/**
 * Serverless Fallback Content Generator
 * Designed to key-in clean, beautiful Kurikulum Merdeka deliverables 
 * dynamically in front-end client when deployed to static hosts like GitHub Pages.
 */

export interface GenerationParams {
  level: string;
  kelas: string;
  semester: string;
  subject: string;
  topic: string;
  cp: string;
  diferensiasi: boolean;
  deepLearning: boolean;
  teacherName: string;
  schoolName: string;
  nip: string;
  instrumentType: string;
  ketunaan?: string;
}

export function generateLocalModule(params: GenerationParams): string {
  const {
    level, kelas, semester, subject, topic, cp,
    diferensiasi, deepLearning, teacherName, schoolName, nip,
    instrumentType, ketunaan = "Tunagrahita"
  } = params;

  const resolvedTeacher = teacherName || "Bpk. Aris Setiawan, S.Pd.";
  const resolvedSchool = schoolName || "SDN Merdeka 01";
  const resolvedNip = nip ? ` (NIP: ${nip})` : "";
  const resolvedTopic = topic || "Gaya dan Tekanan";
  const resolvedSubject = subject || "Sains & IPA";
  const resolvedCp = cp || "Peserta didik mengidentifikasi kaitan antara gaya dengan gerak benda secara kontekstual di lingkungannya.";

  if (instrumentType === "ATP") {
    return `### ALUR TUJUAN PEMBELAJARAN (ATP) TERBARU
**STANDAR KURIKULUM MERDEKA - ELEMEN STRUKTURAL**

#### I. IDENTITAS PEMETAAN AJAR
* **Penyusun:** ${resolvedTeacher}${resolvedNip}
* **Satuan Pendidikan:** ${resolvedSchool}${level === "SMK" ? " (Pusat Keunggulan)" : ""}
* **Mata Pelajaran:** ${resolvedSubject}
* **Fase / Kelas:** ${level} - ${kelas} / ${semester}

---

#### II. ANALISIS RASIONAL & KONSEP ELEMEN
Capaian Pembelajaran (CP) menyatakan:
> ${resolvedCp}

Berdasarkan CP di atas, elemen pembelajaran Kurikulum Merdeka ${level} yang dikembangkan secara terstruktur meliputi:
1. **Elemen Pemahaman Konsepsual:** Mendiagnosis keterkaitan kausalitas teori dasar dengan fenomena nyata.
2. **Elemen Keterampilan Proses:** Menemukan pola, merakit instrumen penyelidikan, serta merancang simpulan asisten mandiri.

---

#### III. ALUR TUJUAN PEMBELAJARAN (ATP) PER PERTEMUAN

| Pertemuan ke- | Alokasi Waktu | Tujuan Pembelajaran (TP) Khusus | Skenario Aktivitas Pembelajaran | Asesmen Formatif |
| --- | --- | --- | --- | --- |
| **Pertemuan 1** | 4 JP (4 x 40m) | Menganalisis cara kerja dasar dan karakteristik utama dari ${resolvedTopic} | Observasi video simulasi, diskusi kelompok terarah, pencatatan hipotesis dasar | Penilaian lembar observasi partisipasi diskusi kelompok |
| **Pertemuan 2** | 4 JP (4 x 40m) | Merancang eksperimen terpadu menguji sifat-sifat fungsional ${resolvedTopic} | Pengumpulan data lapangan, pengukuran presisi, pengisian tabel pembanding | Checkpoint tabel pengolahan data kelompok |
| **Pertemuan 3** | 4 JP (4 x 40m) | Mampu mengevaluasi penyimpangan hasil uji dan mempresentasikan simpulan | Debat antar kelompok, pemaparan lisan, refleksi perbaikan mandiri | Rubrik unjuk kerja presentasi lisan |

---

#### IV. PROFIL PELAJAR PANCASILA & GLOSARIUM MINI
* **Profil Utama Pelajar Pancasila:** 
  * **Bernalar Kritis:** Mengolah informasi ilmiah secara objektif dan menganalisis sebab-akibat.
  * **Gotong Royong:** Berkolaborasi membagi peran demi menyelesaikan proyek kelas secara mulus.
* **Glosarium Istilah Kurikulum:**
  * **Apersepsi:** Upaya mengaitkan materi lama dengan fenomena baru sebagai jembatan mental siswa.
  * **Standardisasi:** Batas toleransi parameter baku yang diakui resmi untuk menjamin mutu ukur.`;

  } else if (instrumentType === "LKPD") {
    return `### LEMBAR KERJA PESERTA DIDIK (LKPD) INTERAKTIF
**STANDAR KURIKULUM MERDEKA - MANDIRI DAN BERKELOMPOK**

#### I. INFORMASI TUGAS AKTIVITAS
* **Topik Pembahasan:** ${resolvedTopic}
* **Mata Pelajaran:** ${resolvedSubject}
* **Penyusun:** ${resolvedTeacher}
* **Satuan Pendidikan:** ${resolvedSchool}

---

#### II. IDENTITAS KELOMPOK KERJA SISWA
* **Nama Kelompok:** __________________________________
* **Fase / Kelas:** ${kelas}
* **Ketua & Anggota Kelompok:**
  1. __________________ (Ketua)
  2. __________________
  3. __________________
  4. __________________

---

#### III. LANGKAH-LANGKAH AKTIVITAS BELAJAR SISWA

##### A. Tahap Observasi Awal (Apersepsi)
Amatilah diagram/fenomena berkaitan dengan **${resolvedTopic}** yang disajikan oleh guru. Catatlah dua (2) pertanyaan kritis yang menggelitik pikiran kelompok Anda:
1. __________________________________________________________________
2. __________________________________________________________________

##### B. Tahap Investigasi Kelompok
1. Siapkan peralatan praktik / buku referensi pendukung yang relevan.
2. Lakukan pengujian / studi pustaka sesuai petunjuk guru secara kompak.
3. Catat dan isilah tabel pengamatan di bawah ini dengan kejujuran akademis.

| Uji Coba ke- | Variabel yang Diuji | Hasil Pengamatan Visual | Analisis Sebab-Akibat |
| --- | --- | --- | --- |
| 1 | Pengukuran Tingkat Awal | __________________ | ____________________________________ |
| 2 | Pengukuran Tingkat Lanjut | __________________ | ____________________________________ |
| 3 | Kondisi Extreme / Anomali | __________________ | ____________________________________ |

##### C. Tahap Presentasi dan Kesimpulan
Diskusikan dengan tim Anda mengenai korelasi hasil uji coba di atas dengan standardisasi buku. Laporkan ke depan kelas untuk dinilai oleh asisten kelompok lain.

---

#### IV. PERTANYAAN REFLEKSI KRITIS (HOTS)
1. Menurut analisis kelompok Anda, faktor eksternal apa yang paling dominan memicu ketidakstabilan nilai ukur ${resolvedTopic} saat eksperimen?
2. Bagaimana cara paling efisien yang disepakati bersama untuk mereduksi tingkat kesalahan tersebut di masa depan?`;

  } else if (instrumentType === "MODUL_BERMAIN") {
    return `### RENCANA PELAKSANAAN PEMBELAJARAN (MODUL BERMAIN PAUD)
**FASE FONDASI - BELAJAR MENYENANGKAN BERPUSAT PADA ANAK**

#### I. INFORMASI UMUM & IDENTITAS
* **Nama Pendidik:** ${resolvedTeacher}
* **Satuan PAUD:** ${resolvedSchool}
* **Kelompok Usia:** ${kelas || "TK B (5-6 Tahun)"}
* **Semester / Minggu:** ${semester} / Minggu ke-3
* **Topik Inspiratif:** ${resolvedTopic}

---

#### II. ELEMEN CAPAIAN PERKEMBANGAN PAUD
Capaian Pembelajaran (CP) PAUD yang disasar pada modul ini:
> ${resolvedCp}

*   **Nilai Agama & Budi Pekerti:** Anak menyayangi sesama makhluk hidup ciptaan Tuhan dan tertib dalam aktivitas pembuka harian.
*   **Jati Diri:** Anak menunjukkan kemandirian memilih wahana bermain serta bersosialisasi secara ramah.
*   **STEAM & Literasi:** Anak mengeksplorasi loose parts alam sektoral, mengenal tekstur raba, dan mengungkapkan perasaannya secara gembira.

---

#### III. LANGKAH-LANGKAH BERMAIN BERMAKNA (Skenario Pijakan Sentra)

##### A. Pijakan Pembuka / Lingkar Pagi (30 Menit)
1. Sambutan hangat guru dengan salam, melatih kerapian menaruh tas, dan berdoa bersama.
2. Membaca nyaring dongeng bergambar bertajuk *Kisah Petualangan ${resolvedTopic}*.
3. Guru merumuskan aturan bermain yang menyenangkan dan asyik bersama anak-anak.

##### B. Pijakan Saat Bermain / Inti Eksplorasi (60 Menit)
*   **Sentra Seni/Loose Parts:** Anak menyusun kolase dari daun kering, kerikil warna-warni, dan kancing kayu membentuk miniatur pohon/benda fungsional.
*   **Sentra Sains Sederhana:** Mengamati pola gelembung, mencampur warna cat alami, atau meraba kasarnya aneka jenis tanah.
*   **Sentra Peran Makro:** Bermain peran sebagai sahabat kebun raya yang ramah lingkungan.

##### C. Pijakan Setelah Bermain / Recalling & Evaluasi (15 Menit)
1. Bernyanyi "Beres-beres waktu selesai" untuk melatih kedisplinan kemandirian anak.
2. Tanya jawab perasaan anak didampingi pameran karya bermain mereka hari ini.
3. Berdoa penutup dan bersiap pulang dengan gembira.

---

#### IV. RENCANA ASESMEN PERKEMBANGAN
1. **Catatan Anekdot (Anecdotal Record):** Mencatat peristiwa perilaku unik anak saat bersikap kolaboratif.
2. **Hasil Karya & Foto Berseri:** Mendokumentasikan ekspresi kreatifitas anak menyusun loose parts secara mendalam.`;

  } else if (instrumentType === "ASESMEN_PERKEMBANGAN") {
    return `### RUBRIK ASESMEN PERKEMBANGAN ANAK USIA DINI
**STANDAR KURIKULUM MERDEKA - OBSERVASI FORMATIF LANGSUNG**

#### I. IDENTITAS PENGAMATAN PAUD
* **Satuan Pendidikan PAUD:** ${resolvedSchool}
* **Pendidik Mengamati:** ${resolvedTeacher}
* **Aspek Utama Kurikulum:** ${resolvedSubject}
* **Kelompok Usia:** ${kelas || "TK B (5-6 Tahun)"}

---

#### II. RUBRIK CAPAIAN PERKEMBANGAN ANAK (Indikator Kinerja)

| Aspek Indikator Perkembangan | Belum Muncul (BM) | Mulai Muncul (MM) | Berkembang Sesuai Harapan (BSH) | Berkembang Sangat Baik (BSB) |
| --- | --- | --- | --- | --- |
| **Kemandirian Perilaku Positif** | Anak enggan merapikan mainan atau masih menangis saat ditinggal. | Anak merapikan mainan hanya setelah mendapat bujukan lembut guru. | Anak merapikan mainan secara mandiri atas kesadaran asalnya. | Anak merapikan mainan sendiri dan tulus membantu temannya membereskan. |
| **Sensosrik Motorik & STEAM** | Kesulitan menggenggam material loose parts alami. | Menggenggam material loose parts tapi belum presisi menyembul pola. | Menyusun pola loose parts secara terstruktur dan tuntas sampai akhir. | Menyusun pola yang unik bercerita luas dengan komponen kombinasi baru. |
| **Literasi Komunikasi Verbal** | Hanya menjawab singkat dengan gerakan isyarat. | Menjawab dengan 1-2 kata tanya guru kelas penyabar. | Menjelaskan secara runtut dengan 3 kalimat utuh tentang mainannya. | Menuturkan cerita yang kaya imajinasi baru yang seru kepada segenap rekan. |

---

#### III. INSTRUMEN CATATAN TINDAK LANJUT GURU
*   Jika tingkat perkembangan dominan anak masih di interval **Belum Muncul (BM)**, pendidik akan memberikan bimbingan sensorik terfokus secara persuasif penuh empati di area bermain basah tanpa paksaan.`;

  } else if (instrumentType === "ANECDOTAL_RECORD") {
    return `### CATATAN ANEKDOT (ANECDOTAL RECORD) HARIAN PAUD
**KURIKULUM MERDEKA – INSTRUMEN MONITORING INDIVIDU GURU**

* **Satuan PAUD:** ${resolvedSchool}
* **Guru Pengamat:** ${resolvedTeacher}
* **Kelompok Usia:** ${kelas}
* **Konten Aktivitas:** ${resolvedTopic}

---

#### I. FORMAT TABEL CATATAN ANEKDOT INDIVIDU

| Hari & Tanggal | Waktu Pengamatan | Nama Siswa | Lokasi Kejadian | Deskripsi Peristiwa Kejadian / Perilaku Unik | Interpretasi Capaian Elemen Perkembangan |
| --- | --- | --- | --- | --- | --- |
| Senin, 25 Mei | 09.30 WIB | Ananda Budi | Area Sentra Balok | Budi secara sukarela meminjamkan balok kayu berbentuk segitiga miliknya pada Ananda Citra yang kekurangan balok untuk jembatan. | **Sosial-Emosional (Jati Diri):** Menunjukkan kematangan emosi, sikap berbagi, dan empati kolaboratif tingkat tinggi (BSB). |
| Selasa, 26 Mei | 10.15 WIB | Ananda Dinda | Kebun Eksplorasi | Dinda jongkok cukup lama menatap tetesan air embun di helai daun keladi, menyentuhnya perlahan dan berkata, "Ibu, airnya berkilau seperti kristal." | **Sains Sederhana / STEAM:** Rasa ingin tahu ilmiah yang tajam, apresiasi keindahan alam ciptaan Tuhan (BSH). |

---

#### II. EVALUASI DAN INTERVENSI STIMULASI LANJUTAN GURU
1. **Rencana Pengayaan Dinda:** Sediakan pinset dan wadah transparan di sentra kebun agar Dinda dapat mengamati butiran air atau serangga ramah lebih intensif.
2. **Apresiasi Sikap Budi:** Memberi bintang penghargaan di papan disiplin ceria untuk memotivasi perilaku suka berbagi di depan anak kelas lainnya.`;

  } else if (instrumentType === "RAPOR_PAUD") {
    return `### DRAF NARASI LAPORAN RAPOR PERKEMBANGAN PAUD
**STANDAR KURIKULUM MERDEKA - DESKRIPSI KONSTRUKTIF**

* **Identitas Siswa Didik:** [Nama Siswa]
* **Satuan PAUD:** ${resolvedSchool}
* **Pendidik Penyusun:** ${resolvedTeacher}
* **Fase / Kelompok Usia:** Fase Fondasi / ${kelas || "TK B (5-6 Tahun)"}

---

#### I. ELEMEN NILAI AGAMA DAN BUDI PEKERTI
> *"Ananda menunjukkan perkembangan yang **Sangat Baik** dalam mengenal nilai agama ciptaan Tuhan. Dirinya gemar merawat kelestarian lingkungan kelas dengan menyayangi tanaman hias pot secara rutin menyiramnya, membuang remahan makanan di tempat sampah khusus, serta melafalkan doa sebelum serta sesudah belajar secara mandiri dengan khidmat."*

---

#### II. ELEMEN JATI DIRI (PENDIDIKAN KARAKTER)
> *"Ananda menunjukkan kecenderungan yang **Berkembang Sangat Baik** dalam mengelola emosi secara sehat. Dirinya mampu menggunakan sepatu secara mandiri, mengantre menunggu giliran cuci tangan dengan sabun tanpa menyela rekan, serta menunjukkan solidaritas yang hangat menjenguk teman bermain yang terjatuh."*

---

#### III. ELEMEN DASAR LITERASI DAN STEAM (SAINS TEKNOLOGI)
> *"Ananda memiliki minat eksplorasi yang amat **Menonjol** dalam sains dasar. Terlihat saat dirinya antusias memisahkan ukuran butiran batu pasir halus ke wadah berbeda secara logis dan runtut. Ananda terampil mendeskripsikan secara lisan kepada guru mengenai hasil penemuan unik struktur polanya bercerita."*`;

  } else if (instrumentType === "OBSERVASI_ANAK") {
    return `### LEMBAR CEKLIS OBSERVASI PERKEMBANGAN ANAK
**MONITORING TUMBUH KEMBANG SEHAT - MOTORIK DAN ADAPTIF**

* **Satuan PAUD:** ${resolvedSchool}
* **Guru Pendamping:** ${resolvedTeacher}
* **Kelompok Usia:** ${kelas}
* **Tema Penyelarasan:** ${resolvedTopic}

---

#### I. DAFTAR INDIKATOR OBSERVASI BULANAN

| No | Indikator Kompetensi Perkembangan Anak | Muncul (V) | Belum Muncul (X) | Catatan Khusus Perilaku Guru |
| --- | --- | --- | --- | --- |
| 1 | **Motorik Kasar:** Mampu melompati rintangan busa setinggi 10cm dengan kedua kaki mendarat seimbang. | [ ] | [ ] | ____________________________________ |
| 2 | **Motorik Halus:** Terampil menggunting garis lurus kertas mengikuti pola putus-putus secara mandiri. | [ ] | [ ] | ____________________________________ |
| 3 | **Kemampuan Kognitif:** Menyebutkan perbedaan rasa manis dari gula tebu dan asin dari garam dapur alami. | [ ] | [ ] | ____________________________________ |
| 4 | **Sikap Sosial:** Meminta bantuan dengan santun memakai kata "tolong" dan bersyukur "terima kasih". | [ ] | [ ] | ____________________________________ |

---

#### II. CARA PENGUKURAN DAN VALIDASI GURU
*   Lakukan observasi santai tanpa memberi kesan ujian menegangkan bagi anak. Simpan hasil karya serta jepretan foto anak untuk portofolio akhir rapor.`;

  } else if (instrumentType === "DEEP_LEARNING_PAUD") {
    return `### PANDUAN IMPLEMENTASI DEEP LEARNING SEJAK PAUD
**PEMAHAMAN MENDALAM BERBASIS PRINSIP INSTRUKSIONAL HOTS-PAUD**

* **Jenjang:** PAUD / TK - ${kelas}
* **Topik Pembahasan:** ${resolvedTopic}
* **Mata Pelajaran (Aspek):** ${resolvedSubject}

---

#### I. TIGA PILAR DEEP LEARNING UNTUK ANAK DIDIK

1. **Sensory Connection (Koneksi Multisensori):**
   * Pendidik diajurkan menyajikan material fisik yang dapat dirasa (loose parts alam, kayu kasar, kain velvet, daun lembap).
   * Anak belajar menyerap realitas fisik untuk memicu konektivitas ingatan jangka panjang.

2. **Critical Investigation (Investigasi Kausalitas):**
   * Guru mengarahkan kemandirian bertanya yang HOTS (High Order Thinking) lewat stimulus terbuka.
   * Contoh pertanyaan pemantik: *"Bagaimana ya jika bumi kita tidak pernah mendung dan turun rintik hujan?"* atau *"Mengapa daun pohon berwarna hijau cerah ya?"*

3. **Creative Expressive Output (Ekspresi Kreasi Mandiri):**
   * Siswa menuangkan pemahamannya lewat karya bebas. Tidak mendikte anak membuat bentuk yang identik (bukan sekadar mewarnai gambar kaku bentukan guru).

---

#### II. DESAIN AKTIVITAS DEEP LEARNING DI KELAS
*   Sediakan area sentra basah dan sentra konstruksi balok berdampingan, lalu bebaskan anak merakit replika saluran air ramah lingkungan seturut kreativitas unik mereka tanpa dihakimi bersalah.`;

  } else if (instrumentType === "ASESMEN") {
    return `### INSTRUMEN ASESMEN & EVALUASI BELAJAR LENGKAP
**STANDAR KURIKULUM MERDEKA – EVALUASI DIAGNOSTIK, FORMATIF, DAN SUMATIF**

#### I. ASESMEN DIAGNOSTIK KOGNITIF (Awal Kegiatan Kelas)
1. Menurut ingatan awal Anda, apa peran kegunaan vital dari **${resolvedTopic}** dalam kehidupan praktis sehari-hari?
2. Apabila komponen pendukung dari **${resolvedTopic}** hilang dari sistem, kegagalan apa yang sekiranya akan berkecamuk?

---

#### II. ASESMEN FORMATIF (Rubrik Observasi Sikap & Karakter Pancasila)

| Nama Peserta Didik | Aspek Bernalar Kritis (Skor 1-4) | Aspek Gotong Royong (Skor 1-4) | Aspek Kemandirian (Skor 1-4) | Deskripsi Tindak Lanjut Evaluasi |
| --- | --- | --- | --- | --- |
| Siswa A | 4 (Sangat Baik) | 3 (Layak) | 4 (Sangat Baik) | Menunjukkan inisiatif analitis tinggi memimpin kelompok. |
| Siswa B | 2 (Perlu Bimbingan) | 4 (Sangat Baik) | 3 (Layak) | Kooperatif dalam kelompok namun perlu dilatih kelancaran kemandirian. |

*   *Skor 4 = Sangat Terpadu; Skor 3 = Cakap Terlatih; Skor 2 = Cukup Berkembang; Skor 1 = Mulai Tumbuh.*

---

#### III. ASESMEN SUMATIF (Soal HOTS Pilihan Ganda & Esai)

##### A. Soal Pilihan Ganda Berpikir Tingkat Tinggi (HOTS)

*   **Soal 1:** Perhatikan pernyataan berikut! Kerusakan atau bias pada sistem ${resolvedTopic} sering kali disebabkan oleh intervensi anomali panas berlebih atau kelembapan koneksi. Metode penanganan dini manakah yang paling direkomendasikan untuk mencegah kegagalan fatal pada sistem tersebut?
    *   **A.** Menurunkan kapasitas tegangan suplai listrik secara mendadak.
    *   **B.** Melakukan observasi visual berkala dan kalibrasi akurasi instrumen ukur secara rutin (Kunci).
    *   **C.** Membiarkan retakan sistem menguap tanpa ada tindakan pencatatan resmi.
    *   **D.** Menambahkan komponen pelapis luar tanpa mengukur kelaikan beban.
    *   **E.** Menonaktifkan isolasi pelindung termal demi menghemat biaya pengerjaan.
    *   *Kunci Jawaban:* **B**
    *   *Pembahasan:* Observasi visual dini dan kalibrasi periodik mencegah terjadinya penyimpangan akumulatif sistem.

*   **Soal 2:** Faktor kritis yang paling memengaruhi keandalan jangka panjang dari fungsi ${resolvedTopic} di lingkungan sekolah yaitu...
    *   **A.** Tingkat keterampilan guru menguji secara digital serta keaktifan siswa merespon kritis (Kunci).
    *   **B.** Kerapian bungkus buku panduan administrasi di laci meja laboratorium.
    *   **C.** Jumlah pajangan ornamen warna-warni di dinding ruang belajar.
    *   *Kunci Jawaban:* **A**

##### B. Soal Esai Analitis Uraian
1. Kemukakan secara komparatif dampak ekonomi dan keselamatan kerja dari penerapan *preventive maintenance* (pemeliharaan pencegahan) versus *reactive maintenance* (perbaikan darurat) dalam penanganan teknologi **${resolvedTopic}**!`;

  } else if (instrumentType === "BAHAN_AJAR") {
    return `### BAHAN AJAR BACAAN MANDIRI GURU & SISWA
**SUMBER REFERENSI INTERNAL – KURIKULUM MERDEKA ADAPTIF**

#### I. INFORMASI IDENTITAS MATERI
* **Bahan Bacaan Pokok:** ${resolvedTopic}
* **Mata Pelajaran Pendukung:** ${resolvedSubject}
* **Fase / Jenjang:** ${level} - ${kelas}
* **Sasaran Pembaca:** Rekan Guru Kelas & Peserta Didik Mandiri

---

#### II. RINGKASAN TEORI DAN KONSEP UTAMA (Core Concept)
Konsep teknologi penanganan **${resolvedTopic}** beroperasi atas pilar kestabilan dinamis yang saling terhubung satu dengan lainnya. Perannya sangat masif untuk penentu tingkat keandalan aktivitas fungsional di lapangan.

*   **Peta Alur Struktur Sistem:**
    1.  **Input Layer:** Sinyal masukan, instrumen pengukuran awal, atau sapaan kondisi.
    2.  **Processor Engine:** Tahap kalkulasi, penganalisaan data, penyelarasan kurikulum oleh pendidik.
    3.  **Output Actuator:** Tindakan akhir terstandar, pelaporan ilmiah, atau pemecahan kasus nyata.

---

#### III. STUDI KASUS NYATA (Konteks Indonesia)
*   **Studi Kasus Lapangan:** Di industri modern Indonesia maupun sektor penunjang pendidikan, kerusakan ${resolvedTopic} sering diidentifikasi akibat kegagalan instalasi kabel pelindung yang terkelupas oleh gesekan eksternal. Kerugian operasional akibat bias akurasi dapat menyentuh angka efisiensi hingga 30% dari kapasitas aslinya.
*   **Arah Pemecahan Masalah:** Mengaplikasikan selubung ganda fleksibel serta menjadwalkan inspeksi visual setarakan standar SOP pabrik/akademi dwi-mingguan teratur.

---

#### IV. GLOSARIUM MINI & PANDUAN BELAJAR CEPAT
*   **Kalibrasi:** Pengecekan tingkat akurasi alat ukur terhadap tolok ukur acuan yang diakui presisinya secara global.
*   **Troubleshooting:** Rangkaian kronologis penelusuran letak kesalahan sistem demi memperoleh akar penyebab gangguan.`;

  } else if (instrumentType === "KKTP_GLOSARIUM") {
    return `### KRITERIA KETERCAPAIAN TUJUAN PEMBELAJARAN (KKTP) & GLOSARIUM
**STANDAR KURIKULUM MERDEKA – SISTEM PENILAIAN RUBRIK INTERVAL**

#### I. PEMETAAN KRITERIA KETERCAPAIAN (KKTP)

| Kriteria Indikator Ketercapaian Kompetensi | Baru Berkembang (0-40%) | Layak Bermutu (41-70%) | Cakap Teruji (71-90%) | Mahir Unggul (91-100%) |
| --- | --- | --- | --- | --- |
| **Pemahaman Konseptual Teori ${resolvedTopic}** | Mengingat sebagian definisi tapi linglung mengaitkan fungsionalitas. | Mampu merangkum inti teori dan menyusun alur penanganan tertulis. | Mampu mendeteksi & membandingkan berbagai jenis error teori. | Mampu mengkritisi, merekonstruksi alternatif, serta memecahkan problem teoritis. |
| **Keterampilan Praktis Prosedural** | Kebingungan memegang instrumen atau asisten kelompok. | Mampu bernalar menguji instrumen di bawah bimbingan guru. | Terampil mengkalibrasi dan mengoperasikan sistem secara mandiri. | Mampu mendiagnosis anomali luar, mereduksi noise, dan memimpin tim. |

*   **Kebijakan Tindak Lanjut Guru Kelas:**
    *   **Interval 0-40%:** Pembelajaran remedial personal intensif terkait konsep pondasi dasar eleman.
    *   **Interval 41-70%:** Pengulangan terfokus disertai pendampingan tutor sebaya yang asyik.
    *   **Interval 71-100%:** Pengayaan mandiri, delegasi asisten lab, atau pembuatan materi bantu mengajar.

---

#### II. GLOSARIUM KOMPREHENSIF MATERI
*   **Akurasi:** Tingkat simpangan terkecil dari hasil pengukuran jika dinilai dengan variabel ideal aslinya.
*   **Diagnosis:** Metode ilmiah penentuan jenis malafungsi berdasarkan tanda-tanda abnormalitas visual/suara.
*   **Simulasi:** Penyederhanaan model operasional dunia nyata untuk memfasilitasi area praktik yang aman.

---

#### III. DAFTAR PUSTAKA UTAMA ALIENASI AJAR
1. Badan Standar, Kurikulum, dan Asesmen Pendidikan (BSKAP) Kemendikbudristek RI. (2024). *Panduan Pembelajaran dan Asesmen Kurikulum Merdeka*. Jakarta.
2. Tim Pengembang Kurikulum Pendidikan Vokasi Nasional. (2023). *Buku Pegangan Guru Bidang Keahlian Istimewa*. Pusat Kurikulum Kemdikbudristek.`;

  } else {
    // Default MODUL_AJAR
    return `### RENCANA PELAKSANAAN PEMBELAJARAN (MODUL AJAR)
**STANDAR KURIKULUM MERDEKA - LENGKAP & SISTEMATIS**

#### I. INFORMASI IDENTITAS MODUL
* **Nama Penyusun:** ${resolvedTeacher}${resolvedNip}
* **Satuan Pendidikan:** ${resolvedSchool}
* **Mata Pelajaran:** ${resolvedSubject}
* **Jenjang / Kelas:** ${level} / ${kelas}
* **Semester / Semester Ajar:** ${semester}
* **Alokasi Waktu:** 2 x 40 Menit (1 Sesi)
* **Topik Bahasan:** ${resolvedTopic}

---

#### II. LANGKAH-LANGKAH TARGET KOMPETENSI
* **Capaian Pembelajaran (CP) Elemen:**
  > ${resolvedCp}

* **Tujuan Pembelajaran Khusus (TP):**
  1. Melalui eksplorasi kasus, peserta didik mampu menguraikan kegunaan operasional **${resolvedTopic}** dengan penuh tanggung jawab.
  2. Peserta didik dapat menguji keabsahan penanganan solusi kasus nyata terkait dalam tim kerja kolaboratif.

${diferensiasi ? `* **Strategi Konten Pembelajaran Diferensiasi:**
  * **Diferensiasi Konten:** Menyertakan video pendek, diagram alur, teks bacaan ringkas, dan objek uji fisik nyata.
  * **Diferensiasi Proses:** Siswa dibagi menjadi kelompok mandiri, kelompok bimbingan asisten sebaya, dan kelompok bimbingan langsung guru.` : ''}

${deepLearning ? `* **Prinsip Deep Learning (Pembelajaran Mendalam):**
  * **Critical Thinking (Berpikir Kritis):** Membongkar letak anomali sistem secara sistematis tanpa langsung mendikte instruksi kaku.
  * **Connetion (Korelasi):** Menghubungkan teori buku dengan realitas kehidupan / dunia kerja di Indonesia.` : ''}

---

#### III. SKENARIO ALUR PEMBELAJARAN (Langkah Rinci)

##### A. Kegiatan Pendahuluan (15 Menit)
1. Guru memberikan salam hangat pembuka batin, memeriksa kebersihan baris bangku, dan memandu doa bersama.
2. **Apersepsi:** Guru melontarkan pertanyaan pemantik: *"Mengapa sistem ${resolvedTopic} seringkali mengalami anomali saat cuaca buruk? Mari kita telisik jawabannya."*
3. Guru menyampaikan motivasi relevansi materi terhadap prospek daya saing di masa depan.

##### B. Kegiatan Inti Eksplorasi (50 Menit)
1. **Stimulasi (Rangsangan):** Peserta didik melihat tayangan kasus kegagalan struktural ${resolvedTopic} di depan kelas.
2. **Identifikasi Masalah:** Guru membagikan LKPD aktivitas kerja, membebaskan siswa menanyakan ganjalan awal.
3. **Pengumpulan Data:** Siswa berkelompok membagi peran, membaca buku referensi/dokumentasi digital secara kolaboratif.
4. **Pengolahan Data:** Masing-masing kelompok menuangkan hasil perumusan solusinya ke dalam tabel bimbingan.
5. **Verifikasi & Presentasi:** Kelompok memaparkan hasil karyanya, disusul tanggapan kritis kelompok pendamping.
6. **Simpulan Bersama:** Guru meluruskan bias pemahaman dan menyepakati inti materi dengan bagan representatif.

##### C. Kegiatan Penutup (15 Menit)
1. Siswa merangkum poin esensial dan mengisi emotikon lembar refleksi emosional belajarnya.
2. Guru menutup dengan apresiasi yang membakar semangat cita-cita, doa syukur kelompok, dan baris pulang tertib.

---

#### IV. ASESMEN PENILAIAN AJAR
1. **Penilaian Sikap:** Kedisiplinan antre serta kolaborasi mandiri profil pelajar Pancasila.
2. **Penilaian Pengetahuan:** Kuis penalaran analitis berupa 3 butir soal HOTS singkat.
3. **Penilaian Keterampilan:** Ketepatan pengisian bagan solusi kerja pada LKPD terstruktur.`;
  }
}

export interface ChatParams {
  message: string;
  history: Array<{sender: string, text: string}>;
}

export function generateLocalChat(params: ChatParams): { text: string, suggestions: string[], assets?: any } {
  const message = params.message.toLowerCase();
  
  let hasTSMContext = message.includes("tsm") || message.includes("motor") || message.includes("injeksi") || message.includes("bengkel");
  let hasSainsContext = message.includes("sains") || message.includes("ipa") || message.includes("biologi") || message.includes("fisika") || message.includes("ekosistem");
  let hasMathContext = message.includes("matematika") || message.includes("angka") || message.includes("rumus") || message.includes("hitung") || message.includes("geometri");

  let text = "Halo Pak Guru! Saya siap membantu Anda menyusun rancangan kurikulum masa depan Merdeka yang adaptif dan interaktif. ";
  let suggestions = ["Tuliskan RPP Rinci", "Rancang Asesmen HOTS"];
  let assets: any = undefined;

  if (hasTSMContext) {
    text += `Saya mendeteksi topik **Teknik Sepeda Motor (TSM)**. Berikut draf rekomendasi rancangan topik **Sistem Injeksi & Diagnosis DTC**:

### Rencana Ajar Pendukung (TSM Vokasi)
* **Langkah Pembuka:** Apersepsi mengenai kedipan lampu MIL (Malfunction Indicator Light) pada motor injeksi.
* **Langkah Praktik:** Siswa melakukan diagnostik mandiri menggunakan scanner OBD2, membaca sinyal tegangan sensor, dan melakukan reset manual.
* **Sikap Kejuruan:** Menuntut kepatuhan tinggi terhadap APD (Alat Pelindung Diri) dan kebersihan lap bengkel kerja.

*Saya telah memaketkan Lembar Aktivitas, Slides Pendukung, dan Cheat Sheet khusus DTC untuk Anda yang bisa langsung diunduh di sebelah kanan layar!*`;
    suggestions = ["Generate Asesmen Diagnostik", "Buat Skrip Video Praktik"];
    assets = {
      slides: {
        title: "Sistem Bahan Bakar Injeksi TSM (Troubleshooting)",
        fileName: "Struktur Sistem EFI TSM.pptx",
        imageUrl: "https://lh3.googleusercontent.com/aida-public/AB6AXuA9vAg5zp8-iJUvzpiP6AQ4y6NiQPBtU9RiykmVQw7VwBTNY0XskTpgT8dNo2eoat4BFP4p-bcODGHuq4ENYPhjN_l9QfUf_J4xRTICWAkoP1wdlGViJaekHZFzEBXwoI8OdJmYrV_sdSWo4ZEBX0kpPLBHyH269n5LTD5xwPLERXsKPd1DQZOC9PrDCDG4LbMq_z8wvdkranPS1gAu23mlvGLISyRj354SoQA3YOdKlbyK0c9QE1C_88hRDiNLp0Kz8V_xuVIe3Is"
      },
      lkpd: {
        title: "LKPD Mandiri: Sensor EFI & Troubleshooting",
        status: "TERSEDIA",
        imageUrl: "https://lh3.googleusercontent.com/aida-public/AB6AXuD6I1iRN3oXZ3UbR8RehvpUnsVhX-YRo2S72uli4gXAvii_6XpLFtWs6bbG3XDZZzK4DOd8hZK9X95qLX0pscrrVe2Q119mTzdllcdUCna3XlIFxtPxnT-CLOuJU2RwaSXJ1PboIc7puZRxco0Th_4KIJJ7xiSzOeZxU2haKfuwXy8rholiMfI8iaVVkbxtmPTxHg_seLiIp2qNsyRC74771FZvQ_oJ0EWtWCxc6ptiaCDneGk9nTyuZZsyQyn9Xm_oGRvJVoWK7Vs"
      },
      cheatsheet: {
        title: "Cheat Sheet Diagnosis DTC & Reset ECU",
        status: "TERSEDIA",
        imageUrl: "https://lh3.googleusercontent.com/aida-public/AB6AXuDS1W94dC7hEo6QxHw60Cl4c7EbH4yKGR6bkNxOYOSnJL6-NrsTHdegXieUBrR-j-VdlzKkMlaLqbzlGeIwrp3vVBMS06R6JbyD40Rnr_9EeTtMcMXXDZkwH4cLxJLBRbNCFQtNbruY7ublWYKWiD8uL2XTp0BBjnmJOWaanDKbi7v5NF2GwQ97WAUh8MkEAuJmia86ejSErc5u0NVBhLAnH2s7A7jp5WWsuPCTZy4LFVHacZnL4ywKo36yi6Bgr5jo0uVXGk-nVuE"
      }
    };
  } else if (hasSainsContext) {
    text += `Saya mendeteksi topik **Sains/IPA**. Berikut draf rancangan **Interaksi Biotik & Abiotik Ekosistem**:

### Modul Singkat (Sains Mandiri)
* **Kosep Utama:** Rantai makanan, produsen, konsumen puncak, dan peredaran materi nutrien.
* **Aktivitas Berpikir:** Melakukan observasi semut, cacing, tanaman, di pekarangan luar kelas lalu digambar skematik hubungannya.

*Aset pembelajaran, slide interaktif, LKPD siswa, dan materi visual terkait sains telah terpasang rapi di kanan sehingga siap diunduh!*`;
    suggestions = ["Buat Lembar Kerja Kelompok", "Integrasikan Nilai Pancasila"];
    assets = {
      slides: {
        title: "Rantai Makanan & Abiotik - Sains SD/SMP",
        fileName: "Interaksi Ekosistem Sains.pptx",
        imageUrl: "https://lh3.googleusercontent.com/aida-public/AB6AXuAZed_mzWOGdONt9tUUYzWHsS7u30gjvXp_PmLosxMniz97GzGpQ8PcHWOoyNkLozz4o3tMAP-2ROZU2y2AUbSy1ADINY-c5KXabmVK3XfQS-jJZYWCP_eYxgMEvts_up6EL0RKcpx4PCy-lfoFlFbaIrkHkVTSvaVgG2QzX-VoUFckGMCNYJeYGwUXd9fxeOLK1yA50jY4FDGF9xp50pW6xJGDq0MkWS3FNNw-n9-jJ8YF-ROatCpg7Sb4DtYoRwNEZ9zAfTLnohk"
      },
      lkpd: {
        title: "Lembar Eksplorasi Biotik Lapangan",
        status: "TERSEDIA",
        imageUrl: "https://lh3.googleusercontent.com/aida-public/AB6AXuD6I1iRN3oXZ3UbR8RehvpUnsVhX-YRo2S72uli4gXAvii_6XpLFtWs6bbG3XDZZzK4DOd8hZK9X95qLX0pscrrVe2Q119mTzdllcdUCna3XlIFxtPxnT-CLOuJU2RwaSXJ1PboIc7puZRxco0Th_4KIJJ7xiSzOeZxU2haKfuwXy8rholiMfI8iaVVkbxtmPTxHg_seLiIp2qNsyRC74771FZvQ_oJ0EWtWCxc6ptiaCDneGk9nTyuZZsyQyn9Xm_oGRvJVoWK7Vs"
      },
      cheatsheet: {
        title: "Bagan Klasifikasi Makhluk Hidup",
        status: "TERSEDIA",
        imageUrl: "https://lh3.googleusercontent.com/aida-public/AB6AXuAmHxEGJxZKkdYsSeePu0W0OWeID3mCZMCbNBZK-SxeLiaO9C3KnyR-dtE42P52-PGTqB8x_LBqtd5K0PCIpcPenucb5ROzYnTiCeRE0_dMkGMGA56fXserVO-svib4C3UgjqiirUa-zi6BHXDzUAM2O68adeAGjXN_cneD6-D1lQOGHKoScv-b84Kelop7PCZPki5Xa6YhCnv412ogxYS6xfi6HrgadJj796GXfCpFukNmZIYCI4yoM5jCnnJMJmdCv2gYWN2PXGE"
      }
    };
  } else if (hasMathContext) {
    text += `Saya mendeteksi topik **Matematika**. Ini adalah rancangan silabus **Matematika Konstruktif Bangun Ruang**:

### Intisari Pembelajaran Matematika
* **Indikator:** Mengidentifikasi jaring-jaring limas dan prisma tegak secara visual.
* **Kegiatan Belajar:** Membagikan origami warna, siswa mengukur panjang rusuk, menggunting, melipat, dan menyatukannya demi memahami volume nyata.

*Ingin slide materi, kuis seru, atau bagan formula cepat matematika? Semua sudah terpasang lengkap di panel media sebelah kanan untuk membakar keaktifan kelas!*`;
    suggestions = ["Buat Lembar Kuis Berhadiah", "Buat Petunjuk Kerja Origami"];
    assets = {
      slides: {
        title: "Visualisasi Rumus Geometri Ruang",
        fileName: "Matematika Geometri Ruang.pptx",
        imageUrl: "https://lh3.googleusercontent.com/aida-public/AB6AXuAmHxEGJxZKkdYsSeePu0W0OWeID3mCZMCbNBZK-SxeLiaO9C3KnyR-dtE42P52-PGTqB8x_LBqtd5K0PCIpcPenucb5ROzYnTiCeRE0_dMkGMGA56fXserVO-svib4C3UgjqiirUa-zi6BHXDzUAM2O68adeAGjXN_cneD6-D1lQOGHKoScv-b84Kelop7PCZPki5Xa6YhCnv412ogxYS6xfi6HrgadJj796GXfCpFukNmZIYCI4yoM5jCnnJMJmdCv2gYWN2PXGE"
      },
      lkpd: {
        title: "Kuis Latihan Matematika Konstruktif",
        status: "TERSEDIA",
        imageUrl: "https://lh3.googleusercontent.com/aida-public/AB6AXuD6I1iRN3oXZ3UbR8RehvpUnsVhX-YRo2S72uli4gXAvii_6XpLFtWs6bbG3XDZZzK4DOd8hZK9X95qLX0pscrrVe2Q119mTzdllcdUCna3XlIFxtPxnT-CLOuJU2RwaSXJ1PboIc7puZRxco0Th_4KIJJ7xiSzOeZxU2haKfuwXy8rholiMfI8iaVVkbxtmPTxHg_seLiIp2qNsyRC74771FZvQ_oJ0EWtWCxc6ptiaCDneGk9nTyuZZsyQyn9Xm_oGRvJVoWK7Vs"
      },
      cheatsheet: {
        title: "Formula Cepat Volume & Sisi Bangun Ruang",
        status: "TERSEDIA",
        imageUrl: "https://lh3.googleusercontent.com/aida-public/AB6AXuDS1W94dC7hEo6QxHw60Cl4c7EbH4yKGR6bkNxOYOSnJL6-NrsTHdegXieUBrR-j-VdlzKkMlaLqbzlGeIwrp3vVBMS06R6JbyD40Rnr_9EeTtMcMXXDZkwH4cLxJLBRbNCFQtNbruY7ublWYKWiD8uL2XTp1BBjnmJOWaanDKbi7v5NF2GwQ97WAUh8MkEAuJmia86ejSErc5u0NVBhLAnH2s7A7jp5WWsuPCTZy4LFVHacZnL4ywKo36yi6Bgr5jo0uVXGk-nVuE"
      }
    };
  } else {
    text += "Ada mata pelajaran khusus, jenjang, atau topik kurikulum Merdeka tertentu yang ingin kita eksplorasi atau drafkan bersamanya? Sebutkan bidang kajian seperti Sains, Matematika, atau kejuruan Teknik Sepeda Motor (TSM) agar saya dapat menyiapkan aset media pembelajarannya secara instan.";
    suggestions = ["Rancang Modul Belajar Baru", "Tanya Panduan Kurikulum"];
  }

  return { text, suggestions, assets };
}
