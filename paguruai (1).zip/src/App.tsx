/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState, useEffect } from 'react';
import LandingPage from './components/LandingPage';
import Dashboard from './components/Dashboard';
import ModuleGenerator from './components/ModuleGenerator';
import AIChat from './components/AIChat';
import { TeacherProject, ChatMessage } from './types';
import { 
  Globe, Sparkles, ArrowLeft, Copy, Check, Download, FileText,
  BookOpen, CheckCircle, User, PlusCircle, ArrowUpRight, Home
} from 'lucide-react';

export default function App() {
  const [view, setView] = useState<'landing' | 'dashboard' | 'generator' | 'chat'>('landing');
  const [activeProject, setActiveProject] = useState<TeacherProject | null>(null);
  
  // Custom global chat history state to maintain conversational logs across tabs
  const [chatHistory, setChatHistory] = useState<ChatMessage[]>([]);

  // Teacher profile personal state for customization
  const [teacherName, setTeacherName] = useState(() => {
    return localStorage.getItem("eduai_teacher_name") || "Bpk. Aris Setiawan, S.Pd.";
  });
  const [schoolName, setSchoolName] = useState(() => {
    return localStorage.getItem("eduai_school_name") || "SDN Merdeka 01";
  });
  const [nip, setNip] = useState(() => {
    return localStorage.getItem("eduai_nip") || "19880415 201212 1 002";
  });

  useEffect(() => {
    localStorage.setItem("eduai_teacher_name", teacherName);
  }, [teacherName]);

  useEffect(() => {
    localStorage.setItem("eduai_school_name", schoolName);
  }, [schoolName]);

  useEffect(() => {
    localStorage.setItem("eduai_nip", nip);
  }, [nip]);

  // Check URL Search Params for a published ID
  const [shareId, setShareId] = useState<string | null>(() => {
    const params = new URLSearchParams(typeof window !== 'undefined' ? window.location.search : '');
    return params.get('share');
  });
  const [publishedModule, setPublishedModule] = useState<any | null>(null);
  const [isShareLoading, setIsShareLoading] = useState(false);
  const [shareError, setShareError] = useState<string | null>(null);
  const [hasCopied, setHasCopied] = useState(false);

  useEffect(() => {
    if (shareId) {
      setIsShareLoading(true);
      setShareError(null);
      fetch(`/api/published/${shareId}`)
        .then(res => {
          if (!res.ok) throw new Error("Gagal mengambil data modul publik.");
          return res.json();
        })
        .then(data => {
          setPublishedModule(data);
        })
        .catch(err => {
          console.warn("Serverless mode or fetch failed. Loading simulated curriculum content: ", err);
          // High fidelity offline fallback for share viewer on static websites
          const simModule = {
            title: "Modul Ajar Matematika - Geometri Ruang",
            level: "SMP",
            kelas: "Kelas VII",
            subject: "Matematika Interaktif",
            content: `### RANCANGAN INDUK MODUL AJAR (FORMAT KURIKULUM MERDEKA)

#### I. INFORMASI UMUM & IDENTITAS
* **Nama Penyusun:** Bpk. Aris Setiawan, S.Pd.
* **Satuan Pendidikan:** SDN Merdeka 01
* **Mata Pelajaran:** Matematika (Fase D)
* **Alokasi Waktu:** 2 x 40 Menit (1 Sesi Tatap Muka)
* **Topik Bahasan:** Bangun Ruang Sisi Datar & Jaring-jaring Prisma

---

#### II. LANGKAH-LANGKAH TARGET OPERASIONAL
* **Capaian Pembelajaran (CP):**
  > Peserta didik mampu mengidentifikasi sifat-sifat bangun ruang, membandingkan volume, merancang jaring-jaring prisma dan limas secara akurat dan gembira.
* **Pertanyaan Pemantik HOTS:**
  > "Mengapa bentuk kemasan susu cair kotak kebanyakan berbentuk prisma segi empat? Apa kelebihannya dibanding bentuk tabung?"

---

#### III. SKENARIO ALUR PEMBELAJARAN AKTIF

##### A. Kegiatan Pendahuluan (15 Menit)
1. Guru menyapa kelas penuh kehangatan, mengajak kerapian baris meja, dan melantunkan doa belajar bersama.
2. **Apersepsi:** Membuka alat peraga kotak kado dan mengajukan pertanyaan pemantik mengenai rusuk dan luas permukaannya.

##### B. Kegiatan Inti Eksplorasi (50 Menit)
1. **Pemberian Rangsangan (Sensory):** Siswa meraba rusuk-rusuk dari model jaring prisma transparan yang dipegang guru.
2. **Pengumpulan Data Mandiri:** Setiap kelompok memotong pola selembar origami warna-warni berkat bimbingan lembar aktivitas LKPD.
3. **Pemaparan / Verifikasi:** Siswa mengangkat hasil karyanya secara bergantian dan merumuskan luas permukaannya.

##### C. Kegiatan Penutup (15 Menit)
1. Refleksi diri dengan menempel emotikon perasaan belajar pada papan penutup.
2. Pemberian apresiasi bernada pujian dari guru serta doa syukur penutup bersama.`,
            authorName: "Bpk. Aris Setiawan, S.Pd.",
            schoolName: "SDN Merdeka 01",
            publishedAt: "Baru saja • Bersebelahan Teks"
          };
          setPublishedModule(simModule);
        })
        .finally(() => {
          setIsShareLoading(false);
        });
    }
  }, [shareId]);

  const handleImportModule = () => {
    if (!publishedModule) return;
    
    // Create reference project
    const newProj: TeacherProject = {
      id: "imported_" + Math.random().toString(36).substring(2, 6),
      title: publishedModule.title || "Modul Ajar Impor",
      level: publishedModule.level || "SMK",
      kelas: publishedModule.kelas || "Kelas XI",
      subject: publishedModule.subject || "Lainnya",
      content: publishedModule.content || "",
      updatedAt: "Diimpor baru saja",
      coverImage: "https://lh3.googleusercontent.com/aida-public/AB6AXuCQbLpZIdmivZ7w3CgLp_lXWeE726q08gP1vLymWQL2eT_QvG7L1A29D7D-k0wE4k8pB9H3gLd5a7K4QvGw_1qf7L9C6h5P8L0X3C6p8L5w2y5L3c6C6w8y5L3c6"
    };
    
    setProjects(prev => [newProj, ...prev]);
    setActiveProject(newProj);
    
    // Clear URL without page reload
    const url = new URL(window.location.href);
    url.searchParams.delete('share');
    window.history.replaceState({}, '', url.toString());
    
    // Go straight to editing!
    setShareId(null);
    setPublishedModule(null);
    setView('generator');
  };

  const copyShareToClipboard = () => {
    if (!publishedModule) return;
    navigator.clipboard.writeText(publishedModule.content);
    setHasCopied(true);
    setTimeout(() => setHasCopied(false), 2000);
  };

  const downloadShareText = () => {
    if (!publishedModule) return;
    const element = document.createElement("a");
    const file = new Blob([publishedModule.content], {type: 'text/plain'});
    element.href = URL.createObjectURL(file);
    element.download = `${publishedModule.title.replace(/\s+/g, "_")}.txt`;
    document.body.appendChild(element);
    element.click();
    document.body.removeChild(element);
  };

  const downloadShareAsWord = () => {
    if (!publishedModule) return;
    
    // Clean unwanted symbols in output
    let cleaned = publishedModule.content
      .replace(/#\*/g, '')
      .replace(/\*#/g, '')
      .replace(/[\u200B-\u200D\uFEFF]/g, '');

    const lines = cleaned.split('\n');
    let htmlContent = "";
    let inTable = false;
    let inList = false;

    lines.forEach((line) => {
      let trimmed = line.trim();
      if (!trimmed) {
        if (inTable) { htmlContent += "</table></div>\n"; inTable = false; }
        if (inList) { htmlContent += "</ul>\n"; inList = false; }
        return;
      }

      // Divider rules
      if (trimmed === '---' || trimmed === '***' || trimmed === '___') {
        if (inTable) { htmlContent += "</table></div>\n"; inTable = false; }
        if (inList) { htmlContent += "</ul>\n"; inList = false; }
        htmlContent += "<hr style='border: none; border-top: 1px double #cbd5e1; margin: 18pt 0;' />\n";
        return;
      }

      // Check for table rows starting with |
      if (trimmed.startsWith('|')) {
        if (inList) { htmlContent += "</ul>\n"; inList = false; }
        let cells = trimmed.split('|').map(c => c.trim());
        if (trimmed.startsWith('|')) cells.shift();
        if (trimmed.endsWith('|')) cells.pop();

        const isDivider = cells.every(cell => /^[:\s\-|]+$/.test(cell));
        if (isDivider) return;

        if (!inTable) {
          htmlContent += "<div style='margin: 14pt 0;'><table border='1' cellspacing='0' cellpadding='8' style='border-collapse: collapse; width: 100%; font-family: \"Calibri\", \"Arial\", sans-serif; font-size: 10.5pt; border: 1.5px solid #1e40af;'>\n";
          inTable = true;
          
          htmlContent += "<tr style='background-color: #1e40af; color: #ffffff; font-weight: bold;'>\n";
          cells.forEach(c => {
            htmlContent += `<th style='border: 1.5px solid #1e40af; padding: 10px; text-align: left; font-size: 11pt;'>${c.replace(/[\*\#\_]/g, '')}</th>\n`;
          });
          htmlContent += "</tr>\n";
        } else {
          htmlContent += "<tr>\n";
          cells.forEach(c => {
            let parsedCell = c
              .replace(/\*\*(.*?)\*\*/g, '<strong>$1</strong>')
              .replace(/\_(.*?)\_/g, '<em>$1</em>');
            htmlContent += `<td style='border: 1px solid #cbd5e1; padding: 8px;'>${parsedCell}</td>\n`;
          });
          htmlContent += "</tr>\n";
        }
        return;
      } else {
        if (inTable) {
          htmlContent += "</table></div>\n";
          inTable = false;
        }
      }

      // Roman Headings
      const romanMatch = trimmed.match(/^(I|II|III|IV|V|VI|VII|VIII|IX|X)\.\s+(.*)/i);
      if (romanMatch) {
        if (inList) { htmlContent += "</ul>\n"; inList = false; }
        htmlContent += `<h2 style='font-family: "Calibri", "Arial", sans-serif; font-size: 14pt; color: #1e3a8a; border-bottom: 2px solid #1e3a8a; padding-bottom: 4px; margin-top: 22pt; margin-bottom: 10pt; text-transform: uppercase; font-weight: bold;'>${romanMatch[1]}. ${romanMatch[2].replace(/[\*\#\_]/g, '')}</h2>\n`;
        return;
      }

      // Headings
      if (trimmed.startsWith('### ')) {
        if (inList) { htmlContent += "</ul>\n"; inList = false; }
        let hText = trimmed.replace('### ', '').replace(/[\*\#\_]/g, '');
        htmlContent += `<h3 style='font-family: "Calibri", "Arial", sans-serif; font-size: 12pt; color: #0f172a; margin-top: 16pt; margin-bottom: 8pt; border-bottom: 1px solid #cbd5e1; padding-bottom: 3px; font-weight: bold;'>${hText}</h3>\n`;
        return;
      }

      if (trimmed.startsWith('#### ')) {
        if (inList) { htmlContent += "</ul>\n"; inList = false; }
        let hText = trimmed.replace('#### ', '').replace(/[\*\#\_]/g, '');
        htmlContent += `<h4 style='font-family: "Calibri", "Arial", sans-serif; font-size: 11pt; color: #1e40af; margin-top: 12pt; margin-bottom: 6pt; font-weight: bold; background-color: #f1f5f9; padding: 5px 10px; border-radius: 4px; display: inline-block;'>${hText}</h4>\n`;
        return;
      }

      if (trimmed.startsWith('##### ')) {
        if (inList) { htmlContent += "</ul>\n"; inList = false; }
        let hText = trimmed.replace('##### ', '').replace(/[\*\#\_]/g, '');
        htmlContent += `<h5 style='font-family: "Calibri", "Arial", sans-serif; font-size: 10.5pt; color: #475569; margin-top: 10pt; margin-bottom: 4pt; font-weight: bold; text-transform: uppercase;'>${hText}</h5>\n`;
        return;
      }

      // Quotes
      if (trimmed.startsWith('> ')) {
        if (inList) { htmlContent += "</ul>\n"; inList = false; }
        let qText = trimmed.replace('> ', '')
          .replace(/\*\*(.*?)\*\*/g, '<strong>$1</strong>')
          .replace(/\_(.*?)\_/g, '<em>$1</em>');
        htmlContent += `<div style='border-left: 4px solid #1e40af; background-color: #eff6ff; padding: 10px 15px; margin: 12pt 0; font-style: italic; font-family: "Calibri", "Arial", sans-serif; font-size: 10pt; color: #1e293b;'>${qText}</div>\n`;
        return;
      }

      // List Elements
      if (trimmed.startsWith('* ') || trimmed.startsWith('- ') || trimmed.startsWith('• ')) {
        if (!inList) {
          htmlContent += "<ul style='font-family: \"Calibri\", \"Arial\", sans-serif; font-size: 10.5pt; margin-left: 20px; margin-top: 6pt; margin-bottom: 6pt;'>\n";
          inList = true;
        }
        let liText = trimmed.replace(/^[\*\-\•]\s+/, '');
        let keyValMatch = liText.match(/^\*\*(.*?)\*\*:(.*)/);
        if (keyValMatch) {
          htmlContent += `<li style='margin-bottom: 5px;'><strong>${keyValMatch[1]}</strong>: ${keyValMatch[2].replace(/\*\*(.*?)\*\*/g, '<strong>$1</strong>').replace(/\_(.*?)\_/g, '<em>$1</em>')}</li>\n`;
        } else {
          htmlContent += `<li style='margin-bottom: 5px;'>${liText.replace(/\*\*(.*?)\*\*/g, '<strong>$1</strong>').replace(/\_(.*?)\_/g, '<em>$1</em>')}</li>\n`;
        }
        return;
      }

      // Numbered List
      const numMatch = trimmed.match(/^(\d+)\.\s+(.*)/);
      if (numMatch) {
        if (inList) { htmlContent += "</ul>\n"; inList = false; }
        let numText = numMatch[2]
          .replace(/\*\*(.*?)\*\*/g, '<strong>$1</strong>')
          .replace(/\_(.*?)\_/g, '<em>$1</em>');
        htmlContent += `<p style='font-family: "Calibri", "Arial", sans-serif; font-size: 10.5pt; margin-left: 20px; line-height: 1.45; margin-top: 6px; margin-bottom: 6px;'><strong>${numMatch[1]}.</strong> ${numText}</p>\n`;
        return;
      }

      // Default Paragraphs
      if (inList) { htmlContent += "</ul>\n"; inList = false; }
      let pParsed = trimmed
        .replace(/\*\*(.*?)\*\*/g, '<strong>$1</strong>')
        .replace(/\_(.*?)\_/g, '<em>$1</em>');
      htmlContent += `<p style='font-family: "Calibri", "Arial", sans-serif; font-size: 10.5pt; line-height: 1.45; color: #1e293b; margin-top: 6pt; margin-bottom: 6pt;'>${pParsed}</p>\n`;
    });

    if (inTable) htmlContent += "</table></div>\n";
    if (inList) htmlContent += "</ul>\n";

    // Build the Word container template
    const docHtml = `
      <html xmlns:o='urn:schemas-microsoft-com:office:office' xmlns:w='urn:schemas-microsoft-com:office:word' xmlns='http://www.w3.org/TR/REC-html40'>
      <head>
        <title>${publishedModule.title}</title>
        <!--[if gte mso 9]>
        <xml>
          <w:WordDocument>
            <w:View>Print</w:View>
            <w:Zoom>100</w:Zoom>
            <w:DoNotOptimizeForBrowser/>
          </w:WordDocument>
        </xml>
        <![endif]-->
        <meta charset="utf-8">
        <style>
          @page WordSection1 {
            size: 8.27in 11.69in; /* A4 size */
            margin: 1.0in 1.0in 1.0in 1.0in;
            mso-header-margin: .5in;
            mso-footer-margin: .5in;
            mso-paper-source: 0;
          }
          div.WordSection1 {
            page: WordSection1;
          }
        </style>
      </head>
      <body lang="ID" style="tab-interval:.5in">
        <div class="WordSection1">
          <div style="text-align: center; border-bottom: 3px double #1e3a8a; padding-bottom: 12px; margin-bottom: 24px;">
            <h1 style="font-family: 'Calibri', 'Arial', sans-serif; font-size: 18pt; color: #1e3a8a; font-weight: bold; margin-bottom: 2px;">PAGURU AI Perangkat Ajar</h1>
            <p style="font-family: 'Calibri', 'Arial', sans-serif; font-size: 10pt; color: #475569; margin: 0; font-style: italic;">Dokumen Rancangan Kurikulum Merdeka Adaptif &amp; Terstruktur</p>
          </div>
          <div style="font-family: 'Calibri', 'Arial', sans-serif; text-align: left;">
            ${htmlContent}
          </div>
          <div style="margin-top: 48px; border-top: 1px solid #cbd5e1; padding-top: 10px; text-align: center; font-family: 'Calibri', sans-serif; font-size: 8.5pt; color: #94a3b8;">
            Dokumen diunduh secara instan melaui PAGURU AI - Perangkat Ajar Guru Terlengkap Indonesia.
          </div>
        </div>
      </body>
      </html>
    `;

    const blob = new Blob([docHtml], { type: 'application/msword;charset=utf-8' });
    const url = URL.createObjectURL(blob);
    const link = document.createElement("a");
    link.href = url;
    link.download = `${publishedModule.title.replace(/[\s\:\*\?\"\'\<\>\|]+/g, "_")}.doc`;
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
    URL.revokeObjectURL(url);
  };

  // Custom JSX direct Markdown Parser for ultra-clean, neat, and highly professional publications
  const renderFormattedMarkdownShare = (markdown: string) => {
    if (!markdown) return null;

    // Clean any unwanted #* symbols or duplicate markdown artifacts
    let cleanedMarkdown = markdown
      .replace(/#\*/g, '')
      .replace(/\*#/g, '')
      .replace(/[\u200B-\u200D\uFEFF]/g, '');

    const rawLines = cleanedMarkdown.split('\n');
    const lines = rawLines.filter(line => {
      const t = line.trim();
      return t !== '```' && t !== '```markdown' && t !== '```html' && !t.startsWith('<!--');
    });

    const blocks: React.ReactNode[] = [];
    let currentTableRows: string[][] = [];
    let insideTable = false;

    // Helper to format inline bold/italic/highlights and strip orphan symbols
    const formatInlineStr = (text: string) => {
      if (!text) return '';
      
      let cleaned = text
        .replace(/[\#\*\_]{3,}/g, '')
        .trim();

      const boldParts = cleaned.split('**');
      return (
        <>
          {boldParts.map((part, i) => {
            if (i % 2 === 1) {
              return (
                <strong key={i} className="font-extrabold text-blue-950 bg-blue-50/50 px-1 py-0.5 rounded border border-blue-100/30">
                  {part}
                </strong>
              );
            }
            const italicParts = part.split('_');
            return (
              <React.Fragment key={i}>
                {italicParts.map((subPart, j) => {
                  if (j % 2 === 1) {
                    return <em key={j} className="text-blue-700 font-semibold not-italic bg-amber-50/60 px-1 py-0.5 rounded border border-amber-100/20">{subPart}</em>;
                  }
                  return subPart;
                })}
              </React.Fragment>
            );
          })}
        </>
      );
    };

    const flushTable = (key: string | number) => {
      if (currentTableRows.length === 0) return;
      
      const cleanRows = currentTableRows.filter(row => {
        const isDivider = row.every(cell => /^[:\s\-|]+$/.test(cell.trim()));
        return !isDivider && row.some(cell => cell.trim().length > 0);
      });

      if (cleanRows.length > 0) {
        const headers = cleanRows[0];
        const bodyRows = cleanRows.slice(1);

        blocks.push(
          <div key={`table-${key}`} className="my-6 overflow-hidden border border-blue-200 rounded-xl shadow-lg font-sans text-xs bg-white">
            <div className="overflow-x-auto">
              <table className="w-full text-left border-collapse">
                <thead>
                  <tr className="bg-gradient-to-r from-blue-700 via-indigo-700 to-indigo-900 text-white font-bold">
                    {headers.map((cell, idx) => (
                      <th key={idx} className="px-4 py-3.5 border-b border-indigo-200 text-[11px] font-bold tracking-wide uppercase">
                        {cell.replace(/[\*\#\_]/g, '').trim()}
                      </th>
                    ))}
                  </tr>
                </thead>
                <tbody className="divide-y divide-slate-155 text-slate-700">
                  {bodyRows.map((row, rowIdx) => (
                    <tr 
                      key={rowIdx} 
                      className={`hover:bg-blue-50/20 transition-colors ${rowIdx % 2 === 1 ? 'bg-blue-50/5' : 'bg-white'}`}
                    >
                      {row.map((cell, cellIdx) => (
                        <td key={cellIdx} className="px-4 py-3 text-xs leading-relaxed font-semibold text-slate-800">
                          {formatInlineStr(cell)}
                        </td>
                      ))}
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          </div>
        );
      }
      currentTableRows = [];
      insideTable = false;
    };

    for (let i = 0; i < lines.length; i++) {
      const line = lines[i];
      const trimmed = line.trim();

      // Table parsing
      if (trimmed.startsWith('|')) {
        insideTable = true;
        let cells = line.split('|').map(c => c.trim());
        if (line.startsWith('|')) cells.shift();
        if (line.endsWith('|')) cells.pop();
        
        currentTableRows.push(cells);
        continue;
      } else {
        if (insideTable) {
          flushTable(i);
        }
      }

      if (!trimmed) {
        blocks.push(<div key={`empty-${i}`} className="h-3"></div>);
        continue;
      }

      if (trimmed === '---' || trimmed === '***' || trimmed === '___') {
        blocks.push(<hr key={`hr-${i}`} className="border-t-2 border-dashed border-slate-200 my-8" />);
        continue;
      }

      const romanMatch = trimmed.match(/^(I|II|III|IV|V|VI|VII|VIII|IX|X)\.\s+(.*)/i);
      if (romanMatch) {
        blocks.push(
          <h2 key={`roman-${i}`} className="font-display font-black text-xs md:text-sm text-indigo-950 mt-10 mb-4 border-l-4 border-blue-600 pl-4 bg-gradient-to-r from-blue-50/40 to-transparent py-2.5 rounded-r-2xl shadow-sm tracking-wide uppercase">
            {romanMatch[1]}. {romanMatch[2].replace(/[\*\#\_]/g, '')}
          </h2>
        );
        continue;
      }

      if (trimmed.startsWith('### ')) {
        const textStr = trimmed.replace('### ', '').replace(/[\*\#\_]/g, '');
        blocks.push(
          <h3 key={`h3-${i}`} className="font-display font-black text-xs md:text-sm text-blue-900 mt-8 mb-3 flex items-center gap-2 border-b border-indigo-100 pb-1.5 uppercase tracking-wider">
            <span className="w-2.5 h-2.5 rounded-full bg-gradient-to-r from-blue-500 to-indigo-600 shadow-sm shadow-blue-400 animate-pulse"></span>
            <span>{textStr}</span>
          </h3>
        );
        continue;
      }

      if (trimmed.startsWith('#### ')) {
        const textStr = trimmed.replace('#### ', '').replace(/[\*\#\_]/g, '');
        blocks.push(
          <h4 key={`h4-${i}`} className="font-display font-bold text-xs text-slate-800 mt-6 mb-2 bg-gradient-to-r from-blue-50/20 to-slate-50/30 border border-blue-50 pr-4 pl-3 py-1.5 rounded-xl inline-block shadow-sm">
            {textStr}
          </h4>
        );
        continue;
      }

      if (trimmed.startsWith('##### ')) {
        const textStr = trimmed.replace('##### ', '').replace(/[\*\#\_]/g, '');
        blocks.push(
          <h5 key={`h5-${i}`} className="font-display font-bold text-[11px] text-blue-700 mt-4 mb-1 uppercase tracking-wide">
            {textStr}
          </h5>
        );
        continue;
      }

      if (trimmed.startsWith('> ')) {
        blocks.push(
          <blockquote key={`quote-${i}`} className="border-l-4 border-blue-600 bg-gradient-to-r from-blue-50/40 to-slate-50 p-4 rounded-r-xl text-xs text-slate-705 italic my-5 font-sans shadow-inner leading-relaxed">
            {formatInlineStr(trimmed.replace('> ', ''))}
          </blockquote>
        );
        continue;
      }

      if (trimmed.startsWith('* ') || trimmed.startsWith('- ') || trimmed.startsWith('• ')) {
        const rawContent = trimmed.replace(/^[\*\-\•]\s+/, '');
        const keyValMatch = rawContent.match(/^\*\*(.*?)\*\*:(.*)/);
        if (keyValMatch) {
          blocks.push(
            <div key={`list-kv-${i}`} className="pl-6 relative my-2.5 leading-relaxed flex items-start gap-1">
              <span className="absolute left-1 top-2 w-1.5 h-1.5 rounded-full bg-blue-600 shadow-sm shadow-indigo-300"></span>
              <span className="text-xs text-slate-700">
                <strong className="font-extrabold text-slate-900 border-b border-indigo-100 pb-0.5">{keyValMatch[1]}</strong>
                <span className="text-slate-650 ml-1">{formatInlineStr(keyValMatch[2])}</span>
              </span>
            </div>
          );
        } else {
          blocks.push(
            <li key={`list-li-${i}`} className="list-none text-xs text-slate-700 pl-6 relative my-2 leading-relaxed font-normal text-left">
              <span className="absolute left-0.5 top-2.5 w-1.5 h-1.5 rounded-full bg-blue-400"></span>
              <span>{formatInlineStr(rawContent)}</span>
            </li>
          );
        }
        continue;
      }

      const numMatch = trimmed.match(/^(\d+)\.\s+(.*)/);
      if (numMatch) {
        blocks.push(
          <div key={`num-${i}`} className="flex gap-3 items-start text-xs text-slate-755 my-3 leading-relaxed pl-1 text-left">
            <span className="font-extrabold text-blue-700 shrink-0 w-5 h-5 bg-blue-50 border border-blue-100 rounded-full flex items-center justify-center text-[10px] font-mono shadow-sm">{numMatch[1]}</span>
            <span className="font-normal flex-grow pt-0.5">{formatInlineStr(numMatch[2])}</span>
          </div>
        );
        continue;
      }

      blocks.push(
        <p key={`p-${i}`} className="text-xs text-slate-700 my-3 leading-relaxed font-normal text-left">
          {formatInlineStr(trimmed)}
        </p>
      );
    }

    if (insideTable) {
      flushTable('end');
    }

    return blocks;
  };

  // Prepopulated high-fidelity curriculum projects matching screenshots
  const [projects, setProjects] = useState<TeacherProject[]>([
    {
      id: 'tsm-11',
      title: "Modul Ajar RPP: Teknik Sepeda Motor",
      level: "SMK",
      kelas: "Kelas XI",
      subject: "Teknik Sepeda Motor",
      updatedAt: "Terakhir diubah 2 jam yang lalu",
      coverImage: "https://lh3.googleusercontent.com/aida-public/AB6AXuCQbLpZIdmivZ7w3CgLp_lXWeE726q08gP1vLymWQL2eT_QvG7L1A29D7D-k0wE4k8pB9H3gLd5a7K4QvGw_1qf7L9C6h5P8L0X3C6p8L5w2y5L3c6C6w8y5L3c6",
      content: `### RENCANA PELAKSANAAN PEMBELAJARAN (MODUL AJAR)
**KURIKULUM MERDEKA**

#### I. INFORMASI UMUM
* **Nama Penyusun:** Bpk. Aris Setiawan, S.Pd.
* **Satuan Pendidikan:** SDN Merdeka 01
* **Mata Pelajaran:** Teknik Sepeda Motor
* **Fase / Kelas:** SMK / Kelas XI
* **Semester:** Ganjil
* **Alokasi Waktu:** 4 x 45 Menit
* **Topik / Bab:** Troubleshooting Sistem Injeksi Bahan Bakar (EFI)

---

#### II. KOMPETENSI INTI
* **Capaian Pembelajaran (CP):** 
  > Pada akhir fase F, peserta didik mampu melakukan diagnosis gangguan, penyetelan, reset ECU, serta perbaikan menyeluruh pada komponen kelistrikan dan mekanisme injeksi bahan bakar sepeda motor modern.

* **Tujuan Pembelajaran:**
  1. Menggunakan scanner EFI (Diagnostic Tool) untuk membaca kode kegagalan (DTC).
  2. Melakukan prosedur reset ECU secara aman sesuai manual operasional pabrikan.

* **Strategi Pembelajaran Diferensiasi:**
  * **Diferensiasi Konten:** Menggunakan representasi visual berupa diagram skematik sirkuit kelistrikan sensor, simulasi video, dan demonstrasi mesin motor hidup.
  * **Diferensiasi Proses:** Siswa bekerja dalam kelompok (tim mekanik diagnosis, tim mekanik kabel, tim analisis manual).

---

#### III. LANGKAH-LANGKAH PEMBELAJARAN
##### A. Kegiatan Pendahuluan (15 Menit)
* Berdoa bersama, memeriksa kesiapan seragam keselamatan kerja (Wearpack).
* **Apersepsi:** Guru sengaja memutus kabel sensor suhu mesin (ECT) pada salah satu motor peraga hingga lampu MIL berkedip, lalu bertanya penyebab kegagalan tersebut.

##### B. Kegiatan Inti (150 Menit)
* Siswa dikelompokkan melakukan diagnosis menggunakan manual book.
* Tiap tim bergantian menghubungkan scanner, mencatat DTC, merumuskan kemungkinan kerusakan, memperbaiki sirkuit, dan melakukan reset ECU.

##### C. Kegiatan Penutup (15 Menit)
* Refleksi kesulitan melakukan pelacakan dan menyepakati panduan dasar diagnosis cepat kelistrikan EFI.`
    },
    {
      id: "sains-6",
      title: "Modul Ajar RPP: IPA Ekosistem sekitar",
      level: "SD",
      kelas: "Kelas VI",
      subject: "Sains/IPA",
      updatedAt: "Terakhir diubah 1 hari yang lalu",
      coverImage: "https://lh3.googleusercontent.com/aida-public/AB6AXuCdLpZ5I8z_XWp9y5gLpL9C7w8X5m3P8L0C6w8P5w2y5L3c6C6w8y5L3c6",
      content: `### RENCANA PELAKSANAAN PEMBELAJARAN (MODUL AJAR)
**KURIKULUM MERDEKA**

#### I. INFORMASI UMUM
* **Nama Penyusun:** Bpk. Aris Setiawan, S.Pd.
* **Satuan Pendidikan:** SDN Merdeka 01
* **Mata Pelajaran:** Sains / IPA
* **Fase / Kelas:** Fase C / Kelas VI
* **Semester:** Ganjil
* **Alokasi Waktu:** 2 x 40 Menit
* **Topik / Bab:** Interaksi Biotik & Abiotik (Ekosistem Lingkungan)

---

#### II. KOMPETENSI INTI
* **Capaian Pembelajaran (CP):**
  > Menganalisis hubungan timbal balik antara komponen biotik (makhluk hidup) dengan abiotik di lingkungan sekitar sekolah.

* **Tujuan Pembelajaran:**
  1. Mengklasifikasikan makhluk hidup biotik dan komponen pendukung abiotik.
  2. Menyusun peta jaring-jaring makanan sederhana berdasarkan ekosistem lokal.

---

#### III. LANGKAH-LANGKAH PEMBELAJARAN
##### A. Kegiatan Pendahuluan (10 Menit)
* Sapaan hangat, apersepsi membayangkan jika tumbuhan hijau di halaman ditiadakan, lalu menceritakan tujuan kelas hari ini.

##### B. Kegiatan Inti (50 Menit)
* Eksplorasi lapangan: siswa mengamati halaman sekolah, mencatatkan serangga, tanaman, tanah, udara, dan tingkat kelembaban.
* Kelompok merakit rantai makanan secara visual menggunakan kertas tempel berwarna.

##### C. Kegiatan Penutup (20 Menit)
* Presentasi poster ekosistem, ditutup dengan kuis pemahaman singkat.`
    },
    {
      id: "math-7",
      title: "Modul Ajar RPP: Geometri Dasar",
      level: "SMP",
      kelas: "Kelas VII",
      subject: "Matematika",
      updatedAt: "Terakhir diubah 3 hari yang lalu",
      coverImage: "https://lh3.googleusercontent.com/aida-public/AB6AXuCeLpZ5I8z_XWp9y5gLpL9C7w8X5m3P8L0C6w8P5w2y5L3c6C6w8y5L3c6",
      content: `### RENCANA PELAKSANAAN PEMBELAJARAN (MODUL AJAR)
**KURIKULUM MERDEKA**

#### I. INFORMASI UMUM
* **Nama Penyusun:** Bpk. Aris Setiawan, S.Pd.
* **Satuan Pendidikan:** SDN Merdeka 01
* **Mata Pelajaran:** Matematika
* **Fase / Kelas:** Fase D / Kelas VII
* **Semester:** Ganjil
* **Alokasi Waktu:** 2 x 45 Menit
* **Topik / Bab:** Bangun Ruang Sisi Datar (Prisma & Limas)

---

#### II. KOMPETENSI INTI
* **Capaian Pembelajaran (CP):**
  > Mengidentifikasi sifat-sifat prisma dan limas, membandingkan volume, jaring-jaring serta merumuskan formulasinya.

* **Tujuan Pembelajaran:**
  1. Menjelaskan perbedaan volume prisma tegak segitiga dengan limas tegak secara terukur.
  2. Membangun model miniatur bangun sisi datar dari materi karton.

---

#### III. LANGKAH-LANGKAH PEMBELAJARAN
##### A. Kegiatan Pendahuluan (10 Menit)
* Menunjukkan bentuk atap rumah adat tradisonal Nusantara yang berbentuk prisma, menanyakan volume ruang di bawah bagian atap.

##### B. Kegiatan Inti (70 Menit)
* Siswa merangkai pola jaring-jaring prisma segitiga, membuktikan kaitan volume melalui takaran air/pasir simulasi.
* Evaluasi mandiri rumus volume.

##### C. Kegiatan Penutup (10 Menit)
* Menyimpulkan keterkaitan luas alas dengan tinggi prisma terhadap bangun ruang.`
    }
  ]);

  const handleCreateNewProject = () => {
    setActiveProject(null);
    setChatHistory([]); // Clear past context chat history for fresh generator start
    setView('generator');
  };

  const handleSelectProject = (project: TeacherProject) => {
    setActiveProject(project);
    setChatHistory([]);
    setView('generator');
  };

  const handleDiscussProject = (project: TeacherProject) => {
    setActiveProject(project);
    setChatHistory([]); // Reset fresh context chat
    setView('chat');
  };

  const handleSaveOrUpdateProject = (
    title: string, level: string, kelas: string, subject: string, content: string
  ) => {
    if (activeProject) {
      // Update existing
      setProjects(prev => prev.map(p => p.id === activeProject.id ? {
        ...p,
        title,
        level,
        kelas,
        subject,
        content,
        updatedAt: "Terakhir diubah baru saja"
      } : p));
    } else {
      // Create fresh
      const newProj: TeacherProject = {
        id: Math.random().toString(),
        title,
        level,
        kelas,
        subject,
        content,
        updatedAt: "Dibuat baru saja",
        // Preset cover dynamic based on subject matched keywords to look fabulous
        coverImage: subject.toLowerCase().includes("sepeda") || subject.toLowerCase().includes("motor") || subject.toLowerCase().includes("tsm")
          ? "https://lh3.googleusercontent.com/aida-public/AB6AXuCQbLpZIdmivZ7w3CgLp_lXWeE726q08gP1vLymWQL2eT_QvG7L1A29D7D-k0wE4k8pB9H3gLd5a7K4QvGw_1qf7L9C6h5P8L0X3C6p8L5w2y5L3c6C6w8y5L3c6"
          : subject.toLowerCase().includes("sains") || subject.toLowerCase().includes("ipa") || subject.toLowerCase().includes("biologi") || subject.toLowerCase().includes("alam")
            ? "https://lh3.googleusercontent.com/aida-public/AB6AXuCdLpZ5I8z_XWp9y5gLpL9C7w8X5m3P8L0C6w8P5w2y5L3c6C6w8y5L3c6"
            : "https://lh3.googleusercontent.com/aida-public/AB6AXuCeLpZ5I8z_XWp9y5gLpL9C7w8X5m3P8L0C6w8P5w2y5L3c6C6w8y5L3c6"
      };
      setProjects(prev => [newProj, ...prev]);
      setActiveProject(newProj);
    }
  };

  // Chat custom action listeners
  const handleAddChatMessage = (newMsg: ChatMessage) => {
    setChatHistory(prev => [...prev, newMsg]);
  };

  // Demo Project shortcut load from the landing screen
  const handleLoadDemoProject = (type: 'tsm' | 'sains' | 'math') => {
    let matchedId = type === 'tsm' ? 'tsm-11' : type === 'sains' ? 'sains-6' : 'math-7';
    let matched = projects.find(p => p.id === matchedId);
    if (matched) {
      setActiveProject(matched);
      setChatHistory([]);
      setView('chat'); // Go straight to discussion to see assets!
    } else {
      setView('dashboard');
    }
  };

  if (shareId) {
    return (
      <div className="min-h-screen bg-slate-100 flex flex-col font-sans">
        {/* Top bar */}
        <header className="h-16 bg-white border-b border-slate-200/85 shadow-sm px-6 flex justify-between items-center sticky top-0 z-50">
          <div className="flex items-center gap-3">
            <span className="p-1 px-3 bg-gradient-to-r from-blue-700 to-indigo-800 text-white text-xs rounded-xl font-bold font-display shadow-sm">PAGURU AI</span>
            <div className="text-left">
              <span className="font-display font-black text-slate-800 text-xs sm:text-sm block">Pratinjau Modul Ajar</span>
              <span className="text-[9px] uppercase font-extrabold tracking-widest text-emerald-700 bg-emerald-50 px-1.5 py-0.5 rounded border border-emerald-100 block mt-0.5 w-max leading-none">
                Tautan Publik Resmi
              </span>
            </div>
          </div>

          <div className="flex items-center gap-2">
            {publishedModule && (
              <>
                <button
                  onClick={handleImportModule}
                  className="bg-indigo-600 hover:bg-indigo-700 text-white px-3 sm:px-4 py-2 rounded-xl text-xs font-bold font-sans flex items-center gap-1.5 hover:scale-102 active:scale-98 transition-all cursor-pointer shadow-md animate-pulse"
                >
                  <PlusCircle className="w-4 h-4 shrink-0 font-bold" />
                  <span className="hidden sm:inline">Impor &amp; Edit RPP</span>
                  <span className="sm:hidden inline">Impor</span>
                </button>

                <button
                  onClick={copyShareToClipboard}
                  className="bg-white hover:bg-slate-50 text-slate-700 px-3 py-2 rounded-xl text-xs font-bold border border-slate-200 flex items-center gap-1 transition-colors cursor-pointer z-10"
                >
                  {hasCopied ? <Check className="w-4 h-4 text-emerald-600 stroke-[3]" /> : <Copy className="w-4 h-4 text-slate-500" />}
                  <span>{hasCopied ? "Disalin!" : "Salin"}</span>
                </button>

                <button
                  onClick={downloadShareText}
                  className="bg-white hover:bg-slate-50 text-slate-700 px-3 py-2 rounded-xl text-xs font-bold border border-slate-200 flex items-center gap-1 transition-colors cursor-pointer"
                  title="Unduh Format Teks (.txt)"
                >
                  <Download className="w-4 h-4 text-slate-500" />
                  <span>Format Teks (.txt)</span>
                </button>

                <button
                  onClick={downloadShareAsWord}
                  className="bg-blue-600 hover:bg-blue-700 text-white px-3 py-2 rounded-xl text-xs font-bold flex items-center gap-1.5 transition-colors cursor-pointer shadow border border-transparent"
                  title="Ekspor ke Microsoft Word (.doc)"
                >
                  <FileText className="w-4 h-4 text-white" />
                  <span>🔵 Ekspor ke Word (.doc)</span>
                </button>
              </>
            )}

            <button
              onClick={() => {
                const url = new URL(window.location.href);
                url.searchParams.delete('share');
                window.history.replaceState({}, '', url.toString());
                setShareId(null);
                setPublishedModule(null);
                setView('landing');
              }}
              className="p-2 hover:bg-slate-100 text-gray-400 hover:text-slate-800 rounded-xl transition-colors cursor-pointer"
              title="Kembali ke Beranda"
            >
              <Home className="w-4 h-4" />
            </button>
          </div>
        </header>

        {/* Loading / Error / Document */}
        <div className="flex-grow overflow-y-auto bg-slate-200 p-4 md:p-12">
          {isShareLoading && (
            <div className="max-w-md mx-auto bg-white p-8 rounded-2xl shadow-lg text-center my-12 flex flex-col items-center">
              <div className="w-12 h-12 bg-indigo-50 rounded-2xl flex items-center justify-center text-indigo-600 animate-spin mb-4">
                <Sparkles className="w-6 h-6" />
              </div>
              <p className="text-sm font-bold text-slate-800">Memuat Modul Ajar Publik...</p>
              <p className="text-xs text-gray-400 mt-1">Harap tunggu sementara draf kurikulum Merdeka diunduh.</p>
            </div>
          )}

          {shareError && (
            <div className="max-w-md mx-auto bg-white p-8 rounded-2xl shadow-lg text-center my-12">
              <div className="w-12 h-12 bg-red-50 text-red-600 rounded-2xl flex items-center justify-center mx-auto mb-4">
                <Globe className="w-6 h-6 animate-pulse" />
              </div>
              <h3 className="font-bold text-slate-800 text-sm mb-1 text-center">Tautan Tidak Valid</h3>
              <p className="text-xs text-gray-500 mb-6 font-light leading-relaxed">
                {shareError} Modul ini kemungkinan tidak dipublikasikan atau draf telah kedaluwarsa dari penyimpanan cloud.
              </p>
              <button
                onClick={() => {
                  const url = new URL(window.location.href);
                  url.searchParams.delete('share');
                  window.history.replaceState({}, '', url.toString());
                  setShareId(null);
                  setView('landing');
                }}
                className="bg-slate-900 hover:bg-slate-800 text-white font-bold text-xs px-5 py-2.5 rounded-xl transition-colors inline-block cursor-pointer"
              >
                Kembali ke Beranda PAGURU AI
              </button>
            </div>
          )}

          {publishedModule && (
            <div className="max-w-3xl bg-white min-h-[11in] mx-auto shadow-xl rounded-2xl p-6 md:p-14 text-left border border-white relative text-gray-800">
              {/* Document Header Metadata info */}
              <div className="border-b border-gray-100 pb-6 mb-8 flex flex-col sm:flex-row sm:justify-between sm:items-start gap-4 text-xs font-sans">
                <div className="text-left">
                  <span className="text-[10px] uppercase font-bold text-indigo-600 block mb-1">DATA PENYUSUN / ADMIN</span>
                  <div className="flex items-center gap-2 text-slate-800 font-extrabold text-sm mb-0.5">
                    <User className="w-4 h-4 text-slate-400" />
                    <span>{publishedModule.authorName || "Bpk. Aris Setiawan, S.Pd."}</span>
                  </div>
                  <div className="text-gray-400 font-light pl-6">
                    {publishedModule.schoolName || "SDN Merdeka 01"} • Penyusun Terverifikasi
                  </div>
                </div>

                <div className="text-left sm:text-right">
                  <span className="text-[10px] uppercase font-bold text-gray-400 block mb-1">Status Publikasi</span>
                  <div className="text-emerald-700 font-bold flex items-center sm:justify-end gap-1 mb-0.5">
                    <span className="w-2 h-2 rounded-full bg-emerald-600 animate-pulse"></span>
                    <span>Tersedia Online</span>
                  </div>
                  <div className="text-gray-400 font-light">Dipublikasi pada {publishedModule.publishedAt}</div>
                </div>
              </div>

              {renderFormattedMarkdownShare(publishedModule.content)}
            </div>
          )}
        </div>
      </div>
    );
  }

  return (
    <>
      {view === 'landing' && (
        <LandingPage 
          onEnterApp={() => setView('dashboard')}
          onSelectDemoProject={handleLoadDemoProject}
        />
      )}

      {view === 'dashboard' && (
        <Dashboard 
          projects={projects}
          onCreateNew={handleCreateNewProject}
          onSelectProject={handleSelectProject}
          onDiscussProject={handleDiscussProject}
          activeTab="dashboard"
          onChangeTab={(tab) => {
            if (tab === 'generator') handleCreateNewProject();
            else if (tab === 'chat') handleDiscussProject(projects[0]);
            else setView('dashboard');
          }}
          onLogout={() => setView('landing')}
          teacherName={teacherName}
          schoolName={schoolName}
          nip={nip}
          onUpdateProfile={(t, s, n) => {
            setTeacherName(t);
            setSchoolName(s);
            setNip(n);
          }}
        />
      )}

      {view === 'generator' && (
        <ModuleGenerator 
          onBack={() => setView('dashboard')}
          activeProject={activeProject}
          onSaveProject={handleSaveOrUpdateProject}
          teacherName={teacherName}
          schoolName={schoolName}
          nip={nip}
          onUpdateProfile={(t, s, n) => {
            setTeacherName(t);
            setSchoolName(s);
            setNip(n);
          }}
        />
      )}

      {view === 'chat' && (
        <AIChat 
          onBack={() => setView('dashboard')}
          activeProject={activeProject}
          history={chatHistory}
          onAddMessage={handleAddChatMessage}
          onSetHistory={setChatHistory}
          teacherName={teacherName}
          schoolName={schoolName}
        />
      )}
    </>
  );
}
