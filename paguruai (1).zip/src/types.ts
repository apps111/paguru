/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

export interface ModulInput {
  level: string; // SD, SMP, SMA, SMK, SLB
  kelas: string;
  semester: string; // Ganjil, Genap
  subject: string;
  topic: string;
  cp: string; // Capaian Pembelajaran
  diferensiasi: boolean;
  deepLearning: boolean;
}

export interface TeacherProject {
  id: string;
  title: string;
  level: string;
  kelas: string;
  subject: string;
  updatedAt: string;
  coverImage: string;
  content: string;
}

export interface ChatMessage {
  id: string;
  sender: 'user' | 'ai';
  text: string;
  isLoading?: boolean;
  assets?: {
    slides?: {
      title: string;
      fileName: string;
      imageUrl: string;
    };
    lkpd?: {
      title: string;
      status: string;
      imageUrl: string;
    };
    cheatsheet?: {
      title: string;
      status: string;
      imageUrl: string;
    };
  };
  suggestions?: string[];
}
