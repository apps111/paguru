/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState } from 'react';
import { 
  Sparkles, BookOpen, Clock, FileText, PlusCircle, Search, 
  Bell, ChevronRight, CheckCircle2, MessageSquare, ArrowRight,
  User, Database, Calendar, LogOut, Check, X
} from 'lucide-react';
import { TeacherProject } from '../types';

interface DashboardProps {
  projects: TeacherProject[];
  onCreateNew: () => void;
  onSelectProject: (p: TeacherProject) => void;
  onDiscussProject: (p: TeacherProject) => void;
  activeTab: string;
  onChangeTab: (tab: string) => void;
  onLogout: () => void;
  teacherName: string;
  schoolName: string;
  nip: string;
  onUpdateProfile: (teacherName: string, schoolName: string, nip: string) => void;
}

export default function Dashboard({ 
  projects, onCreateNew, onSelectProject, onDiscussProject, 
  activeTab, onChangeTab, onLogout,
  teacherName, schoolName, nip, onUpdateProfile
}: DashboardProps) {
  const [showProfileModal, setShowProfileModal] = useState(false);
  const [tempTeacherName, setTempTeacherName] = useState(teacherName);
  const [tempSchoolName, setTempSchoolName] = useState(schoolName);
  const [tempNip, setTempNip] = useState(nip);

  const openProfileModal = () => {
    setTempTeacherName(teacherName);
    setTempSchoolName(schoolName);
    setTempNip(nip);
    setShowProfileModal(true);
  };

  const saveProfile = (e: React.FormEvent) => {
    e.preventDefault();
    onUpdateProfile(tempTeacherName, tempSchoolName, tempNip);
    setShowProfileModal(false);
  };
  
  return (
    <div className="flex min-h-screen bg-slate-50 font-sans">
      
      {/* Sidebar Navigation */}
      <aside className="w-64 bg-white border-r border-slate-200/80 flex flex-col justify-between shrink-0 h-screen sticky top-0">
        <div>
          {/* Logo Brand */}
          <div className="h-16 border-b border-gray-100 flex items-center px-6 gap-2">
            <span className="p-1 px-2.5 bg-gradient-to-r from-blue-700 via-indigo-700 to-indigo-900 text-white text-xs rounded-xl font-bold font-display shadow-sm">PAGURU AI</span>
            <span className="font-display font-black text-slate-800 text-sm">⭐⭐⭐⭐⭐</span>
          </div>

          {/* Profile Section */}
          <div 
            onClick={openProfileModal}
            className="p-5 border-b border-gray-100/60 flex items-center gap-3 hover:bg-slate-50 cursor-pointer group transition-colors"
            title="Klik untuk ubah profil"
          >
            <div className="w-10 h-10 bg-gradient-to-tr from-brand-primary to-blue-400 rounded-full flex items-center justify-center text-white font-bold text-sm shadow-sm relative group-hover:scale-105 transition-transform shrink-0">
              {teacherName.substring(0, 2).toUpperCase()}
              <span className="absolute bottom-0 right-0 w-3 h-3 bg-emerald-500 border-2 border-white rounded-full"></span>
            </div>
            <div className="text-left flex-grow min-w-0">
              <div className="font-bold text-slate-800 text-xs truncate group-hover:text-brand-primary transition-colors flex items-center justify-between gap-1">
                <span className="truncate">{teacherName}</span>
                <span className="text-[9px] text-gray-400 shrink-0 font-medium group-hover:underline">Ubah</span>
              </div>
              <div className="text-[10px] text-gray-500 font-medium truncate mt-0.5">{schoolName}</div>
              {nip && <div className="text-[9px] text-gray-400 truncate mt-0.5">NIP: {nip}</div>}
              <span className="inline-block mt-1.5 bg-emerald-50 text-emerald-700 border border-emerald-200 text-[8px] font-extrabold px-1.5 py-0.5 rounded-full leading-none">
                ⭐ Akses Guru Merdeka (Gratis CSR)
              </span>
            </div>
          </div>

          {/* Navigation Items */}
          <nav className="p-4 flex flex-col gap-1.5">
            <button
              onClick={() => onChangeTab('dashboard')}
              className={`w-full flex items-center gap-3 px-4 py-3 rounded-xl font-semibold text-sm transition-all ${
                activeTab === 'dashboard' 
                  ? 'bg-brand-primary/10 text-brand-primary' 
                  : 'text-gray-600 hover:bg-slate-50 hover:text-gray-900'
              }`}
            >
              <Database className="w-4 h-4" />
              <span>Dashboard Proyek</span>
            </button>

            <button
              onClick={() => onChangeTab('generator')}
              className={`w-full flex items-center gap-3 px-4 py-3 rounded-xl font-semibold text-sm transition-all ${
                activeTab === 'generator' 
                  ? 'bg-brand-primary/10 text-brand-primary' 
                  : 'text-gray-600 hover:bg-slate-50 hover:text-gray-900'
              }`}
            >
              <Sparkles className="w-4 h-4" />
              <span>Generator Modul</span>
            </button>

            <button
              onClick={() => onChangeTab('chat')}
              className={`w-full flex items-center gap-3 px-4 py-3 rounded-xl font-semibold text-sm transition-all ${
                activeTab === 'chat' 
                  ? 'bg-brand-primary/10 text-brand-primary' 
                  : 'text-gray-600 hover:bg-slate-50 hover:text-gray-900'
              }`}
            >
              <MessageSquare className="w-4 h-4" />
              <span>AI Chat Guru</span>
            </button>
          </nav>
        </div>

        {/* Exit & Footer */}
        <div className="p-4 border-t border-gray-100 flex flex-col gap-3">
          <div className="p-3 bg-gradient-to-br from-indigo-50/50 to-blue-50/50 rounded-xl border border-indigo-100/50 text-[11px] text-gray-500">
            <span className="font-bold text-indigo-950 block mb-0.5">PAGURU AI ⭐⭐⭐⭐⭐</span>
            Perangkat Ajar Guru Terintegrasi Nasional.
          </div>
          <button 
            onClick={onLogout}
            className="w-full flex items-center gap-3 px-4 py-2.5 rounded-xl text-gray-500 hover:text-red-500 hover:bg-red-50/50 transition-colors text-xs font-semibold"
          >
            <LogOut className="w-4 h-4" />
            <span>Keluar Sesi</span>
          </button>
        </div>
      </aside>

      {/* Main Content Area */}
      <main className="flex-grow flex flex-col min-h-screen">
        
        {/* Workspace Top Header */}
        <header className="h-16 bg-white border-b border-slate-200/80 px-8 flex justify-between items-center sticky top-0 z-40">
          <div className="flex items-center gap-2">
            <h1 className="font-display font-black text-xl text-slate-900">Ruang Kerja Guru</h1>
            <span className="text-[10px] bg-emerald-50 text-emerald-700 px-2 py-0.5 rounded-md font-extrabold border border-emerald-100">
              ● ONLINE
            </span>
          </div>

          <div className="flex items-center gap-4">
            {/* Search Input */}
            <div className="relative w-64 hidden sm:block">
              <Search className="w-4 h-4 text-gray-400 absolute left-3 top-1/2 -translate-y-1/2" />
              <input 
                type="text" 
                placeholder="Cari administrasi mengajar..." 
                className="w-full pl-9 pr-4 py-1.5 rounded-xl border border-gray-200 focus:outline-none focus:border-brand-primary text-xs"
              />
            </div>

            {/* Notifications */}
            <button className="relative p-2 text-gray-500 hover:text-brand-primary hover:bg-gray-50 rounded-full transition-colors">
              <Bell className="w-4 h-4" />
              <span className="absolute top-1 right-1 w-2 h-2 bg-emerald-600 rounded-full"></span>
            </button>

            {/* Date Display */}
            <div className="flex items-center gap-1.5 text-xs text-gray-500 border border-slate-200/60 rounded-xl px-3 py-1 bg-slate-50">
              <Calendar className="w-3.5 h-3.5 text-brand-primary" />
              <span className="font-semibold">Senin, 25 Mei 2026</span>
            </div>
          </div>
        </header>

        {/* Content Container */}
        <div className="p-8 max-w-7xl mx-auto w-full flex-grow">
          {/* Greeting Promo Jumbotron */}
          <section className="bg-gradient-to-r from-brand-primary to-indigo-700 text-white rounded-[1.751rem] p-8 mb-8 relative overflow-hidden shadow-md">
            <div className="absolute top-0 right-0 w-48 h-48 bg-white/10 rounded-full blur-2xl -translate-y-1/3 translate-x-1/3"></div>
            <div className="max-w-2xl relative z-10">
              <div className="inline-flex items-center gap-1 bg-white/20 px-3 py-1 rounded-full text-[10px] font-extrabold uppercase tracking-wider mb-4 border border-white/10 leading-none">
                <Sparkles className="w-3 h-3 fill-white/10" />
                <span>Asisten Kurikulum Merdeka</span>
              </div>
              <h2 className="font-display text-2xl md:text-3xl font-extrabold mb-2 tracking-tight">
                Selamat pagi, {teacherName.split(',')[0].replace(/^(Bpk\.|Ibu\.|Pak|Bu)\s+/i, "")}!
              </h2>
              <p className="text-sm opacity-90 leading-relaxed font-light">
                Pekerjaan administrasi kelas Anda hari ini telah beres 85%. Mulai eksplorasi generator baru, draf Modul, atau diskusikan kurikulum bersama Guru AI Assistant kapan pun secara efisien.
              </p>
            </div>
          </section>

          {/* Core Analytics Cards */}
          <section className="grid grid-cols-1 md:grid-cols-3 gap-6 mb-8">
            <div className="bg-white border border-slate-200/70 rounded-2xl p-5 flex items-center justify-between shadow-sm">
              <div className="text-left font-sans">
                <span className="text-gray-400 text-[11px] font-bold uppercase tracking-wider block">Total Modul Ajar</span>
                <span className="text-3xl font-extrabold font-display text-slate-900 block mt-1">12</span>
                <span className="text-[10px] text-emerald-600 font-bold mt-1 inline-flex items-center gap-0.5">
                  ● 3 Baru Bulan Ini
                </span>
              </div>
              <div className="w-12 h-12 bg-blue-100 text-brand-primary rounded-xl flex items-center justify-center">
                <BookOpen className="w-6 h-6" />
              </div>
            </div>

            <div className="bg-white border border-slate-200/70 rounded-2xl p-5 flex items-center justify-between shadow-sm">
              <div className="text-left font-sans">
                <span className="text-gray-400 text-[11px] font-bold uppercase tracking-wider block">Presentasi &amp; Lembar Kerja</span>
                <span className="text-3xl font-extrabold font-display text-slate-900 block mt-1">8</span>
                <span className="text-[10px] text-brand-secondary font-bold mt-1 inline-flex items-center gap-0.5">
                  ✨ Terintegrasi AI Assets
                </span>
              </div>
              <div className="w-12 h-12 bg-purple-100 text-brand-secondary rounded-xl flex items-center justify-center">
                <FileText className="w-6 h-6" />
              </div>
            </div>

            <div className="bg-white border border-slate-200/70 rounded-2xl p-5 flex items-center justify-between shadow-sm">
              <div className="text-left font-sans">
                <span className="text-gray-400 text-[11px] font-bold uppercase tracking-wider block">Kesesuaian Kompetensi</span>
                <span className="text-3xl font-extrabold font-display text-slate-900 block mt-1">85%</span>
                <span className="text-[10px] text-emerald-600 font-bold mt-1 inline-flex items-center gap-0.5">
                  ✓ Sesuai 8-Dimensi Profil
                </span>
              </div>
              <div className="w-12 h-12 bg-emerald-100 text-brand-tertiary rounded-xl flex items-center justify-center">
                <CheckCircle2 className="w-6 h-6" />
              </div>
            </div>
          </section>

          {/* Action Call & Title */}
          <div className="flex justify-between items-center mb-6">
            <h3 className="font-display font-bold text-lg text-slate-800">Administrasi Mengajar Terkini</h3>
            <button 
              onClick={onCreateNew}
              className="ai-gradient text-white px-4.5 py-2.5 rounded-xl font-bold text-xs shadow-sm hover:scale-102 active:scale-98 transition-all flex items-center gap-1.5 cursor-pointer"
            >
              <PlusCircle className="w-4 h-4" />
              <span>Buat RPP Baru</span>
            </button>
          </div>

          {/* Projects Grid */}
          <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
            
            {/* Create New Prompt Card (Interactive Blank) */}
            <div 
              onClick={onCreateNew}
              className="bg-white border-2 border-dashed border-gray-200 hover:border-brand-primary/40 rounded-3xl p-6 flex flex-col items-center justify-center text-center cursor-pointer transition-colors group group-hover:bg-slate-50 min-h-[360px]"
            >
              <div className="w-14 h-14 bg-slate-50 group-hover:bg-brand-primary/5 rounded-2xl flex items-center justify-center text-gray-400 group-hover:text-brand-primary mb-4 transition-colors">
                <PlusCircle className="w-8 h-8" />
              </div>
              <h4 className="font-bold text-slate-800 text-sm font-sans mb-1">Rancang dari Nol</h4>
              <p className="text-xs text-slate-400 max-w-xs leading-relaxed font-light">
                Buka wizard untuk menyiapkan modul ajar/RPP dengan penyesuaian khusus secara otomatis.
              </p>
            </div>

            {/* Loop Projects list */}
            {projects.map((p) => (
              <div 
                key={p.id}
                className="bg-white border border-slate-200/70 rounded-3xl overflow-hidden shadow-sm hover:shadow-md transition-shadow flex flex-col h-full min-h-[360px]"
              >
                {/* Card Top Cover with dynamic gradient and labels */}
                <div className="h-40 relative bg-slate-100 shrink-0">
                  <img 
                    src={p.coverImage} 
                    alt={p.title} 
                    className="w-full h-full object-cover"
                    referrerPolicy="no-referrer"
                  />
                  <div className="absolute inset-0 bg-gradient-to-t from-black/80 via-black/25 to-transparent flex flex-col justify-end p-4">
                    <span className="bg-white/20 backdrop-blur-md text-white border border-white/20 text-[9px] font-extrabold px-2 py-0.5 rounded-full uppercase tracking-wider self-start leading-none mb-1">
                      {p.level} / {p.kelas}
                    </span>
                    <h4 className="font-display font-black text-white text-sm line-clamp-1 leading-normal">
                      {p.title}
                    </h4>
                  </div>
                </div>

                {/* Card Body Context Meta */}
                <div className="p-5 flex-grow flex flex-col justify-between font-sans">
                  <div>
                    <div className="flex items-center justify-between text-[11px] text-gray-400 mb-3">
                      <div className="flex items-center gap-1">
                        <BookOpen className="w-3.5 h-3.5 text-brand-primary" />
                        <span className="font-semibold text-slate-600">{p.subject}</span>
                      </div>
                      <div className="flex items-center gap-1">
                        <Clock className="w-3.5 h-3.5 text-gray-400" />
                        <span>{p.updatedAt}</span>
                      </div>
                    </div>
                    <p className="text-xs text-gray-500 line-clamp-3 leading-relaxed font-light mb-4">
                      Sesuai Kurikulum Merdeka Fase F, dikonfigurasi dengan pendekatan Deep Learning &amp; Asesmen HOTS terpadu.
                    </p>
                  </div>

                  {/* Dual Interaction triggers */}
                  <div className="grid grid-cols-2 gap-2 mt-2 pt-2 border-t border-gray-100">
                    <button 
                      onClick={() => onSelectProject(p)}
                      className="bg-slate-50 hover:bg-slate-100 text-slate-700 font-bold text-[11px] py-2 rounded-xl transition-all flex items-center justify-center gap-1 border border-slate-200/50 cursor-pointer"
                    >
                      <FileText className="w-3.5 h-3.5 text-slate-500" />
                      <span>Buka Modul</span>
                    </button>
                    <button 
                      onClick={() => onDiscussProject(p)}
                      className="bg-indigo-50 hover:bg-indigo-100 text-slate-800 font-bold text-[11px] py-2 rounded-xl transition-all flex items-center justify-center gap-1 border border-indigo-100 cursor-pointer"
                    >
                      <MessageSquare className="w-3.5 h-3.5 text-brand-secondary fill-brand-secondary/5" />
                      <span>Diskusi AI</span>
                    </button>
                  </div>
                </div>

              </div>
            ))}

          </div>
        </div>
      </main>

      {/* Profile Modification Modal */}
      {showProfileModal && (
        <div className="fixed inset-0 bg-slate-900/40 backdrop-blur-xs flex items-center justify-center z-50 p-4">
          <div className="bg-white rounded-3xl w-full max-w-md shadow-2xl border border-slate-100 p-6 relative animate-in fade-in zoom-in-95 duration-200">
            <button 
              onClick={() => setShowProfileModal(false)}
              className="absolute top-4 right-4 p-1.5 rounded-xl hover:bg-slate-100 text-gray-400 hover:text-gray-650 transition-colors"
            >
              <X className="w-4 h-4" />
            </button>

            <div className="flex items-center gap-3 mb-5 pb-3 border-b border-gray-100">
              <div className="w-10 h-10 bg-indigo-50 text-brand-primary rounded-xl flex items-center justify-center">
                <User className="w-5 h-5" />
              </div>
              <div className="text-left">
                <h4 className="font-display font-black text-slate-800 text-sm">Sesuaikan Identitas Mengajar</h4>
                <p className="text-[10px] text-gray-400 font-light">Data akan diterapkan otomatis ke semua modul ajar baru.</p>
              </div>
            </div>

            <form onSubmit={saveProfile} className="space-y-4 text-left">
              <div>
                <label className="block text-[10px] font-bold text-gray-500 uppercase tracking-wider mb-1.5">Nama Guru / Penyusun</label>
                <input 
                  type="text" 
                  required
                  value={tempTeacherName}
                  onChange={(e) => setTempTeacherName(e.target.value)}
                  placeholder="Contoh: Bpk. Aris Setiawan, S.Pd."
                  className="w-full px-3.5 py-2.5 rounded-xl border border-gray-300 focus:outline-none focus:border-brand-primary text-xs"
                />
              </div>

              <div>
                <label className="block text-[10px] font-bold text-gray-500 uppercase tracking-wider mb-1.5">Nama Sekolah / Institusi</label>
                <input 
                  type="text" 
                  required
                  value={tempSchoolName}
                  onChange={(e) => setTempSchoolName(e.target.value)}
                  placeholder="Contoh: SDN Merdeka 01"
                  className="w-full px-3.5 py-2.5 rounded-xl border border-gray-300 focus:outline-none focus:border-brand-primary text-xs"
                />
              </div>

              <div>
                <label className="block text-[10px] font-bold text-gray-500 uppercase tracking-wider mb-1.5">NIP / Identitas (Opsional)</label>
                <input 
                  type="text" 
                  value={tempNip}
                  onChange={(e) => setTempNip(e.target.value)}
                  placeholder="Contoh: 19880415 201212 1 002"
                  className="w-full px-3.5 py-2.5 rounded-xl border border-gray-300 focus:outline-none focus:border-brand-primary text-xs"
                />
              </div>

              <div className="flex gap-2.5 pt-4">
                <button 
                  type="button"
                  onClick={() => setShowProfileModal(false)}
                  className="flex-1 bg-slate-50 hover:bg-slate-100 text-slate-600 font-bold text-xs py-3 rounded-xl transition-all border border-slate-200/50 cursor-pointer"
                >
                  Batal
                </button>
                <button 
                  type="submit"
                  className="flex-1 bg-slate-900 hover:bg-slate-800 text-white font-bold text-xs py-3 rounded-xl transition-all flex items-center justify-center gap-1 cursor-pointer"
                >
                  <Check className="w-4 h-4" />
                  <span>Simpan Perubahan</span>
                </button>
              </div>
            </form>
          </div>
        </div>
      )}
    </div>
  );
}
