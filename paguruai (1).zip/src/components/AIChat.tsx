/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState, useRef, useEffect } from 'react';
import { 
  Send, Sparkles, ArrowLeft, BookOpen, Clock, 
  Download, Eye, Image, FileText, Share2, Award, 
  HelpCircle, CheckCircle, Info, MessageSquare
} from 'lucide-react';
import { ChatMessage, TeacherProject } from '../types';
import { generateLocalChat } from '../lib/serverlessFallback';

interface AIChatProps {
  onBack: () => void;
  activeProject: TeacherProject | null;
  history: ChatMessage[];
  onAddMessage: (msg: ChatMessage) => void;
  onSetHistory: (history: ChatMessage[]) => void;
  teacherName: string;
  schoolName: string;
}

export default function AIChat({ onBack, activeProject, history, onAddMessage, onSetHistory, teacherName, schoolName }: AIChatProps) {
  const [inputText, setInputText] = useState("");
  const [isAiLoading, setIsAiLoading] = useState(false);
  const chatBottomRef = useRef<HTMLDivElement>(null);

  // Sync scroll to bottom
  const scrollToBottom = () => {
    chatBottomRef.current?.scrollIntoView({ behavior: 'smooth' });
  };

  useEffect(() => {
    scrollToBottom();
  }, [history, isAiLoading]);

  // Handle active project setup if not discussed yet
  useEffect(() => {
    if (history.length === 0) {
      // Setup dynamic welcome based on active context
      let subjectLabel = activeProject ? activeProject.subject : "materi sekolah";
      let titleLabel = activeProject ? activeProject.title : "materi Kurikulum Merdeka";

      let initialWelcomeText = `Halo, **${teacherName}**! Saya adalah **Guru AI Assistant** milik Anda dari **${schoolName}**. 

Saya siap menemani Anda berdiskusi, merumuskan rencana kegiatan belajar, kuis interaktif, maupun rujukan modul untuk **${titleLabel}** (${subjectLabel}).

Silakan ajukan pertanyaan atau pilih salah satu rekomendasi cepat di bawah untuk langsung menyusun elemen pengajaran berkualitas tinggi!`;

      // Set matched default assets if any project matches
      let defaultAssets = undefined;
      let lcTitle = (titleLabel || "").toLowerCase();
      
      if (lcTitle.includes("sepeda") || lcTitle.includes("tsm")) {
        defaultAssets = {
          slides: {
            title: "Sistem Bahan Bakar Injeksi TSM (Troubleshooting)",
            fileName: "Struktur Sistem EFI TSM.pptx",
            imageUrl: "https://lh3.googleusercontent.com/aida-public/AB6AXuA9vAg5zp8-iJUvzpiP6AQ4y6NiQPBtU9RiykmVQw7VwBTNY0XskTpgT8dNo2eoat4BFP4p-bcODGHuq4ENYPhjN_l9QfUf_J4xRTICWAkoP1wdlGViJaekHZFzEBXwoI8OdJmYrV_sdSWo4ZEBX0kpPLBHyH269n5LTD5xwPLERXsKPd1DQZOC9PrDCDG4LbMq_z8wvdkranPS1gAu23mlvGLISyRj354SoQA3YOdKlbyK0c9QE1C_88hRDiNLp0Kz8V_xuVIe3Is"
          },
          lkpd: {
            title: "LKPD Mandiri: Sensor EFI & Troubleshooting",
            status: "TERSEDIA",
            imageUrl: "https://lh3.googleusercontent.com/aida-public/AB6AXuD6I1iRN3oXZ3UbR8RehvpUnsVhX-YRo2S72uli4gXAvii_6XpLFtWs6bbG3XDZZzK4DOd8hZK9X95qLX0pscrrVe2Q119mTzdllcdUCna3XlIFxtPxnT-CLOuJU2RwaSXJ1PboIc7puZRxco0Th_4KIJJ7xiSzOeZxU2haKfuwXy8rholiMfI8iaVVkbxtmPTxHg_seLiIp2qNsyRC74771FZvQ_oJ0EWtWCxc6ptiaCDneGk9nTyuZZsyQyn9Xm_oGRvJVoWK7Vs"
          },
          cheatsheet: {
            title: "Cheat Sheet Diagnosis DTC & Reset ECU",
            status: "TERSEDIA",
            imageUrl: "https://lh3.googleusercontent.com/aida-public/AB6AXuDS1W94dC7hEo6QxHw60Cl4c7EbH4yKGR6bkNxOYOSnJL6-NrsTHdegXieUBrR-j-VdlzKkMlaLqbzlGeIwrp3vVBMS06R6JbyD40Rnr_9EeTtMcMXXDZkwH4cLxJLBRbNCFQtNbruY7ublWYKWiD8uL2XTp0BBjnmJOWaanDKbi7v5NF2GwQ97WAUh8MkEAuJmia86ejSErc5u0NVBhLAnH2s7A7jp5WWsuPCTZy4LFVHacZnL4ywKo36yi6Bgr5jo0uVXGk-nVuE"
          }
        };
      } else if (lcTitle.includes("sains") || lcTitle.includes("ekosistem")) {
        defaultAssets = {
          slides: {
            title: "Rantai Makanan & Abiotik - Sains SD/SMP",
            fileName: "Interaksi Ekosistem Sains.pptx",
            imageUrl: "https://lh3.googleusercontent.com/aida-public/AB6AXuAZed_mzWOGdONt9tUUYzWHsS7u30gjvXp_PmLosxMniz97GzGpQ8PcHWOoyNkLozz4o3tMAP-2ROZU2y2AUbSy1ADINY-c5KXabmVK3XfQS-jJZYWCP_eYxgMEvts_up6EL0RKcpx4PCy-lfoFlFbaIrkHkVTSvaVgG2QzX-VoUFckGMCNYJeYGwUXd9fxeOLK1yA50jY4FDGF9xp50pW6xJGDq0MkWS3FNNw-n9-jJ8YF-ROatCpg7Sb4DtYoRwNEZ9zAfTLnohk"
          },
          lkpd: {
            title: "Lembar Eksplorasi Biotik Lapangan",
            status: "TERSEDIA",
            imageUrl: "https://lh3.googleusercontent.com/aida-public/AB6AXuD6I1iRN3oXZ3UbR8RehvpUnsVhX-YRo2S72uli4gXAvii_6XpLFtWs6bbG3XDZZzK4DOd8hZK9X95qLX0pscrrVe2Q119mTzdllcdUCna3XlIFxtPxnT-CLOuJU2RwaSXJ1PboIc7puZRxco0Th_4KIJJ7xiSzOeZxU2haKfuwXy8rholiMfI8iaVVkbxtmPTxHg_seLiIp2qNsyRC74771FZvQ_oJ0EWtWCxc6ptiaCDneGk9nTyuZZsyQyn9Xm_oGRvJVoWK7Vs"
          },
          cheatsheet: {
            title: "Bagan Klasifikasi Makhluk Hidup",
            status: "TERSEDIA",
            imageUrl: "https://lh3.googleusercontent.com/aida-public/AB6AXuAmHxEGJxZKkdYsSeePu0W0OWeID3mCZMCbNBZK-SxeLiaO9C3KnyR-dtE42P52-PGTqB8x_LBqtd5K0PCIpcPenucb5ROzYnTiCeRE0_dMkGMGA56fXserVO-svib4C3UgjqiirUa-zi6BHXDzUAM2O68adeAGjXN_cneD6-D1lQOGHKoScv-b84Kelop7PCZPki5Xa6YhCnv412ogxYS6xfi6HrgadJj796GXfCpFukNmZIYCI4yoM5jCnnJMJmdCv2gYWN2PXGE"
          }
        };
      } else if (lcTitle.includes("geometri") || lcTitle.includes("matematika")) {
        defaultAssets = {
          slides: {
            title: "Visualisasi Rumus Geometri Ruang",
            fileName: "Matematika Geometri Ruang.pptx",
            imageUrl: "https://lh3.googleusercontent.com/aida-public/AB6AXuAmHxEGJxZKkdYsSeePu0W0OWeID3mCZMCbNBZK-SxeLiaO9C3KnyR-dtE42P52-PGTqB8x_LBqtd5K0PCIpcPenucb5ROzYnTiCeRE0_dMkGMGA56fXserVO-svib4C3UgjqiirUa-zi6BHXDzUAM2O68adeAGjXN_cneD6-D1lQOGHKoScv-b84Kelop7PCZPki5Xa6YhCnv412ogxYS6xfi6HrgadJj796GXfCpFukNmZIYCI4yoM5jCnnJMJmdCv2gYWN2PXGE"
          },
          lkpd: {
            title: "Kuis Latihan Matematika Konstruktif",
            status: "TERSEDIA",
            imageUrl: "https://lh3.googleusercontent.com/aida-public/AB6AXuD6I1iRN3oXZ3UbR8RehvpUnsVhX-YRo2S72uli4gXAvii_6XpLFtWs6bbG3XDZZzK4DOd8hZK9X95qLX0pscrrVe2Q119mTzdllcdUCna3XlIFxtPxnT-CLOuJU2RwaSXJ1PboIc7puZRxco0Th_4KIJJ7xiSzOeZxU2haKfuwXy8rholiMfI8iaVVkbxtmPTxHg_seLiIp2qNsyRC74771FZvQ_oJ0EWtWCxc6ptiaCDneGk9nTyuZZsyQyn9Xm_oGRvJVoWK7Vs"
          },
          cheatsheet: {
            title: "Formula Cepat Volume & Sisi Bangun Ruang",
            status: "TERSEDIA",
            imageUrl: "https://lh3.googleusercontent.com/aida-public/AB6AXuDS1W94dC7hEo6QxHw60Cl4c7EbH4yKGR6bkNxOYOSnJL6-NrsTHdegXieUBrR-j-VdlzKkMlaLqbzlGeIwrp3vVBMS06R6JbyD40Rnr_9EeTtMcMXXDZkwH4cLxJLBRbNCFQtNbruY7ublWYKWiD8uL2XTp0BBjnmJOWaanDKbi7v5NF2GwQ97WAUh8MkEAuJmia86ejSErc5u0NVBhLAnH2s7A7jp5WWsuPCTZy4LFVHacZnL4ywKo36yi6Bgr5jo0uVXGk-nVuE"
          }
        };
      }

      onSetHistory([
        {
          id: 'welcome',
          sender: 'ai',
          text: initialWelcomeText,
          suggestions: activeProject?.subject === "Teknik Sepeda Motor" 
            ? ["Diagnosis Kode Kerusakan (DTC)", "Metoda Reset ECU Motor EFI", "Lembar Kerja Siswa Bengkel"]
            : ["Rancang Asesmen HOTS", "Pembelajaran Diferensiasi Konten", "Generate LKPD Siswa"],
          assets: defaultAssets
        }
      ]);
    }
  }, [activeProject, history]);

  const handleSendMessage = async (customText?: string) => {
    const textToSend = customText || inputText;
    if (!textToSend.trim()) return;

    // Attach user message
    const userMsg: ChatMessage = {
      id: Math.random().toString(),
      sender: 'user',
      text: textToSend
    };

    onAddMessage(userMsg);
    setInputText("");
    setIsAiLoading(true);

    try {
      const response = await fetch('/api/chat', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify({
          message: textToSend,
          history: history.map(h => ({ sender: h.sender, text: h.text }))
        })
      });

      if (!response.ok) {
        throw new Error("Gagal terhubung dengan server chat.");
      }

      const data = await response.json();
      
      const aiResponse: ChatMessage = {
        id: Math.random().toString(),
        sender: 'ai',
        text: data.text,
        suggestions: data.suggestions || ["Grup Diskusi Baru", "Modifikasi Aktivitas"],
        assets: data.assets // Semi-dynamic hotlinked graphics payload inside
      };

      onAddMessage(aiResponse);
    } catch (e) {
      console.warn("Using backend fallback chat: ", e);
      const data = generateLocalChat({
        message: textToSend,
        history: history.map(h => ({ sender: h.sender, text: h.text }))
      });
      
      const aiResponse: ChatMessage = {
        id: Math.random().toString(),
        sender: 'ai',
        text: data.text,
        suggestions: data.suggestions,
        assets: data.assets
      };

      onAddMessage(aiResponse);
    } finally {
      setIsAiLoading(false);
    }
  };

  // Extract all assets embedded sequentially across messages or fallbacks
  const getLatestAssets = () => {
    // Traverse backwards to pick the latest asset stack injected by the AI responses
    for (let i = history.length - 1; i >= 0; i--) {
      if (history[i].assets) {
        return history[i].assets;
      }
    }
    return undefined;
  };

  const activeAssets = getLatestAssets();

  // Custom JSX Markdown parser specifically supporting beautiful inline highlights for chats
  const renderMessageContent = (mdText: string) => {
    const lines = mdText.split('\n');
    return lines.map((line, idx) => {
      let trimmed = line.trim();

      if (trimmed.startsWith('### ')) {
        return (
          <h4 key={idx} className="font-display font-black text-slate-800 text-[13px] uppercase mt-4 mb-2 first:mt-1 tracking-wider border-b border-gray-100 pb-1 flex items-center gap-1.5">
            <span className="w-1.5 h-3 bg-brand-secondary rounded-full"></span>
            {trimmed.replace('### ', '')}
          </h4>
        );
      }

      if (trimmed.startsWith('* ') || trimmed.startsWith('- ')) {
        const textContent = trimmed.substring(2);
        if (textContent.includes('**')) {
          const parts = textContent.split('**');
          return (
            <li key={idx} className="list-none pl-5 relative my-1 text-xs text-slate-600 leading-relaxed font-light">
              <span className="absolute left-1 top-1.5 w-1 h-1 rounded-full bg-brand-secondary"></span>
              {parts.map((p, pIdx) => pIdx % 2 === 1 ? <strong key={pIdx} className="font-bold text-slate-900">{p}</strong> : p)}
            </li>
          );
        }
        return (
          <li key={idx} className="list-none pl-5 relative my-1 text-xs text-slate-600 leading-relaxed font-light">
            <span className="absolute left-1 top-1.5 w-1 h-1 rounded-full bg-slate-400"></span>
            {textContent}
          </li>
        );
      }

      if (trimmed.startsWith('> ')) {
        return (
          <blockquote key={idx} className="border-l-4 border-brand-primary bg-indigo-50/40 p-2.5 max-w-lg italic rounded-r-lg text-xs my-2 text-slate-600">
            {trimmed.replace('> ', '')}
          </blockquote>
        );
      }

      // Handle bold blocks inline
      if (trimmed.includes('**')) {
        const parts = trimmed.split('**');
        return (
          <p key={idx} className="my-1.5 text-xs text-slate-600 leading-relaxed font-light">
            {parts.map((p, pIdx) => pIdx % 2 === 1 ? <strong key={pIdx} className="font-bold text-slate-900">{p}</strong> : p)}
          </p>
        );
      }

      if (trimmed.length > 0) {
        return <p key={idx} className="my-1.5 text-xs text-slate-600 leading-relaxed font-light">{trimmed}</p>;
      }

      return <div key={idx} className="h-1"></div>;
    });
  };

  return (
    <div className="min-h-screen bg-slate-50 flex flex-col font-sans">
      
      {/* Interactive Chat Header */}
      <header className="h-16 bg-white border-b border-slate-200/80 px-6 flex justify-between items-center shrink-0">
        <div className="flex items-center gap-4">
          <button 
            onClick={onBack}
            className="p-2 hover:bg-slate-100 rounded-xl transition-colors text-gray-500 hover:text-gray-900 flex items-center gap-1.5 font-bold text-xs cursor-pointer"
          >
            <ArrowLeft className="w-4 h-4" />
            <span>Kembali ke Sesi</span>
          </button>
          
          <div className="h-5 w-px bg-slate-200"></div>

          <div className="flex items-center gap-2">
            <div className="w-8 h-8 rounded-full bg-indigo-100 flex items-center justify-center text-brand-secondary">
              <Sparkles className="w-4 h-4 text-brand-secondary fill-brand-secondary/5" />
            </div>
            <div className="text-left leading-none">
              <span className="font-bold text-slate-800 text-xs block">AI Chat Guru Indonesia</span>
              <span className="text-[10px] text-gray-400 mt-1 block">Kontekstual Kurikulum Merdeka</span>
            </div>
          </div>
        </div>

        <div className="flex items-center gap-2">
          {activeProject && (
            <span className="text-xs bg-brand-primary/10 text-brand-primary border border-brand-primary/10 px-3 py-1 rounded-xl font-bold">
              Kait: {activeProject.title}
            </span>
          )}
        </div>
      </header>

      {/* Main Body - Split Chat Panel vs AI Assets */}
      <div className="flex-grow flex flex-col lg:flex-row divide-y lg:divide-y-0 lg:divide-x divide-slate-200/80 h-[calc(100vh-64px)] overflow-hidden">
        
        {/* Left main Chat Dialogue Area */}
        <div className="flex-grow flex flex-col bg-slate-50 overflow-hidden relative">
          
          {/* Scrollable Dialogue Lists */}
          <div className="flex-grow overflow-y-auto p-6 md:p-8 flex flex-col gap-6 selection:bg-brand-primary/10">
            {history.map((m) => (
              <div 
                key={m.id}
                className={`flex gap-3 max-w-4xl ${m.sender === 'user' ? 'flex-row-reverse self-end text-right' : 'self-start text-left'}`}
              >
                {/* Custom Senders Avatars */}
                <div className={`w-9 h-9 rounded-full flex items-center justify-center shrink-0 text-xs font-bold shadow-sm ${
                  m.sender === 'user' 
                    ? 'bg-gradient-to-tr from-brand-primary to-blue-400 text-white' 
                    : 'bg-brand-secondary/15 text-brand-secondary border border-brand-secondary/10'
                }`}>
                  {m.sender === 'user' ? teacherName.substring(0, 2).toUpperCase() : <Sparkles className="w-4 h-4 text-brand-secondary fill-brand-secondary/10" />}
                </div>

                {/* Message Speech Frame */}
                <div className="flex flex-col gap-1.5 max-w-lg md:max-w-xl text-left">
                  <span className="text-[10px] font-bold text-gray-400/85">
                    {m.sender === 'user' ? teacherName : "Guru AI Assistant"}
                  </span>
                  <div className={`p-4 rounded-2xl border ${
                    m.sender === 'user' 
                      ? 'bg-brand-primary text-white border-brand-primary select-text rounded-tr-none' 
                      : 'bg-white text-gray-800 border-slate-200/70 shadow-sm rounded-tl-none'
                  }`}>
                    {m.sender === 'user' ? (
                      <p className="text-xs leading-relaxed">{m.text}</p>
                    ) : (
                      renderMessageContent(m.text)
                    )}
                  </div>

                  {/* Message Suggestions Render Panel (Intelligent dynamic chips clickables) */}
                  {m.suggestions && m.suggestions.length > 0 && (
                    <div className="flex flex-wrap gap-2 mt-2">
                      {m.suggestions.map((s, sIdx) => (
                        <button 
                          key={sIdx}
                          onClick={() => handleSendMessage(s)}
                          className="bg-white hover:bg-brand-primary/5 text-brand-primary hover:text-brand-primary border border-slate-250 py-1.5 px-3 rounded-xl text-[10px] font-bold transition-all shadow-sm flex items-center gap-1 cursor-pointer"
                        >
                          <Sparkles className="w-3 h-3 text-brand-secondary fill-brand-secondary/5 shrink-0" />
                          <span>{s}</span>
                        </button>
                      ))}
                    </div>
                  )}
                </div>

              </div>
            ))}

            {isAiLoading && (
              /* Beautiful message-bubble typing indicator */
              <div className="self-start flex gap-3">
                <div className="w-9 h-9 rounded-full bg-brand-secondary/15 text-brand-secondary border border-brand-secondary/10 flex items-center justify-center">
                  <Sparkles className="w-4 h-4 animate-pulse text-brand-secondary" />
                </div>
                <div className="flex flex-col gap-1">
                  <span className="text-[10px] font-bold text-gray-400/85">AI sedang merumuskan jawaban...</span>
                  <div className="bg-white border border-slate-200/70 p-4 rounded-2xl rounded-tl-none shadow-sm flex items-center gap-1">
                    <span className="w-1.5 h-1.5 rounded-full bg-slate-400 animate-bounce"></span>
                    <span className="w-1.5 h-1.5 rounded-full bg-slate-400 animate-bounce [animation-delay:0.2s]"></span>
                    <span className="w-1.5 h-1.5 rounded-full bg-slate-400 animate-bounce [animation-delay:0.4s]"></span>
                  </div>
                </div>
              </div>
            )}
            
            <div ref={chatBottomRef}></div>
          </div>

          {/* Prompt Form Section */}
          <div className="p-4 bg-white border-t border-slate-200/80">
            <div className="max-w-4xl mx-auto flex gap-2 relative">
              <input 
                type="text"
                value={inputText}
                onChange={(e) => setInputText(e.target.value)}
                onKeyDown={(e) => {
                  if (e.key === 'Enter') handleSendMessage();
                }}
                disabled={isAiLoading}
                placeholder="Diskusikan atau ketik permintaan Anda di sini (contoh: 'sains ekosistem' atau 'TSM EFI')..."
                className="flex-grow border border-gray-200 focus:outline-none focus:border-brand-primary rounded-xl px-4 py-3 text-xs pr-14"
              />
              <button 
                onClick={() => handleSendMessage()}
                disabled={isAiLoading || !inputText.trim()}
                className="absolute right-1.5 top-1/2 -translate-y-1/2 p-2 bg-brand-primary text-white rounded-lg hover:scale-105 active:scale-95 transition-all disabled:opacity-55 cursor-pointer"
              >
                <Send className="w-3.5 h-3.5" />
              </button>
            </div>
            <div className="text-center text-[10px] text-gray-400 mt-2">
              Guru AI Assistant terintegrasi Gemini SDK 2.5, memberikan solusi rancangan kurikulum presisi.
            </div>
          </div>

        </div>

        {/* Right Sidebar - AI Media Assets (Showstoppers visual payload showcase) */}
        <section className="w-full lg:w-[450px] bg-slate-100 flex flex-col justify-between overflow-y-auto shrink-0 h-full p-6 select-none border-l border-slate-200/85">
          <div>
            <div className="flex justify-between items-center mb-5 pb-2 border-b border-gray-250">
              <div className="text-left font-sans">
                <h3 className="font-display font-black text-xs text-slate-800 uppercase tracking-widest flex items-center gap-1.5">
                  <Award className="w-4 h-4 text-emerald-600" />
                  <span>AI Media Assets</span>
                </h3>
                <span className="text-[10px] text-gray-400 block mt-0.5 font-light">Perpustakaan materi visual kelas pendukung</span>
              </div>
              <span className="text-[9px] bg-emerald-50 text-emerald-700 font-extrabold px-2 py-0.5 rounded-md border border-emerald-150">
                BEBAS BIAYA (CSR)
              </span>
            </div>

            {!activeAssets ? (
              /* Mock standard starter tips if assets not fired yet */
              <div className="bg-white border border-slate-200/70 p-6 rounded-2xl shadow-sm text-center">
                <div className="w-12 h-12 bg-slate-50 text-slate-400 rounded-xl flex items-center justify-center mx-auto mb-4 animate-pulse">
                  <Image className="w-6 h-6" />
                </div>
                <h4 className="font-bold text-xs text-slate-800 mb-1">Eksplorasi Media Mengajar</h4>
                <p className="text-[11px] text-slate-400 leading-relaxed font-light mb-4">
                  Coba ketik obrolan bertema **Teknik Sepeda Motor (TSM)**, **Sains/IPA**, atau **Matematika** di dialog asisten untuk memicu pembuatan ringkasan PPT, LKPD, dan Cheat Sheet instan secara adaptif!
                </p>
                <div className="grid grid-cols-1 gap-2">
                  <button 
                    onClick={() => handleSendMessage("Buat draf slide presentasi motor TSM")}
                    className="text-left bg-purple-50 hover:bg-purple-100 p-2.5 rounded-xl text-[10px] font-bold text-purple-900 border border-purple-150 transition-colors cursor-pointer"
                  >
                    🔧 Coba Kejuruan TSM EFI
                  </button>
                  <button 
                    onClick={() => handleSendMessage("Rancang modul ajar Sains Ekosistem tingkat SD")}
                    className="text-left bg-emerald-50 hover:bg-emerald-100 p-2.5 rounded-xl text-[10px] font-bold text-emerald-900 border border-emerald-150 transition-colors cursor-pointer"
                  >
                    🌿 Coba Sains IPA Ekosistem
                  </button>
                </div>
              </div>
            ) : (
              /* Presentation Slides Mock elements if present */
              <div className="flex flex-col gap-5">
                
                {/* PPT Presentasi Slide Component */}
                {activeAssets.slides && (
                  <div className="bg-white border border-slate-200/80 rounded-2xl overflow-hidden shadow-sm hover:shadow-md transition-shadow">
                    <div className="p-4 bg-slate-50/80 border-b border-gray-100 flex items-center justify-between">
                      <div className="flex items-center gap-1.5 overflow-hidden">
                        <FileText className="w-4 h-4 text-brand-primary shrink-0" />
                        <span className="text-[11px] font-bold text-slate-800 truncate">{activeAssets.slides.fileName}</span>
                      </div>
                      <span className="text-[8px] bg-blue-100 text-brand-primary font-bold px-1.5 py-0.5 rounded leading-none">
                        PPTX SLIDES
                      </span>
                    </div>

                    <div className="p-3 bg-slate-900 aspect-video relative overflow-hidden group">
                      <img 
                        src={activeAssets.slides.imageUrl} 
                        alt="Slide mock" 
                        className="w-full h-full object-contain filter brightness-95"
                        referrerPolicy="no-referrer"
                      />
                      <div className="absolute inset-x-0 bottom-0 bg-gradient-to-t from-black/80 to-transparent p-2">
                        <span className="text-[9px] text-white font-bold block truncate">
                          {activeAssets.slides.title}
                        </span>
                      </div>
                    </div>

                    <div className="p-3 px-4 flex justify-between items-center bg-white">
                      <span className="text-[10px] text-gray-400 font-light">Edisi 2026 Kurikulum Merdeka</span>
                      <a 
                        href={activeAssets.slides.imageUrl}
                        target="_blank"
                        referrerPolicy="no-referrer"
                        className="bg-brand-primary hover:bg-blue-800 text-white font-bold text-[10px] px-3 py-1.5 rounded-lg flex items-center gap-1 transition-colors"
                      >
                        <Download className="w-3 h-3" />
                        <span>Unduh PPTX</span>
                      </a>
                    </div>
                  </div>
                )}

                {/* LKPD Worksheet Element */}
                {activeAssets.lkpd && (
                  <div className="bg-white border border-slate-200/80 rounded-2xl overflow-hidden shadow-sm flex items-center gap-4 p-3.5">
                    <div className="w-16 h-16 shrink-0 rounded-lg overflow-hidden bg-slate-100 relative">
                      <img 
                        src={activeAssets.lkpd.imageUrl} 
                        alt="LKPD worksheet mock" 
                        className="w-full h-full object-cover"
                        referrerPolicy="no-referrer"
                      />
                    </div>
                    <div className="flex-grow text-left overflow-hidden">
                      <span className="text-[8px] bg-emerald-100 text-[#006645] font-bold px-1.5 rounded uppercase leading-none">
                        Lembar Siswa (LKPD)
                      </span>
                      <h4 className="font-bold text-[11px] text-slate-800 mt-1 mb-0.5 truncate leading-normal">
                        {activeAssets.lkpd.title}
                      </h4>
                      <div className="flex items-center gap-3 mt-1.5">
                        <button className="text-[10px] font-bold text-brand-primary hover:underline cursor-pointer">
                          Petunjuk
                        </button>
                        <span className="text-gray-300">|</span>
                        <a 
                          href={activeAssets.lkpd.imageUrl}
                          target="_blank"
                          referrerPolicy="no-referrer"
                          className="text-[10px] font-bold text-slate-600 hover:text-slate-900 cursor-pointer"
                        >
                          Cetak Laporan
                        </a>
                      </div>
                    </div>
                  </div>
                )}

                {/* Cheat Sheet Infographics Element */}
                {activeAssets.cheatsheet && (
                  <div className="bg-white border border-slate-200/80 rounded-2xl overflow-hidden shadow-sm flex items-center gap-4 p-3.5">
                    <div className="w-16 h-16 shrink-0 rounded-lg overflow-hidden bg-slate-100 relative">
                      <img 
                        src={activeAssets.cheatsheet.imageUrl} 
                        alt="Cheatsheet mock" 
                        className="w-full h-full object-cover"
                        referrerPolicy="no-referrer"
                      />
                    </div>
                    <div className="flex-grow text-left overflow-hidden">
                      <span className="text-[8px] bg-indigo-100 text-indigo-700 font-bold px-1.5 rounded uppercase leading-none">
                        Bahan Ajar / Cheat Sheet
                      </span>
                      <h4 className="font-bold text-[11px] text-slate-800 mt-1 mb-0.5 truncate leading-normal">
                        {activeAssets.cheatsheet.title}
                      </h4>
                      <div className="flex items-center gap-3 mt-1.5 font-bold text-[10px]">
                        <button className="text-brand-primary hover:underline cursor-pointer">
                          Aktivasi
                        </button>
                        <span className="text-gray-300">|</span>
                        <a 
                          href={activeAssets.cheatsheet.imageUrl}
                          target="_blank"
                          referrerPolicy="no-referrer"
                          className="text-slate-600 hover:text-slate-900"
                        >
                          Salin Tautan
                        </a>
                      </div>
                    </div>
                  </div>
                )}

              </div>
            )}
          </div>

          <div className="bg-white/80 border border-slate-200 p-4 rounded-2xl flex items-start gap-2.5 text-slate-400 text-[10px] mt-6 leading-relaxed">
            <Info className="w-4 h-4 text-[#006645] shrink-0 mt-0.5" />
            <div className="text-left font-light">
              <span className="font-bold text-slate-700 block mb-0.5">Integrasi Rapor &amp; Kurikulum</span>
              Semua dokumen ajar siap cetak sesuai revisi terbaru Badan Standar Kurikulum &amp; Asesmen Pendidikan (BSKAP).
            </div>
          </div>
        </section>

      </div>
    </div>
  );
}
