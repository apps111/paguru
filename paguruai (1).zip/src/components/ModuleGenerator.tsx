/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState, useEffect } from 'react';
import { 
  Sparkles, ArrowLeft, ArrowRight, Check, CheckCircle, 
  Copy, Download, Edit3, Eye, FileText, Globe, RefreshCcw, 
  HelpCircle, ChevronRight, ToggleLeft, ToggleRight, Info
} from 'lucide-react';
import { ModulInput, TeacherProject } from '../types';
import { generateLocalModule } from '../lib/serverlessFallback';

export const LEVEL_CLASSES: Record<string, { value: string; label: string }[]> = {
  PAUD: [
    { value: "Kelompok KB (3-4 Tahun)", label: "Kelompok KB (Usia 3-4 Tahun)" },
    { value: "TK A (4-5 Tahun)", label: "TK A (Usia 4-5 Tahun)" },
    { value: "TK B (5-6 Tahun)", label: "TK B (Usia 5-6 Tahun)" }
  ],
  SD: [
    { value: "Kelas I", label: "Fase A - Kelas I" },
    { value: "Kelas II", label: "Fase A - Kelas II" },
    { value: "Kelas III", label: "Fase B - Kelas III" },
    { value: "Kelas IV", label: "Fase B - Kelas IV" },
    { value: "Kelas V", label: "Fase C - Kelas V" },
    { value: "Kelas VI", label: "Fase C - Kelas VI" }
  ],
  SMP: [
    { value: "Kelas VII", label: "Fase D - Kelas VII" },
    { value: "Kelas VIII", label: "Fase D - Kelas VIII" },
    { value: "Kelas IX", label: "Fase D - Kelas IX" }
  ],
  SMA: [
    { value: "Kelas X", label: "Fase E - Kelas X" },
    { value: "Kelas XI", label: "Fase F - Kelas XI" },
    { value: "Kelas XII", label: "Fase F - Kelas XII" }
  ],
  SMK: [
    { value: "Kelas X", label: "Fase E - Kelas X" },
    { value: "Kelas XI", label: "Fase F - Kelas XI" },
    { value: "Kelas XII", label: "Fase F - Kelas XII" },
    { value: "Kelas XIII", label: "Fase F - Kelas XIII (Program 4 Tahun)" }
  ],
  SLB: [
    { value: "Kelas I (SLB)", label: "Fase A - Kelas I (SLB)" },
    { value: "Kelas II (SLB)", label: "Fase A - Kelas II (SLB)" },
    { value: "Kelas III (SLB)", label: "Fase B - Kelas III (SLB)" },
    { value: "Kelas IV (SLB)", label: "Fase B - Kelas IV (SLB)" },
    { value: "Kelas V (SLB)", label: "Fase C - Kelas V (SLB)" },
    { value: "Kelas VI (SLB)", label: "Fase C - Kelas VI (SLB)" },
    { value: "Kelas VII (SLB)", label: "Fase D - Kelas VII (SLB)" },
    { value: "Kelas VIII (SLB)", label: "Fase D - Kelas VIII (SLB)" },
    { value: "Kelas IX (SLB)", label: "Fase D - Kelas IX (SLB)" },
    { value: "Kelas X (SLB)", label: "Fase E - Kelas X (SLB)" },
    { value: "Kelas XI (SLB)", label: "Fase F - Kelas XI (SLB)" },
    { value: "Kelas XII (SLB)", label: "Fase F - Kelas XII (SLB)" }
  ]
};

export const LEVEL_SUBJECTS: Record<string, { category?: string; list: string[] }[]> = {
  PAUD: [
    {
      category: "Domain Pembelajaran PAUD/TK (Fase Fondasi)",
      list: [
        "Nilai Agama dan Budi Pekerti",
        "Jati Diri",
        "Literasi Dasar",
        "STEAM Sederhana",
        "Numerasi Dasar",
        "Motorik Kasar",
        "Motorik Halus",
        "Sosial Emosional",
        "Bahasa dan Komunikasi",
        "Seni dan Kreativitas",
        "Bermain Bermakna",
        "Eksplorasi Lingkungan",
        "Kemandirian",
        "Karakter dan Kebiasaan Positif",
        "Coding Unplugged Sederhana",
        "AI Awareness Anak (Pengenalan Visual)",
        "Kegiatan Kokurikuler Terintegrasi (KKA)"
      ]
    }
  ],
  SD: [
    {
      category: "Mata Pelajaran Inti SD/MI (Fase A, B, C)",
      list: [
        "Pendidikan Pancasila",
        "Bahasa Indonesia",
        "Matematika",
        "IPAS (Ilmu Pengetahuan Alam dan Sosial)",
        "Seni Rupa (Seni Budaya)",
        "Seni Musik (Seni Budaya)",
        "Seni Tari (Seni Budaya)",
        "Seni Teater (Seni Budaya)",
        "Pendidikan Jasmani, Olahraga, dan Kesehatan (PJOK)",
        "Bahasa Inggris",
        "Pendidikan Agama dan Budi Pekerti Islam",
        "Pendidikan Karakter & Karbudi",
        "Literasi Digital SD",
        "Coding & AI Dasar Kelas Dasar",
        "Kegiatan Kokurikuler Terintegrasi (KKA)"
      ]
    },
    {
      category: "Muatan Lokal (Bahasa Daerah)",
      list: [
        "Muatan Lokal Bahasa Jawa",
        "Muatan Lokal Bahasa Sunda",
        "Muatan Lokal Bahasa Bali",
        "Muatan Lokal Bahasa Madura",
        "Muatan Lokal Bahasa Daerah Lainnya"
      ]
    }
  ],
  SMP: [
    {
      category: "Mata Pelajaran Inti SMP/MTs (Fase D)",
      list: [
        "Bahasa Indonesia",
        "Matematika",
        "Ilmu Pengetahuan Alam (IPA)",
        "Ilmu Pengetahuan Sosial (IPS)",
        "Bahasa Inggris",
        "Informatika",
        "Pendidikan Pancasila",
        "Pendidikan Jasmani, Olahraga, dan Kesehatan (PJOK)",
        "Pendidikan Agama dan Budi Pekerti",
        "Literasi Digital",
        "Coding",
        "Artificial Intelligence Dasar",
        "Kegiatan Kokurikuler Terintegrasi (KKA)",
        "Kewirausahaan Dasar",
        "Pendidikan Karakter",
        "Projek STEM / STEAM"
      ]
    },
    {
      category: "Seni dan Prakarya / Pilihan SMP",
      list: [
        "Seni Rupa",
        "Seni Musik",
        "Seni Tari",
        "Seni Teater",
        "Prakarya Kerajinan",
        "Prakarya Rekayasa",
        "Prakarya Budidaya",
        "Prakarya Pengolahan",
        "Muatan Lokal"
      ]
    }
  ],
  SMA: [
    {
      category: "Kelompok Wajib SMA/MA (Fase E - F)",
      list: [
        "Bahasa Indonesia",
        "Matematika",
        "Bahasa Inggris",
        "Pendidikan Pancasila",
        "Sejarah",
        "Informatika",
        "Pendidikan Jasmani, Olahraga, dan Kesehatan (PJOK)",
        "Pendidikan Agama dan Budi Pekerti",
        "Seni Rupa",
        "Seni Musik",
        "Seni Tari",
        "Seni Teater",
        "Prakarya dan Kewirausahaan",
        "Muatan Lokal",
        "Kegiatan Kokurikuler Terintegrasi (KKA)",
        "Coding",
        "Artificial Intelligence SMA",
        "Literasi Digital SMA",
        "Pendidikan Karakter"
      ]
    },
    {
      category: "Kelompok Pilihan - Rumpun Sains & Teknologi",
      list: [
        "Fisika",
        "Kimia",
        "Biologi",
        "Matematika Lanjut"
      ]
    },
    {
      category: "Kelompok Pilihan - Rumpun Sosial & Humaniora",
      list: [
        "Ekonomi",
        "Geografi",
        "Sosiologi",
        "Antropologi",
        "Bahasa Arab",
        "Bahasa Jepang",
        "Bahasa Mandarin",
        "Bahasa Korea",
        "Bahasa Jerman",
        "Bahasa Prancis"
      ]
    },
    {
      category: "Kelompok Pilihan - Kreatif & Komunikasi",
      list: [
        "DKV Dasar",
        "Perfilman",
        "Broadcasting",
        "Content Creator",
        "Digital Marketing"
      ]
    }
  ],
  SMK: [
    {
      category: "Mata Pelajaran Umum SMK / Kelompok A",
      list: [
        "Bahasa Indonesia",
        "Matematika",
        "Bahasa Inggris",
        "Pendidikan Pancasila",
        "Agama Islam dan Budi Pekerti",
        "Pendidikan Jasmani, Olahraga, dan Kesehatan (PJOK)",
        "Sejarah",
        "Informatika",
        "Seni Budaya",
        "Muatan Lokal",
        "Kegiatan Kokurikuler Terintegrasi (KKA)",
        "Coding Kejuruan",
        "Artificial Intelligence Industri",
        "Literasi Digital Kerja",
        "Projek Kreatif dan Kewirausahaan (PKK)"
      ]
    },
    {
      category: "Kejuruan - Teknologi & Rekayasa",
      list: [
        "Teknik Kendaraan Ringan (TKR / TKRO)",
        "Teknik Sepeda Motor (TSM)",
        "Teknik Alat Berat",
        "Teknik Pemesinan",
        "Teknik Pengelasan",
        "Teknik Fabrikasi Logam",
        "Teknik Konstruksi",
        "Teknik Pendingin & Tata Udara (AC)",
        "Teknik Instalasi Tenaga Listrik",
        "Teknik Elektronika Industri",
        "Teknik Audio Video",
        "Teknik Otomasi Industri",
        "Teknik Energi Terbarukan",
        "Teknik Robotika",
        "Teknik Dirgantara",
        "Teknik Perkapalan"
      ]
    },
    {
      category: "Kejuruan - Teknologi Informasi",
      list: [
        "Rekayasa Perangkat Lunak / PPLG",
        "Teknik Komputer dan Jaringan (TKJ)",
        "Sistem Informatika Jaringan dan Aplikasi (SIJA)",
        "Cyber Security",
        "Data Science",
        "Artificial Intelligence & Machine Learning",
        "Game Development",
        "Cloud Computing"
      ]
    },
    {
      category: "Kejuruan - Bisnis & Manajemen",
      list: [
        "Akuntansi dan Keuangan",
        "MPLB (Manajemen Perkantoran & Layanan Bisnis)",
        "Bisnis Retail",
        "Manajemen Logistik",
        "Digital Marketing",
        "E-Commerce"
      ]
    },
    {
      category: "Kejuruan - Ekonomi Kreatif",
      list: [
        "DKV (Desain Komunikasi Visual)",
        "Animasi & Pemodelan 3D",
        "Broadcasting & Pertelevisian",
        "Perfilman & Sinematografi",
        "Multimedia",
        "Fotografi",
        "Content Creator",
        "UI/UX Design"
      ]
    },
    {
      category: "Kejuruan - Pariwisata",
      list: [
        "Perhotelan",
        "Usaha Layanan Pariwisata",
        "Kuliner / Tata Boga",
        "Tata Busana / Fashion",
        "Tata Kecantikan",
        "Spa & Wellness"
      ]
    },
    {
      category: "Kejuruan - Kesehatan",
      list: [
        "Farmasi Klinis",
        "Keperawatan",
        "Teknologi Laboratorium Medik",
        "Analis Kesehatan",
        "Caregiver"
      ]
    },
    {
      category: "Kejuruan - Agribisnis",
      list: [
        "Agribisnis Tanaman",
        "Agribisnis Ternak",
        "Agriteknologi",
        "Perikanan",
        "Kehutanan"
      ]
    },
    {
      category: "Kejuruan - Maritim",
      list: [
        "Nautika Kapal",
        "Teknika Kapal",
        "Perikanan Laut"
      ]
    },
    {
      category: "Kejuruan - Seni & Industri Kreatif",
      list: [
        "Seni Musik Kejuruan",
        "Seni Pertunjukan",
        "Desain Interior",
        "Fashion Design Kejuruan"
      ]
    }
  ],
  SLB: [
    {
      category: "Layanan Kebutuhan Khusus / Adaptif SLB",
      list: [
        "Pendidikan Agama dan Budi Pekerti Adaptif",
        "Pendidikan Pancasila Adaptif",
        "Bahasa Indonesia Adaptif",
        "Matematika Fungsional",
        "IPAS Adaptif",
        "Keterampilan Hidup (Life Skill)",
        "Komunikasi Fungsional",
        "Vokasional Dasar SLB",
        "Seni dan Kreativitas Adaptif",
        "PJOK Adaptif",
        "Teknologi Asistif",
        "Literasi Dasar Adaptif",
        "Numerasi Dasar Adaptif",
        "Kemandirian Adaptif",
        "Orientasi Mobilitas",
        "Pengembangan Diri",
        "Muatan Lokal Adaptif",
        "Coding Adaptif",
        "Literasi Digital Adaptif"
      ]
    }
  ]
};

interface ModuleGeneratorProps {
  onBack: () => void;
  activeProject: TeacherProject | null;
  onSaveProject: (title: string, level: string, kelas: string, subject: string, content: string) => void;
  teacherName: string;
  schoolName: string;
  nip: string;
  onUpdateProfile: (teacherName: string, schoolName: string, nip: string) => void;
}

export default function ModuleGenerator({ 
  onBack, 
  activeProject, 
  onSaveProject,
  teacherName,
  schoolName,
  nip,
  onUpdateProfile
}: ModuleGeneratorProps) {
  // Input fields
  const [title, setTitle] = useState("Modul Ajar RPP Baru");
  const [level, setLevel] = useState("SMK");
  const [kelas, setKelas] = useState("Kelas XI");
  const [semester, setSemester] = useState("Ganjil");
  const [subject, setSubject] = useState("Teknik Sepeda Motor");
  const [topic, setTopic] = useState("Troubleshooting Sistem Injeksi Bahan Bakar (EFI)");
  const [cp, setCp] = useState(
    "Pada akhir fase F, peserta didik mampu melakukan diagnosis gangguan, penyetelan, reset ECU, serta perbaikan menyeluruh pada komponen kelistrikan dan mekanisme injeksi bahan bakar sepeda motor modern."
  );
  
  // Magic Toggles
  const [instrumentType, setInstrumentType] = useState<string>("MODUL_AJAR");
  const [ketunaan, setKetunaan] = useState<string>("Tunagrahita");
  const [diferensiasi, setDiferensiasi] = useState(true);
  const [deepLearning, setDeepLearning] = useState(true);

  // Output generated text state
  const [generatedContent, setGeneratedContent] = useState("");
  const [isLoading, setIsLoading] = useState(false);
  const [hasCopied, setHasCopied] = useState(false);
  const [hasSaved, setHasSaved] = useState(false);

  // States for publication link sharing
  const [isPublishing, setIsPublishing] = useState(false);
  const [publishedId, setPublishedId] = useState<string | null>(null);
  const [showPublishModal, setShowPublishModal] = useState(false);
  const [hasCopiedLink, setHasCopiedLink] = useState(false);

  const handlePublish = async () => {
    setIsPublishing(true);
    setShowPublishModal(true);
    setPublishedId(null);
    try {
      const response = await fetch("/api/publish", {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
        },
        body: JSON.stringify({
          title,
          level,
          kelas,
          semester,
          subject,
          topic,
          cp,
          content: generatedContent,
          authorName: teacherName,
          schoolName: schoolName
        })
      });

      if (!response.ok) {
        throw new Error("Gagal menghubungkan server publikasi.");
      }

      const data = await response.json();
      if (data.success && data.id) {
        setPublishedId(data.id);
      }
    } catch (e) {
      console.warn("Publish cloud database is inactive. Generating a simulated offline share code: ", e);
      // Generate a simulated unique base64 or alphanumeric ID so sharing works with dummy persistence
      const simulatedId = "sim_" + Math.random().toString(36).substring(2, 9);
      setPublishedId(simulatedId);
    } finally {
      setIsPublishing(false);
    }
  };

  // Sync inputs with selected project if available
  useEffect(() => {
    if (activeProject) {
      setTitle(activeProject.title);
      setLevel(activeProject.level);
      setKelas(activeProject.kelas);
      setSubject(activeProject.subject);
      setGeneratedContent(activeProject.content);
      
      // Auto-extract topic from title/content if simple
      if (activeProject.title.toLowerCase().includes("sepeda") || activeProject.title.toLowerCase().includes("tsm")) {
        setTopic("Troubleshooting Injeksi EFI");
        setCp("Peserta didik mampu melakukan diagnosis gangguan, penyetelan, reset ECU pada sistem injeksi.");
      } else if (activeProject.title.toLowerCase().includes("sains") || activeProject.title.toLowerCase().includes("ekosistem")) {
        setTopic("Eksplorasi Lingkungan Hidup Biotik & Abiotik");
        setCp("Siswa mampu menganalisis interaksi antar makhluk hidup dan lingkungannya.");
      } else if (activeProject.title.toLowerCase().includes("geometri") || activeProject.title.toLowerCase().includes("matematika")) {
        setTopic("Geometri Ruang: Sifat Sisi & Volume");
        setCp("Memahami bangun ruang dan menghitung serta membandingkan volume dalam kehidupan sehari-hari.");
      }
    }
  }, [activeProject]);

  // Auto-update valid class and subject option list triggers when level changes
  useEffect(() => {
    // Only run if we are creating a new project to avoid overwriting existing data
    if (!activeProject) {
      const validClasses = LEVEL_CLASSES[level] || [];
      if (validClasses.length > 0) {
        const isValid = validClasses.some(c => c.value === kelas);
        if (!isValid) {
          setKelas(validClasses[0].value);
        }
      }
      
      const levelSubjects = LEVEL_SUBJECTS[level] || [];
      if (levelSubjects.length > 0) {
        // Set first subject option of first group
        const firstGroup = levelSubjects[0];
        if (firstGroup && firstGroup.list.length > 0) {
          setSubject(firstGroup.list[0]);
        }
      }

      if (level === "PAUD") {
        setInstrumentType("MODUL_BERMAIN");
        setTopic("Menyayangi Tanaman & Alam Ciptaan Tuhan");
        setCp("Anak mengenali alam sekitarnya, terbiasa merawat makhluk hidup secara gembira, serta mengekspresikan karyanya lewat bahan alam.");
      } else if (level === "SLB") {
        setInstrumentType("MODUL_AJAR");
        setTopic("Mengenal Nilai Uang Fungsional");
        setCp("Peserta didik mampu mengidentifikasi serta menggunakan mata uang rupiah secara fungsional untuk kehidupan praktis sehari-hari.");
      } else if (level === "SMK") {
        setInstrumentType("MODUL_AJAR");
        setTopic("Troubleshooting Sistem Injeksi Bahan Bakar (EFI)");
        setCp("Pada akhir fase F, peserta didik mampu melakukan diagnosis gangguan, penyetelan, reset ECU serta perbaikan pada mekanisme injeksi sepeda motor modern.");
      } else {
        setInstrumentType("MODUL_AJAR");
      }
    }
  }, [level]);

  // Handle Preset quick selector options
  const applyPreset = (presetType: 'tsm' | 'sains' | 'math') => {
    if (presetType === 'tsm') {
      setTitle("Modul Ajar RPP: Teknik Sepeda Motor");
      setLevel("SMK");
      setKelas("Kelas XI");
      setSubject("Teknik Sepeda Motor");
      setTopic("Troubleshooting Sistem Injeksi Bahan Bakar (EFI)");
      setCp("Pada akhir fase F, peserta didik mampu melakukan diagnosis gangguan, penyetelan, reset ECU secara mandiri.");
    } else if (presetType === 'sains') {
      setTitle("Modul Ajar RPP: IPA Ekosistem sekitar");
      setLevel("SD");
      setKelas("Kelas VI");
      setSubject("Sains/IPA");
      setTopic("Interaksi Biotik & Abiotik (Ekosistem)");
      setCp("Menganalisis hubungan timbal balik antara komponen biotik (makhluk hidup) dengan abiotik di sekitarnya.");
    } else if (presetType === 'math') {
      setTitle("Modul Ajar RPP: Geometri Dasar");
      setLevel("SMP");
      setKelas("Kelas VII");
      setSubject("Matematika");
      setTopic("Bangun Ruang Sisi Datar");
      setCp("Mengidentifikasi sifat-sifat bangun ruang, membandingkan volume, jaring-jaring prisma dan limas secara akurat.");
    }
  };

  const generateModulAjar = async () => {
    setIsLoading(true);
    setGeneratedContent("");
    setHasSaved(false);

    try {
      const response = await fetch('/api/generate-modul', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify({
          level,
          kelas,
          semester,
          subject,
          topic,
          cp,
          diferensiasi,
          deepLearning,
          teacherName,
          schoolName,
          nip,
          instrumentType,
          ketunaan
        })
      });

      if (!response.ok) {
        throw new Error("Gagal memanggil server backend.");
      }

      const data = await response.json();
      setGeneratedContent(data.text);
    } catch (e) {
      console.warn("Using backend fallback generator: ", e);
      // Perfect front-end local generator for offline/GitHub Pages compatibility
      const localResult = generateLocalModule({
        level,
        kelas,
        semester,
        subject,
        topic,
        cp,
        diferensiasi,
        deepLearning,
        teacherName,
        schoolName,
        nip,
        instrumentType,
        ketunaan
      });
      setGeneratedContent(localResult);
    } finally {
      setIsLoading(false);
    }
  };

  const copyToClipboard = () => {
    navigator.clipboard.writeText(generatedContent);
    setHasCopied(true);
    setTimeout(() => setHasCopied(false), 2000);
  };

  const handleSave = () => {
    onSaveProject(title, level, kelas, subject, generatedContent);
    setHasSaved(true);
    setTimeout(() => setHasSaved(false), 2000);
  };

  const downloadText = () => {
    const element = document.createElement("a");
    const file = new Blob([generatedContent], {type: 'text/plain'});
    element.href = URL.createObjectURL(file);
    element.download = `${title.replace(/\s+/g, "_")}.txt`;
    document.body.appendChild(element);
    element.click();
    document.body.removeChild(element);
  };

  const downloadAsWord = () => {
    if (!generatedContent) return;
    
    // Clean unwanted symbols in output
    let cleaned = generatedContent
      .replace(/#\*/g, '')
      .replace(/\*#/g, '')
      .replace(/[\u200B-\u200D\uFEFF]/g, '');

    const lines = cleaned.split('\n');
    let htmlContent = "";
    let inTable = false;
    let inList = false;

    lines.forEach((line) => {
      let trimmed = line.trim();
      if (!trimmed) {
        if (inTable) { htmlContent += "</table></div>\n"; inTable = false; }
        if (inList) { htmlContent += "</ul>\n"; inList = false; }
        return;
      }

      // Divider rules
      if (trimmed === '---' || trimmed === '***' || trimmed === '___') {
        if (inTable) { htmlContent += "</table></div>\n"; inTable = false; }
        if (inList) { htmlContent += "</ul>\n"; inList = false; }
        htmlContent += "<hr style='border: none; border-top: 1px double #cbd5e1; margin: 18pt 0;' />\n";
        return;
      }

      // Check for table rows starting with |
      if (trimmed.startsWith('|')) {
        if (inList) { htmlContent += "</ul>\n"; inList = false; }
        let cells = trimmed.split('|').map(c => c.trim());
        if (trimmed.startsWith('|')) cells.shift();
        if (trimmed.endsWith('|')) cells.pop();

        const isDivider = cells.every(cell => /^[:\s\-|]+$/.test(cell));
        if (isDivider) return;

        if (!inTable) {
          htmlContent += "<div style='margin: 14pt 0;'><table border='1' cellspacing='0' cellpadding='8' style='border-collapse: collapse; width: 100%; font-family: \"Calibri\", \"Arial\", sans-serif; font-size: 10.5pt; border: 1.5px solid #1e40af;'>\n";
          inTable = true;
          
          htmlContent += "<tr style='background-color: #1e40af; color: #ffffff; font-weight: bold;'>\n";
          cells.forEach(c => {
            htmlContent += `<th style='border: 1.5px solid #1e40af; padding: 10px; text-align: left; font-size: 11pt;'>${c.replace(/[\*\#\_]/g, '')}</th>\n`;
          });
          htmlContent += "</tr>\n";
        } else {
          htmlContent += "<tr>\n";
          cells.forEach(c => {
            let parsedCell = c
              .replace(/\*\*(.*?)\*\*/g, '<strong>$1</strong>')
              .replace(/\_(.*?)\_/g, '<em>$1</em>');
            htmlContent += `<td style='border: 1px solid #cbd5e1; padding: 8px;'>${parsedCell}</td>\n`;
          });
          htmlContent += "</tr>\n";
        }
        return;
      } else {
        if (inTable) {
          htmlContent += "</table></div>\n";
          inTable = false;
        }
      }

      // Roman Headings
      const romanMatch = trimmed.match(/^(I|II|III|IV|V|VI|VII|VIII|IX|X)\.\s+(.*)/i);
      if (romanMatch) {
        if (inList) { htmlContent += "</ul>\n"; inList = false; }
        htmlContent += `<h2 style='font-family: "Calibri", "Arial", sans-serif; font-size: 14pt; color: #1e3a8a; border-bottom: 2px solid #1e3a8a; padding-bottom: 4px; margin-top: 22pt; margin-bottom: 10pt; text-transform: uppercase; font-weight: bold;'>${romanMatch[1]}. ${romanMatch[2].replace(/[\*\#\_]/g, '')}</h2>\n`;
        return;
      }

      // Headings
      if (trimmed.startsWith('### ')) {
        if (inList) { htmlContent += "</ul>\n"; inList = false; }
        let hText = trimmed.replace('### ', '').replace(/[\*\#\_]/g, '');
        htmlContent += `<h3 style='font-family: "Calibri", "Arial", sans-serif; font-size: 12pt; color: #0f172a; margin-top: 16pt; margin-bottom: 8pt; border-bottom: 1px solid #cbd5e1; padding-bottom: 3px; font-weight: bold;'>${hText}</h3>\n`;
        return;
      }

      if (trimmed.startsWith('#### ')) {
        if (inList) { htmlContent += "</ul>\n"; inList = false; }
        let hText = trimmed.replace('#### ', '').replace(/[\*\#\_]/g, '');
        htmlContent += `<h4 style='font-family: "Calibri", "Arial", sans-serif; font-size: 11pt; color: #1e40af; margin-top: 12pt; margin-bottom: 6pt; font-weight: bold; background-color: #f1f5f9; padding: 5px 10px; border-radius: 4px; display: inline-block;'>${hText}</h4>\n`;
        return;
      }

      if (trimmed.startsWith('##### ')) {
        if (inList) { htmlContent += "</ul>\n"; inList = false; }
        let hText = trimmed.replace('##### ', '').replace(/[\*\#\_]/g, '');
        htmlContent += `<h5 style='font-family: "Calibri", "Arial", sans-serif; font-size: 10.5pt; color: #475569; margin-top: 10pt; margin-bottom: 4pt; font-weight: bold; text-transform: uppercase;'>${hText}</h5>\n`;
        return;
      }

      // Quotes
      if (trimmed.startsWith('> ')) {
        if (inList) { htmlContent += "</ul>\n"; inList = false; }
        let qText = trimmed.replace('> ', '')
          .replace(/\*\*(.*?)\*\*/g, '<strong>$1</strong>')
          .replace(/\_(.*?)\_/g, '<em>$1</em>');
        htmlContent += `<div style='border-left: 4px solid #1e40af; background-color: #eff6ff; padding: 10px 15px; margin: 12pt 0; font-style: italic; font-family: "Calibri", "Arial", sans-serif; font-size: 10pt; color: #1e293b;'>${qText}</div>\n`;
        return;
      }

      // List Elements
      if (trimmed.startsWith('* ') || trimmed.startsWith('- ') || trimmed.startsWith('• ')) {
        if (!inList) {
          htmlContent += "<ul style='font-family: \"Calibri\", \"Arial\", sans-serif; font-size: 10.5pt; margin-left: 20px; margin-top: 6pt; margin-bottom: 6pt;'>\n";
          inList = true;
        }
        let liText = trimmed.replace(/^[\*\-\•]\s+/, '');
        let keyValMatch = liText.match(/^\*\*(.*?)\*\*:(.*)/);
        if (keyValMatch) {
          htmlContent += `<li style='margin-bottom: 5px;'><strong>${keyValMatch[1]}</strong>: ${keyValMatch[2].replace(/\*\*(.*?)\*\*/g, '<strong>$1</strong>').replace(/\_(.*?)\_/g, '<em>$1</em>')}</li>\n`;
        } else {
          htmlContent += `<li style='margin-bottom: 5px;'>${liText.replace(/\*\*(.*?)\*\*/g, '<strong>$1</strong>').replace(/\_(.*?)\_/g, '<em>$1</em>')}</li>\n`;
        }
        return;
      }

      // Numbered List
      const numMatch = trimmed.match(/^(\d+)\.\s+(.*)/);
      if (numMatch) {
        if (inList) { htmlContent += "</ul>\n"; inList = false; }
        let numText = numMatch[2]
          .replace(/\*\*(.*?)\*\*/g, '<strong>$1</strong>')
          .replace(/\_(.*?)\_/g, '<em>$1</em>');
        htmlContent += `<p style='font-family: "Calibri", "Arial", sans-serif; font-size: 10.5pt; margin-left: 20px; line-height: 1.45; margin-top: 6px; margin-bottom: 6px;'><strong>${numMatch[1]}.</strong> ${numText}</p>\n`;
        return;
      }

      // Default Paragraphs
      if (inList) { htmlContent += "</ul>\n"; inList = false; }
      let pParsed = trimmed
        .replace(/\*\*(.*?)\*\*/g, '<strong>$1</strong>')
        .replace(/\_(.*?)\_/g, '<em>$1</em>');
      htmlContent += `<p style='font-family: "Calibri", "Arial", sans-serif; font-size: 10.5pt; line-height: 1.45; color: #1e293b; margin-top: 6pt; margin-bottom: 6pt;'>${pParsed}</p>\n`;
    });

    if (inTable) htmlContent += "</table></div>\n";
    if (inList) htmlContent += "</ul>\n";

    // Build the Word container template
    const docHtml = `
      <html xmlns:o='urn:schemas-microsoft-com:office:office' xmlns:w='urn:schemas-microsoft-com:office:word' xmlns='http://www.w3.org/TR/REC-html40'>
      <head>
        <title>${title}</title>
        <!--[if gte mso 9]>
        <xml>
          <w:WordDocument>
            <w:View>Print</w:View>
            <w:Zoom>100</w:Zoom>
            <w:DoNotOptimizeForBrowser/>
          </w:WordDocument>
        </xml>
        <![endif]-->
        <meta charset="utf-8">
        <style>
          @page WordSection1 {
            size: 8.27in 11.69in; /* A4 size */
            margin: 1.0in 1.0in 1.0in 1.0in;
            mso-header-margin: .5in;
            mso-footer-margin: .5in;
            mso-paper-source: 0;
          }
          div.WordSection1 {
            page: WordSection1;
          }
        </style>
      </head>
      <body lang="ID" style="tab-interval:.5in">
        <div class="WordSection1">
          <div style="text-align: center; border-bottom: 3px double #1e3a8a; padding-bottom: 12px; margin-bottom: 24px;">
            <h1 style="font-family: 'Calibri', 'Arial', sans-serif; font-size: 18pt; color: #1e3a8a; font-weight: bold; margin-bottom: 2px;">PAGURU AI Perangkat Ajar</h1>
            <p style="font-family: 'Calibri', 'Arial', sans-serif; font-size: 10pt; color: #475569; margin: 0; font-style: italic;">Dokumen Rancangan Kurikulum Merdeka Adaptif &amp; Terstruktur</p>
          </div>
          <div style="font-family: 'Calibri', 'Arial', sans-serif; text-align: left;">
            ${htmlContent}
          </div>
          <div style="margin-top: 48px; border-top: 1px solid #cbd5e1; padding-top: 10px; text-align: center; font-family: 'Calibri', sans-serif; font-size: 8.5pt; color: #94a3b8;">
            Dokumen diunduh secara instan melaui PAGURU AI - Perangkat Ajar Guru Terlengkap Indonesia.
          </div>
        </div>
      </body>
      </html>
    `;

    const blob = new Blob([docHtml], { type: 'application/msword;charset=utf-8' });
    const url = URL.createObjectURL(blob);
    const link = document.createElement("a");
    link.href = url;
    link.download = `${title.replace(/[\s\:\*\?\"\'\<\>\|]+/g, "_")}.doc`;
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
    URL.revokeObjectURL(url);
  };

  // Custom JSX direct Markdown Parser for ultra-clean, neat, and highly professional publications
  const renderFormattedMarkdown = (markdown: string) => {
    if (!markdown) return null;

    // Clean any unwanted #* symbols or duplicate markdown artifacts
    let cleanedMarkdown = markdown
      .replace(/#\*/g, '')
      .replace(/\*#/g, '')
      .replace(/[\u200B-\u200D\uFEFF]/g, '');

    const rawLines = cleanedMarkdown.split('\n');
    const lines = rawLines.filter(line => {
      const t = line.trim();
      return t !== '```' && t !== '```markdown' && t !== '```html' && !t.startsWith('<!--');
    });

    const blocks: React.ReactNode[] = [];
    let currentTableRows: string[][] = [];
    let insideTable = false;

    // Helper to format inline bold/italic/highlights and strip orphan symbols
    const formatInlineStr = (text: string) => {
      if (!text) return '';
      
      let cleaned = text
        .replace(/[\#\*\_]{3,}/g, '')
        .trim();

      const boldParts = cleaned.split('**');
      return (
        <>
          {boldParts.map((part, i) => {
            if (i % 2 === 1) {
              return (
                <strong key={i} className="font-extrabold text-blue-950 bg-blue-50/50 px-1 py-0.5 rounded border border-blue-100/30">
                  {part}
                </strong>
              );
            }
            const italicParts = part.split('_');
            return (
              <React.Fragment key={i}>
                {italicParts.map((subPart, j) => {
                  if (j % 2 === 1) {
                    return <em key={j} className="text-blue-700 font-semibold not-italic bg-amber-50/60 px-1 py-0.5 rounded border border-amber-100/20">{subPart}</em>;
                  }
                  return subPart;
                })}
              </React.Fragment>
            );
          })}
        </>
      );
    };

    const flushTable = (key: string | number) => {
      if (currentTableRows.length === 0) return;
      
      const cleanRows = currentTableRows.filter(row => {
        const isDivider = row.every(cell => /^[:\s\-|]+$/.test(cell.trim()));
        return !isDivider && row.some(cell => cell.trim().length > 0);
      });

      if (cleanRows.length > 0) {
        const headers = cleanRows[0];
        const bodyRows = cleanRows.slice(1);

        blocks.push(
          <div key={`table-${key}`} className="my-6 overflow-hidden border border-blue-200 rounded-xl shadow-lg font-sans text-xs bg-white">
            <div className="overflow-x-auto">
              <table className="w-full text-left border-collapse">
                <thead>
                  <tr className="bg-gradient-to-r from-blue-700 via-indigo-700 to-indigo-900 text-white font-bold">
                    {headers.map((cell, idx) => (
                      <th key={idx} className="px-4 py-3.5 border-b border-indigo-200 text-[11px] font-bold tracking-wide uppercase">
                        {cell.replace(/[\*\#\_]/g, '').trim()}
                      </th>
                    ))}
                  </tr>
                </thead>
                <tbody className="divide-y divide-slate-150 text-slate-700">
                  {bodyRows.map((row, rowIdx) => (
                    <tr 
                      key={rowIdx} 
                      className={`hover:bg-blue-50/20 transition-colors ${rowIdx % 2 === 1 ? 'bg-blue-50/5' : 'bg-white'}`}
                    >
                      {row.map((cell, cellIdx) => (
                        <td key={cellIdx} className="px-4 py-3 text-xs leading-relaxed font-semibold text-slate-800">
                          {formatInlineStr(cell)}
                        </td>
                      ))}
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          </div>
        );
      }
      currentTableRows = [];
      insideTable = false;
    };

    for (let i = 0; i < lines.length; i++) {
      const line = lines[i];
      const trimmed = line.trim();

      // Table parsing
      if (trimmed.startsWith('|')) {
        insideTable = true;
        let cells = line.split('|').map(c => c.trim());
        if (line.startsWith('|')) cells.shift();
        if (line.endsWith('|')) cells.pop();
        
        currentTableRows.push(cells);
        continue;
      } else {
        if (insideTable) {
          flushTable(i);
        }
      }

      if (!trimmed) {
        blocks.push(<div key={`empty-${i}`} className="h-3"></div>);
        continue;
      }

      if (trimmed === '---' || trimmed === '***' || trimmed === '___') {
        blocks.push(<hr key={`hr-${i}`} className="border-t-2 border-dashed border-slate-200 my-8" />);
        continue;
      }

      const romanMatch = trimmed.match(/^(I|II|III|IV|V|VI|VII|VIII|IX|X)\.\s+(.*)/i);
      if (romanMatch) {
        blocks.push(
          <h2 key={`roman-${i}`} className="font-display font-black text-xs md:text-sm text-indigo-950 mt-10 mb-4 border-l-4 border-blue-600 pl-4 bg-gradient-to-r from-blue-50/40 to-transparent py-2.5 rounded-r-2xl shadow-sm tracking-wide uppercase">
            {romanMatch[1]}. {romanMatch[2].replace(/[\*\#\_]/g, '')}
          </h2>
        );
        continue;
      }

      if (trimmed.startsWith('### ')) {
        const textStr = trimmed.replace('### ', '').replace(/[\*\#\_]/g, '');
        blocks.push(
          <h3 key={`h3-${i}`} className="font-display font-black text-xs md:text-sm text-blue-900 mt-8 mb-3 flex items-center gap-2 border-b border-indigo-100 pb-1.5 uppercase tracking-wider">
            <span className="w-2.5 h-2.5 rounded-full bg-gradient-to-r from-blue-500 to-indigo-600 shadow-sm shadow-blue-400 animate-pulse"></span>
            <span>{textStr}</span>
          </h3>
        );
        continue;
      }

      if (trimmed.startsWith('#### ')) {
        const textStr = trimmed.replace('#### ', '').replace(/[\*\#\_]/g, '');
        blocks.push(
          <h4 key={`h4-${i}`} className="font-display font-bold text-xs text-slate-800 mt-6 mb-2 bg-gradient-to-r from-blue-50/20 to-slate-50/30 border border-blue-50 pr-4 pl-3 py-1.5 rounded-xl inline-block shadow-sm">
            {textStr}
          </h4>
        );
        continue;
      }

      if (trimmed.startsWith('##### ')) {
        const textStr = trimmed.replace('##### ', '').replace(/[\*\#\_]/g, '');
        blocks.push(
          <h5 key={`h5-${i}`} className="font-display font-bold text-[11px] text-blue-700 mt-4 mb-1 uppercase tracking-wide">
            {textStr}
          </h5>
        );
        continue;
      }

      if (trimmed.startsWith('> ')) {
        blocks.push(
          <blockquote key={`quote-${i}`} className="border-l-4 border-blue-600 bg-gradient-to-r from-blue-50/40 to-slate-50 p-4 rounded-r-xl text-xs text-slate-700 italic my-5 font-sans shadow-inner leading-relaxed">
            {formatInlineStr(trimmed.replace('> ', ''))}
          </blockquote>
        );
        continue;
      }

      if (trimmed.startsWith('* ') || trimmed.startsWith('- ') || trimmed.startsWith('• ')) {
        const rawContent = trimmed.replace(/^[\*\-\•]\s+/, '');
        const keyValMatch = rawContent.match(/^\*\*(.*?)\*\*:(.*)/);
        if (keyValMatch) {
          blocks.push(
            <div key={`list-kv-${i}`} className="pl-6 relative my-2.5 leading-relaxed flex items-start gap-1">
              <span className="absolute left-1 top-2 w-1.5 h-1.5 rounded-full bg-blue-600 shadow-sm shadow-indigo-300"></span>
              <span className="text-xs text-slate-700">
                <strong className="font-extrabold text-slate-900 border-b border-indigo-100 pb-0.5">{keyValMatch[1]}</strong>
                <span className="text-slate-650 ml-1">{formatInlineStr(keyValMatch[2])}</span>
              </span>
            </div>
          );
        } else {
          blocks.push(
            <li key={`list-li-${i}`} className="list-none text-xs text-slate-700 pl-6 relative my-2 leading-relaxed font-normal text-left">
              <span className="absolute left-0.5 top-2.5 w-1.5 h-1.5 rounded-full bg-blue-400"></span>
              <span>{formatInlineStr(rawContent)}</span>
            </li>
          );
        }
        continue;
      }

      const numMatch = trimmed.match(/^(\d+)\.\s+(.*)/);
      if (numMatch) {
        blocks.push(
          <div key={`num-${i}`} className="flex gap-3 items-start text-xs text-slate-755 my-3 leading-relaxed pl-1 text-left">
            <span className="font-extrabold text-blue-700 shrink-0 w-5 h-5 bg-blue-50 border border-blue-100 rounded-full flex items-center justify-center text-[10px] font-mono shadow-sm">{numMatch[1]}</span>
            <span className="font-normal flex-grow pt-0.5">{formatInlineStr(numMatch[2])}</span>
          </div>
        );
        continue;
      }

      blocks.push(
        <p key={`p-${i}`} className="text-xs text-slate-700 my-3 leading-relaxed font-normal text-left">
          {formatInlineStr(trimmed)}
        </p>
      );
    }

    if (insideTable) {
      flushTable('end');
    }

    return blocks;
  };

  return (
    <div className="min-h-screen bg-slate-50 flex flex-col font-sans">
      
      {/* Utility Back Header */}
      <header className="h-16 bg-white border-b border-slate-200/80 px-6 flex justify-between items-center shrink-0">
        <div className="flex items-center gap-4">
          <button 
            onClick={onBack}
            className="p-2 hover:bg-slate-100 rounded-xl transition-colors text-gray-500 hover:text-gray-900 flex items-center gap-1.5 font-bold text-xs cursor-pointer"
          >
            <ArrowLeft className="w-4 h-4" />
            <span>Kembali ke Dashboard</span>
          </button>
          
          <div className="h-5 w-px bg-slate-200"></div>

          <div className="flex items-center gap-2">
            <input 
              type="text"
              value={title}
              onChange={(e) => setTitle(e.target.value)}
              className="bg-transparent hover:bg-slate-50 focus:bg-white text-sm font-extrabold text-slate-800 px-2.5 py-1 rounded-lg border border-transparent focus:border-slate-200 focus:outline-none w-64 md:w-80"
            />
          </div>
        </div>

        <div className="flex items-center gap-2 font-sans">
          {generatedContent && (
            <>
              <button 
                onClick={handleSave}
                className="bg-white hover:bg-slate-50 text-slate-800 px-4 py-2 rounded-xl text-xs font-bold border border-slate-200 flex items-center gap-1.5 transition-colors cursor-pointer"
              >
                {hasSaved ? <Check className="w-4 h-4 text-emerald-600 stroke-[3]" /> : <CheckCircle className="w-4 h-4 text-slate-500" />}
                <span>{hasSaved ? "Tersimpan" : "Simpan Proyek"}</span>
              </button>

              <button 
                onClick={handlePublish}
                className="bg-indigo-600 hover:bg-indigo-700 text-white px-4 py-2 rounded-xl text-xs font-bold flex items-center gap-1.5 hover:scale-102 active:scale-98 transition-all cursor-pointer shadow-md"
              >
                <Globe className="w-4 h-4 shrink-0" />
                <span>Bagikan Link Publik</span>
              </button>

              <button 
                onClick={downloadText}
                className="bg-slate-700 hover:bg-slate-800 text-white px-3 sm:px-4 py-2 rounded-xl text-xs font-bold transition-transform active:scale-95 flex items-center gap-1.5 cursor-pointer border border-transparent"
                title="Ekspor sebagai dokumen teks biasa"
              >
                <Download className="w-3.5 h-3.5" />
                <span>Format Teks (.txt)</span>
              </button>

              <button 
                onClick={downloadAsWord}
                className="bg-blue-600 hover:bg-blue-700 text-white px-3 sm:px-4 py-2 rounded-xl text-xs font-bold transition-transform active:scale-95 flex items-center gap-1.5 cursor-pointer border border-transparent shadow"
                title="Ekspor dokumen lengkap ke Microsoft Word"
              >
                <FileText className="w-3.5 h-3.5" />
                <span>🔵 Ekspor ke Word (.doc)</span>
              </button>
            </>
          )}
        </div>
      </header>

      {/* Main Container Layout */}
      <div className="flex-grow flex flex-col lg:flex-row divide-y lg:divide-y-0 lg:divide-x divide-slate-200/80 h-[calc(100vh-64px)] overflow-hidden">
        
        {/* Left Input Configuration Column */}
        <section className="w-full lg:w-[420px] bg-white p-6 flex flex-col justify-between overflow-y-auto shrink-0">
          <div className="flex flex-col gap-5">
            <div>
              <h3 className="font-display font-extrabold text-sm text-slate-800 mb-1">Konfigurasi RPP &amp; Modul Ajar</h3>
              <p className="text-[11px] text-gray-400">Atur parameter dan nyalakan fitur kecerdasan akademik di bawah.</p>
            </div>

            {/* Smart preset templates fast load */}
            <div className="bg-slate-50 border border-slate-100 rounded-2xl p-4">
              <span className="text-[10px] uppercase font-extrabold tracking-wider text-slate-400 block mb-2">Preset Modul Sekolah</span>
              <div className="grid grid-cols-3 gap-2">
                <button 
                  onClick={() => applyPreset('tsm')}
                  type="button" 
                  className={`text-[10px] font-bold p-1.5 py-2.5 rounded-xl border text-center transition-all cursor-pointer ${
                    subject === "Teknik Sepeda Motor" 
                      ? 'bg-brand-primary/10 border-brand-primary/30 text-brand-primary' 
                      : 'bg-white border-gray-200 text-gray-600 hover:bg-gray-100'
                  }`}
                >
                  ⚙ Kejuruan TSM
                </button>
                <button 
                  onClick={() => applyPreset('sains')}
                  type="button" 
                  className={`text-[10px] font-bold p-1.5 py-2.5 rounded-xl border text-center transition-all cursor-pointer ${
                    subject.startsWith("Sains") || subject.startsWith("IPA")
                      ? 'bg-emerald-50 border-emerald-250 text-emerald-700' 
                      : 'bg-white border-gray-200 text-gray-600 hover:bg-gray-100'
                  }`}
                >
                  🌿 IPA Sains
                </button>
                <button 
                  onClick={() => applyPreset('math')}
                  type="button" 
                  className={`text-[10px] font-bold p-1.5 py-2.5 rounded-xl border text-center transition-all cursor-pointer ${
                    subject === "Matematika" 
                      ? 'bg-blue-50 border-blue-200 text-blue-700' 
                      : 'bg-white border-gray-200 text-gray-600 hover:bg-gray-100'
                  }`}
                >
                  📐 Matematika
                </button>
              </div>
            </div>

            {/* Form Fields */}
            <div className="flex flex-col gap-3 font-sans">
              
              {/* Dynamic Column: Teacher & School Reference */}
              <div className="bg-indigo-50/50 p-3.5 rounded-2xl border border-indigo-100/60 text-left">
                <span className="text-[10px] font-bold text-brand-primary uppercase tracking-wider block mb-2">Identitas RPP (Penyusun)</span>
                <div className="grid grid-cols-2 gap-2.5">
                  <div className="flex flex-col gap-0.5">
                    <label className="text-[9px] font-bold text-gray-500">Nama Guru</label>
                    <input 
                      type="text"
                      value={teacherName}
                      onChange={(e) => onUpdateProfile(e.target.value, schoolName, nip)}
                      placeholder="Nama Guru"
                      className="border border-gray-200 rounded-xl px-2.5 py-1.5 text-[11px] focus:outline-none focus:border-indigo-400 bg-white font-medium"
                    />
                  </div>
                  <div className="flex flex-col gap-0.5">
                    <label className="text-[9px] font-bold text-gray-500">Sekolah / Satuan</label>
                    <input 
                      type="text"
                      value={schoolName}
                      onChange={(e) => onUpdateProfile(teacherName, e.target.value, nip)}
                      placeholder="Nama Sekolah"
                      className="border border-gray-200 rounded-xl px-2.5 py-1.5 text-[11px] focus:outline-none focus:border-indigo-400 bg-white font-medium"
                    />
                  </div>
                </div>
              </div>

              {/* Row: Tipe Perangkat/Instrumen Pembelajaran */}
              <div className="flex flex-col gap-1 text-left">
                <label className="text-[11px] font-bold text-gray-700 flex items-center gap-1">
                  ✨ Jenis Instrumen Perangkat Pembelajaran
                </label>
                <select 
                  value={instrumentType} 
                  onChange={(e) => {
                    const selectedVal = e.target.value;
                    setInstrumentType(selectedVal);
                    // Match document title
                    if (selectedVal === "MODUL_AJAR" || selectedVal === "MODUL_BERMAIN") {
                      setTitle((selectedVal === "MODUL_BERMAIN" ? "Modul Bermain: " : "Modul Ajar RPP: ") + topic);
                    } else if (selectedVal === "ATP") {
                      setTitle("Alur Tujuan Pembelajaran (ATP): " + topic);
                    } else if (selectedVal === "LKPD") {
                      setTitle("LKPD Mandiri: " + topic);
                    } else if (selectedVal === "ASESMEN" || selectedVal === "ASESMEN_PERKEMBANGAN") {
                      setTitle((selectedVal === "ASESMEN_PERKEMBANGAN" ? "Asesmen Perkembangan: " : "Instrumen Asesmen & Soal HOTS: ") + topic);
                    } else if (selectedVal === "BAHAN_AJAR" || selectedVal === "RAPOR_PAUD") {
                      setTitle((selectedVal === "RAPOR_PAUD" ? "Draf Narasi Rapor PAUD: " : "Bahan Bacaan Ringkas: ") + topic);
                    } else if (selectedVal === "KKTP_GLOSARIUM" || selectedVal === "ANECDOTAL_RECORD") {
                      setTitle((selectedVal === "ANECDOTAL_RECORD" ? "Catatan Anekdot: " : "KKTP & Glosarium: ") + topic);
                    } else if (selectedVal === "OBSERVASI_ANAK") {
                      setTitle("Panduan Observasi: " + topic);
                    } else if (selectedVal === "DEEP_LEARNING_PAUD") {
                      setTitle("Deep Learning PAUD: " + topic);
                    }
                  }}
                  className="border-2 border-indigo-100 rounded-xl px-3 py-2.5 text-xs focus:outline-none focus:border-brand-primary bg-indigo-50/10 font-bold text-slate-800 cursor-pointer transition-all hover:bg-slate-50"
                >
                  {level === "PAUD" ? (
                    <>
                      <option value="MODUL_BERMAIN">🧸 Modul Bermain Bermakna (PAUD/TK)</option>
                      <option value="ASESMEN_PERKEMBANGAN">📊 Rubrik Asesmen Perkembangan Anak</option>
                      <option value="ANECDOTAL_RECORD">📝 Anecdotal Record (Catatan Kejadian Anekdot)</option>
                      <option value="RAPOR_PAUD">📋 Narasi Rapor PAUD Terbaru (Deskripsi Capaian)</option>
                      <option value="OBSERVASI_ANAK">🔍 Panduan Observasi Perkembangan Anak</option>
                      <option value="DEEP_LEARNING_PAUD">💡 Draf Deep Learning Anak Usia Dini</option>
                    </>
                  ) : (
                    <>
                      <option value="MODUL_AJAR">📥 Modul Ajar (RPP Master Kurikulum Merdeka)</option>
                      <option value="ATP">📈 Alur Tujuan Pembelajaran (ATP)</option>
                      <option value="LKPD">📝 Lembar Kerja Peserta Didik (LKPD - Student Worksheet)</option>
                      <option value="ASESMEN">📊 Instrumen Asesmen (Diagnostik, Formatif &amp; Sumatif HOTS)</option>
                      <option value="BAHAN_AJAR">📚 Bahan Ajar Bacaan Ringkas Guru &amp; Siswa</option>
                      <option value="KKTP_GLOSARIUM">📋 Kriteria Ketercapaian (KKTP), Glosarium &amp; Pustaka</option>
                    </>
                  )}
                </select>
                <span className="text-[9px] text-gray-400 font-light leading-snug">
                  Pilih draf instrumen Kurikulum Merdeka terbaru yang ingin Anda bangun menggunakan kecerdasan buatan.
                </span>
              </div>

              {/* Row: Jenjang & Kelas */}
              <div className="grid grid-cols-2 gap-3">
                <div className="flex flex-col gap-1 text-left">
                  <label className="text-[11px] font-bold text-gray-700">Jenjang Pendidikan</label>
                  <select 
                    value={level} 
                    onChange={(e) => setLevel(e.target.value)}
                    className="border border-gray-200 rounded-xl px-3 py-2 text-xs focus:outline-none focus:border-brand-primary bg-white cursor-pointer"
                  >
                    <option value="PAUD">PAUD (Pendidikan Anak Usia Dini)</option>
                    <option value="SD">SD (Sekolah Dasar)</option>
                    <option value="SMP">SMP (Menengah Pertama)</option>
                    <option value="SMA">SMA (Menengah Atas)</option>
                    <option value="SMK">SMK (Sekolah Menengah Kejuruan)</option>
                    <option value="SLB">SLB (Sekolah Luar Biasa)</option>
                  </select>
                </div>

                <div className="flex flex-col gap-1 text-left">
                  <label className="text-[11px] font-bold text-gray-700">Fase &amp; Kelas</label>
                  <select 
                    value={kelas} 
                    onChange={(e) => setKelas(e.target.value)}
                    className="border border-gray-200 rounded-xl px-3 py-2 text-xs focus:outline-none focus:border-brand-primary bg-white cursor-pointer"
                  >
                    {(LEVEL_CLASSES[level] || LEVEL_CLASSES["SD"]).map((c) => (
                      <option key={c.value} value={c.value}>{c.label}</option>
                    ))}
                  </select>
                </div>
              </div>

              {/* Conditional Row: Jenis Layanan Ketunaan SLB */}
              {level === "SLB" && (
                <div className="flex flex-col gap-1 text-left">
                  <label className="text-[11px] font-bold text-gray-700 flex items-center gap-1">
                    ♿ Jenis Layanan / Ketunaan Pembelajaran SLB
                  </label>
                  <select 
                    value={ketunaan} 
                    onChange={(e) => setKetunaan(e.target.value)}
                    className="border border-gray-200 rounded-xl px-3 py-2 text-xs focus:outline-none focus:border-brand-primary bg-white cursor-pointer font-bold text-slate-800"
                  >
                    <option value="Tunagrahita">Tunagrahita (Hambatan Intelektual / Kognitif)</option>
                    <option value="Tunanetra">Tunanetra (Hambatan Penglihatan / Visual)</option>
                    <option value="Tunarungu">Tunarungu (Hambatan Pendengaran / Wicara)</option>
                    <option value="Tunadaksa">Tunadaksa (Hambatan Motorik / Fisik Organik)</option>
                    <option value="Autisme">Autisme (Autism Spectrum Disorder - ASD)</option>
                    <option value="ADHD">ADHD / GPPH (Hambatan Pemusatan Perhatian)</option>
                    <option value="Slow learner">Slow Learner (Lamban Belajar Adaptif)</option>
                    <option value="Disabilitas majemuk">Disabilitas Majemuk (Hambatan Ganda Layanan Adaptif)</option>
                  </select>
                  <span className="text-[9px] text-gray-400 font-light leading-snug">
                    AI otomatis memodifikasi dan menyederhanakan tingkat kesulitan akomodasi berdasarkan jenis ketunaan peserta didik.
                  </span>
                </div>
              )}

              {/* Row: Mata Pelajaran Selection */}
              <div className="flex flex-col gap-1 text-left">
                <label className="text-[11px] font-bold text-gray-700">Mata Pelajaran</label>
                
                {/* Pre-populated select helper */}
                <select
                  value={(LEVEL_SUBJECTS[level] || []).flatMap(g => g.list).includes(subject) ? subject : "KUSTOM"}
                  onChange={(e) => {
                    const selectedVal = e.target.value;
                    if (selectedVal !== "KUSTOM") {
                      setSubject(selectedVal);
                    }
                  }}
                  className="border border-gray-200 rounded-xl px-3 py-2 text-xs focus:outline-none focus:border-brand-primary bg-white mb-1.5 cursor-pointer text-slate-700"
                >
                  <option value="KUSTOM">-- Tulis Kustom Mata Pelajaran --</option>
                  {(LEVEL_SUBJECTS[level] || []).map((grp, gidx) => (
                    grp.category ? (
                      <optgroup key={gidx} label={grp.category}>
                        {grp.list.map((sub, sidx) => (
                          <option key={sidx} value={sub}>{sub}</option>
                        ))}
                      </optgroup>
                    ) : (
                      grp.list.map((sub, sidx) => (
                        <option key={sidx} value={sub}>{sub}</option>
                      ))
                    )
                  ))}
                </select>

                {/* Free Text input field for modification / custom values */}
                <input 
                  type="text" 
                  value={subject}
                  onChange={(e) => setSubject(e.target.value)}
                  placeholder="Atau ketik sendiri mata pelajaran..."
                  className="border border-gray-200 rounded-xl px-3 py-2 text-xs focus:outline-none focus:border-brand-primary bg-white"
                />
              </div>

              {/* Row: Topik / Bab Utama */}
              <div className="flex flex-col gap-1">
                <label className="text-[11px] font-bold text-gray-700">Topik / Bab Pembahasan Utama</label>
                <input 
                  type="text" 
                  value={topic}
                  onChange={(e) => setTopic(e.target.value)}
                  placeholder="Contoh: Bangun Datar, Listrik EFI"
                  className="border border-gray-200 rounded-xl px-3 py-2 text-xs focus:outline-none focus:border-brand-primary bg-white"
                />
              </div>

              {/* Row: Capaian Pembelajaran (CP) */}
              <div className="flex flex-col gap-1">
                <label className="text-[11px] font-bold text-gray-700">Capaian Pembelajaran (CP) / Rumusan Kompetensi</label>
                <textarea 
                  value={cp}
                  onChange={(e) => setCp(e.target.value)}
                  rows={4}
                  placeholder="Tuliskan Capaian Pembelajaran dari Kemendikbudristek..."
                  className="border border-gray-200 rounded-xl px-3 py-2 text-xs focus:outline-none focus:border-brand-primary bg-white resize-none leading-relaxed font-light"
                />
              </div>

              {/* Special AI Magic toggles */}
              <div className="mt-2 border-t border-gray-100 pt-4 flex flex-col gap-3 bg-slate-50/50 p-3.5 rounded-2xl">
                <div className="flex items-center justify-between">
                  <div className="flex items-start gap-1.5">
                    <Sparkles className="w-3.5 h-3.5 text-brand-secondary fill-brand-secondary/5 mt-0.5" />
                    <div className="text-left">
                      <span className="text-[11px] font-bold text-slate-800 block">Diferensiasi Pembelajaran</span>
                      <span className="text-[10px] text-gray-400 block font-light leading-none">Rincikan gaya visual, audio, dan kinestetik</span>
                    </div>
                  </div>
                  <button 
                    type="button"
                    onClick={() => setDiferensiasi(!diferensiasi)}
                    className="text-brand-secondary hover:scale-105 transition-transform"
                  >
                    {diferensiasi ? <ToggleRight className="w-8 h-8 shrink-0" /> : <ToggleLeft className="w-8 h-8 text-gray-300 shrink-0" />}
                  </button>
                </div>

                <div className="flex items-center justify-between border-t border-slate-100/80 pt-2.5">
                  <div className="flex items-start gap-1.5">
                    <Sparkles className="w-3.5 h-3.5 text-brand-primary fill-brand-primary/5 mt-0.5" />
                    <div className="text-left">
                      <span className="text-[11px] font-bold text-slate-800 block">Metodologi Deep Learning</span>
                      <span className="text-[10px] text-gray-400 block font-light leading-none">Menekankan pemahaman HOTS &amp; koneksi</span>
                    </div>
                  </div>
                  <button 
                    type="button"
                    onClick={() => setDeepLearning(!deepLearning)}
                    className="text-brand-primary hover:scale-105 transition-transform"
                  >
                    {deepLearning ? <ToggleRight className="w-8 h-8 shrink-0" /> : <ToggleLeft className="w-8 h-8 text-gray-300 shrink-0" />}
                  </button>
                </div>
              </div>

            </div>
          </div>

          <div className="mt-6 pt-3">
            <button 
              onClick={generateModulAjar}
              disabled={isLoading}
              className="w-full ai-gradient text-white py-3.5 rounded-2xl font-bold text-xs tracking-wider uppercase block shadow-md disabled:opacity-50 hover:scale-102 active:scale-98 transition-all cursor-pointer"
            >
              {isLoading ? "Menyusun dengan AI..." : "Mulai Rancang Modul Ajar"}
            </button>
          </div>
        </section>

        {/* Right Output Document Column */}
        <section className="flex-grow bg-slate-100 flex flex-col overflow-hidden relative">
          
          {isLoading && (
            <div className="absolute inset-0 bg-white/80 backdrop-blur-sm z-30 flex flex-col items-center justify-center text-center p-6">
              <div className="w-16 h-16 bg-brand-primary/10 rounded-2xl flex items-center justify-center text-brand-primary mb-4 animate-spin">
                <Sparkles className="w-8 h-8 text-indigo-700" />
              </div>
              <h4 className="font-display font-black text-slate-800 text-sm mb-1 uppercase tracking-wider">Kecerdasan Buatan Sedang Bekerja</h4>
              <p className="text-xs text-slate-500 max-w-sm leading-relaxed font-light">
                Merumuskan draf akademik terbaik sesuai Kurikulum Merdeka, menyusun silabus latihan, instrumen HOTS, dan differensiasi konten...
              </p>
            </div>
          )}

          {!generatedContent && !isLoading ? (
            /* Empty state placeholder */
            <div className="flex-grow flex flex-col items-center justify-center p-8 text-center bg-white/95">
              <div className="w-16 h-16 bg-indigo-50 text-indigo-700 rounded-3xl flex items-center justify-center mb-5 animate-float">
                <Sparkles className="w-8 h-8" />
              </div>
              <h4 className="font-display font-black text-slate-800 text-base mb-2">Draf Modul Kurikulum Merdeka Anda</h4>
              <p className="text-xs text-gray-400 max-w-md leading-relaxed mb-6 font-light">
                Tekan tombol "Mulai Rancang Modul Ajar" di sebelah kiri, atau pilih salah satu demo sekolah cepat untuk memproses draf administrasi mengajar Anda dalam sekejap secara akurat.
              </p>
              
              <div className="bg-slate-50 text-[11px] text-gray-500 rounded-2xl border border-gray-100 p-4 max-w-lg mx-auto text-left flex items-start gap-2.5 leading-relaxed font-light">
                <Info className="w-4 h-4 text-brand-primary shrink-0 mt-0.5" />
                <div>
                  <span className="font-bold text-slate-700 block mb-0.5">Pendekatan Kurikulum Merdeka</span>
                  Draf disusun berdasar rumusan Kriteria Ketercapaian Tujuan Pembelajaran (KKTP), lengkap dengan rubrik penilaian kinerja, serta lembar asisten guru.
                </div>
              </div>
            </div>
          ) : (
            /* Document Output Preview */
            <div className="flex-grow flex flex-col overflow-hidden">
              
              {/* Document top title indicators bar */}
              <div className="bg-white border-b border-gray-200/80 p-4 px-6 flex justify-between items-center shrink-0">
                <div className="flex items-center gap-2">
                  <span className="text-[10px] uppercase font-extrabold tracking-widest text-[#006645] bg-emerald-50 px-2.5 py-1 rounded-md border border-emerald-100">
                    DOKUMEN SIAP
                  </span>
                  <span className="text-xs text-gray-400">|</span>
                  <span className="text-xs text-gray-500 font-medium">Bpk. Aris Setiawan, S.Pd.</span>
                </div>

                <div className="flex items-center gap-2 text-xs">
                  <button 
                    onClick={copyToClipboard}
                    className="bg-slate-50 hover:bg-slate-100 text-slate-700 font-bold px-3 py-1.5 rounded-lg border border-slate-200/60 flex items-center gap-1 transition-colors cursor-pointer"
                  >
                    <Copy className="w-3.5 h-3.5 text-slate-500" />
                    <span>{hasCopied ? "Disalin!" : "Salin"}</span>
                  </button>
                </div>
              </div>

              {/* Real Word doc mockup paper panel */}
              <div className="flex-grow overflow-y-auto p-6 md:p-12 bg-slate-200 selection:bg-brand-primary/10">
                <div className="max-w-3xl bg-white min-h-[11in] mx-auto shadow-xl rounded-2xl p-8 md:p-14 text-left border border-white relative text-gray-800">
                  <div className="absolute top-0 right-0 p-4 text-[10px] text-gray-300 font-mono select-none">
                    EduAI Template Doc
                  </div>
                  
                  {renderFormattedMarkdown(generatedContent)}
                </div>
              </div>

            </div>
          )}

        </section>

      </div>

      {/* Share/Publish Success Dialog Modal Overlay */}
      {showPublishModal && (
        <div className="fixed inset-0 bg-slate-900/40 backdrop-blur-sm z-50 flex items-center justify-center p-4">
          <div className="bg-white rounded-3xl p-6 md:p-8 max-w-lg w-full shadow-2xl border border-slate-100 text-center animate-scale-up font-sans">
            {isPublishing ? (
              <div className="py-8 flex flex-col items-center">
                <div className="w-14 h-14 bg-indigo-50 rounded-2xl flex items-center justify-center text-indigo-650 animate-spin mb-4 text-indigo-600">
                  <RefreshCcw className="w-6 h-6 animate-spin" />
                </div>
                <h4 className="font-display font-black text-slate-800 text-sm uppercase tracking-wider">Menyiapkan Tautan Publik</h4>
                <p className="text-xs text-gray-400 mt-2 max-w-xs font-light">
                  Sedang meregistrasikan draf modul mengajar Anda ke server sinkronisasi kurikulum...
                </p>
              </div>
            ) : publishedId ? (
              <div className="flex flex-col items-center">
                <div className="w-14 h-14 bg-emerald-50 text-emerald-600 rounded-3xl flex items-center justify-center mb-4">
                  <CheckCircle className="w-8 h-8 stroke-[2.5]" />
                </div>
                <h4 className="font-display font-black text-emerald-800 text-base">Modul Berhasil Dipublikasikan!</h4>
                <p className="text-xs text-gray-400 mt-1.5 font-light max-w-sm block">
                  Tautan Anda telah aktif dan siap digunakan langsung oleh siapa saja, tanpa perlu login.
                </p>

                {/* Real-time Link View Input */}
                <div className="w-full mt-6 bg-slate-50 border border-slate-200/60 rounded-2xl p-3 flex items-center justify-between gap-2.5">
                  <input 
                    type="text" 
                    readOnly
                    value={`${window.location.origin}/?share=${publishedId}`}
                    className="bg-transparent text-slate-800 text-xs font-mono font-medium focus:outline-none flex-grow select-all cursor-text text-left truncate"
                  />
                  <button 
                    onClick={() => {
                      navigator.clipboard.writeText(`${window.location.origin}/?share=${publishedId}`);
                      setHasCopiedLink(true);
                      setTimeout(() => setHasCopiedLink(false), 2000);
                    }}
                    className="bg-slate-900 hover:bg-slate-800 text-white font-bold text-[10px] px-3.5 py-2 rounded-xl shrink-0 transition-all cursor-pointer font-sans"
                  >
                    {hasCopiedLink ? "Disalin!" : "Salin Link"}
                  </button>
                </div>

                {/* Immediate Click Access Action */}
                <div className="grid grid-cols-2 gap-3 w-full mt-6 font-sans">
                  <a 
                    href={`${window.location.origin}/?share=${publishedId}`}
                    target="_blank"
                    rel="noreferrer"
                    className="bg-indigo-600 hover:bg-indigo-700 text-white font-bold text-xs py-3 rounded-xl transition-all shadow-md flex items-center justify-center gap-1.5 cursor-pointer select-none border border-transparent"
                  >
                    <span>Kunjungi Link</span>
                    <ArrowRight className="w-4 h-4" />
                  </a>

                  <button 
                    onClick={() => setShowPublishModal(false)}
                    className="bg-slate-100 hover:bg-slate-200 text-slate-800 font-bold text-xs py-3 rounded-xl transition-colors cursor-pointer select-none border border-transparent"
                  >
                    Selesai
                  </button>
                </div>
                
                <span className="text-[10px] text-gray-400 block mt-4 font-light leading-relaxed">
                  Tip: Rekan guru yang membuka tautan ini dapat mengimpor &amp; mengedit RPP ini secara langsung ke dalam dasbor kelas mereka masing-masing.
                </span>
              </div>
            ) : (
              <div className="py-4 text-center">
                <div className="w-12 h-12 bg-red-50 text-red-650 rounded-2xl flex items-center justify-center mx-auto mb-3">
                  <Info className="w-6 h-6 text-red-500" />
                </div>
                <h4 className="font-bold text-slate-800 text-sm mb-1">Gagal Mempublikasikan</h4>
                <p className="text-xs text-gray-400">Terjadi kesalahan teknis saat mengirim data modul. Coba beberapa saat lagi.</p>
                <div className="mt-5 flex gap-2 justify-center">
                  <button 
                    onClick={handlePublish}
                    className="bg-slate-900 hover:bg-slate-800 text-white text-xs font-bold px-4 py-2 rounded-xl cursor-pointer"
                  >
                    Coba Lagi
                  </button>
                  <button 
                    onClick={() => setShowPublishModal(false)}
                    className="bg-slate-100 hover:bg-slate-200 text-slate-800 text-xs font-bold px-4 py-2 rounded-xl cursor-pointer"
                  >
                    Batal
                  </button>
                </div>
              </div>
            )}
          </div>
        </div>
      )}

    </div>
  );
}
