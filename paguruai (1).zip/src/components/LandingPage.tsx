/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import { Sparkles, ArrowRight, Rocket, Check, HelpCircle, AlertCircle, PlayCircle, Eye } from 'lucide-react';

interface LandingPageProps {
  onEnterApp: () => void;
  onSelectDemoProject: (type: 'tsm' | 'sains' | 'math') => void;
}

export default function LandingPage({ onEnterApp, onSelectDemoProject }: LandingPageProps) {
  return (
    <div className="bg-surface-bg text-on-surface font-sans min-h-screen selection:bg-brand-primary/20 selection:text-brand-primary">
      {/* Navigation */}
      <nav className="fixed top-0 w-full z-50 bg-white/75 backdrop-blur-xl border-b border-gray-200/50">
        <div className="flex justify-between items-center px-6 lg:px-12 max-w-7xl mx-auto h-16">
          <div className="font-display text-xl font-extrabold text-indigo-900 flex items-center gap-2">
            <span className="p-1 px-2.5 bg-gradient-to-r from-blue-700 via-indigo-700 to-indigo-900 text-white text-base rounded-xl font-bold font-display shadow-sm">PAGURU AI ⭐⭐⭐⭐⭐</span>
            <span className="text-xs text-indigo-500/80 font-sans tracking-wide hidden sm:inline">Perangkat Ajar Guru</span>
          </div>
          
          {/* Menu Desktop */}
          <div className="hidden md:flex items-center gap-8">
            <a href="#features" className="text-brand-primary font-semibold border-b-2 border-brand-primary pb-1 text-sm font-sans">
              Fitur
            </a>
            <a href="#pricing" className="text-gray-600 hover:text-brand-primary transition-colors text-sm font-medium font-sans">
              Harga
            </a>
            <a href="#community" className="text-gray-600 hover:text-brand-primary transition-colors text-sm font-medium font-sans">
              Komunitas
            </a>
          </div>

          <div className="flex items-center gap-4">
            <button 
              onClick={onEnterApp}
              className="text-brand-primary font-bold text-sm tracking-wide hover:opacity-80 transition-opacity font-sans hidden md:block"
            >
              Masuk
            </button>
            <button 
              onClick={onEnterApp}
              className="ai-gradient text-white px-5 py-2.5 rounded-full font-bold text-sm shadow-sm hover:scale-105 transition-transform flex items-center gap-1.5"
            >
              <Sparkles className="w-4 h-4" />
              <span>Mulai Gratis</span>
            </button>
          </div>
        </div>
      </nav>

      {/* Main Body */}
      <main className="pt-24 overflow-hidden">
        {/* Hero Section */}
        <section className="relative px-6 lg:px-12 max-w-7xl mx-auto flex flex-col items-center text-center py-16">
          {/* Blurred Accent Blobs */}
          <div className="absolute -top-20 -left-20 w-80 h-80 lg:w-96 lg:h-96 bg-brand-primary/10 rounded-full blur-[100px] -z-10"></div>
          <div className="absolute top-40 -right-20 w-80 h-80 lg:w-96 lg:h-96 bg-brand-secondary/10 rounded-full blur-[100px] -z-10"></div>
          
          {/* Pill Batch */}
          <div className="inline-flex items-center gap-1.5 bg-brand-secondary/10 text-brand-secondary px-4 py-1.5 rounded-full mb-6 border border-brand-secondary/20 text-xs font-semibold leading-none font-sans">
            <Sparkles className="w-3.5 h-3.5 fill-brand-secondary/20" />
            <span>AI-Powered Education 2026</span>
          </div>

          <h1 className="font-display text-4xl sm:text-5xl lg:text-[54px] max-w-4xl font-extrabold tracking-tight leading-[1.1] mb-6">
            <span className="bg-gradient-to-r from-blue-700 via-indigo-700 to-indigo-900 bg-clip-text text-transparent">PAGURU AI Perangkat Ajar</span> <span className="text-blue-600 block sm:inline">Kurikulum Merdeka 2026</span>
          </h1>
          
          <p className="font-sans text-gray-600 text-lg md:text-xl max-w-3xl mb-10 leading-relaxed font-light">
            Solusi Pintar Kecerdasan Buatan Terlengkap untuk Seluruh Guru Indonesia. Rancang Modul Ajar, RPP Master, Alur Pembelajaran (ATP), LKPD, Catatan Anekdot, Rubrik Asesmen Kejuruan &amp; SLB Fungsional dalam Sekejap.
          </p>

          <div className="flex flex-col sm:flex-row justify-center gap-4 w-full sm:w-auto px-4 z-10">
            <button 
              onClick={onEnterApp}
              className="ai-gradient hover:shadow-lg text-white px-8 py-4 rounded-xl font-bold flex items-center justify-center gap-2.5 text-base transition-transform active:scale-95 cursor-pointer"
            >
              <Rocket className="w-5 h-5" />
              <span>Mulai Gratis Sekarang</span>
            </button>
            <a 
              href="#demo-interactive"
              className="glass-card hover:bg-gray-100/50 text-gray-800 px-8 py-4 rounded-xl font-bold border border-gray-200/60 transition-colors flex items-center justify-center gap-2 text-base"
            >
              <PlayCircle className="w-5 h-5 text-brand-primary" />
              <span>Coba Demo Interaktif</span>
            </a>
          </div>

          {/* Hero Interface Preview with Floating Elements */}
          <div className="mt-16 relative w-full max-w-5xl px-2">
            <div className="glass-card rounded-[2rem] p-3 shadow-2xl border border-white/80 relative">
              <img 
                alt="EduAI Interface" 
                className="w-full rounded-[1.5rem] shadow-inner border border-gray-100"
                referrerPolicy="no-referrer"
                src="https://lh3.googleusercontent.com/aida-public/AB6AXuCg0qj70Yd1aRAgbIgvjvbYVGTP0ThhNVafMsh9ks73AMzkWg_DNjdioATrjnudRhfQRJkHvlSFXzUDqHb7Enf8Loc9XwtcbnxlQ-5Jsu14cFYaugueW3Rq4QPALcWaonhppDuVIEyKa8SK4kjbj7EVExU2ay0_dhjGfBLYrI72sb5LLwbsZGq0g1vvng7O9c_ZNPE3JVqzsQ72MAaw5zy_WJCoHnFtReJGqXjFJwA-ONwVmzVMjjKgCDzMZ8pUmKflKdEgUPnGZ48" 
              />
              
              {/* Floating Chip 1 */}
              <div className="absolute -left-4 lg:-left-8 top-1/4 glass-card p-4 rounded-2xl shadow-xl animate-float block z-20 hover:scale-105 transition-transform duration-300">
                <div className="flex items-center gap-3">
                  <div className="w-10 h-10 bg-emerald-100 rounded-lg flex items-center justify-center text-brand-tertiary">
                    <Check className="w-5 h-5 stroke-[3]" />
                  </div>
                  <div className="text-left font-sans">
                    <div className="font-bold text-sm text-gray-950">Modul Selesai</div>
                    <div className="text-gray-500 text-xs mt-0.5">Matematika - Kelas 4</div>
                  </div>
                </div>
              </div>

              {/* Floating Chip 2 */}
              <div className="absolute -right-4 lg:-right-8 bottom-1/4 glass-card p-4 rounded-2xl shadow-xl animate-float [animation-delay:2.5s] block z-20 hover:scale-105 transition-transform duration-300">
                <div className="flex items-center gap-3">
                  <div className="w-10 h-10 bg-indigo-100 rounded-lg flex items-center justify-center text-brand-secondary">
                    <Sparkles className="w-5 h-5 fill-brand-secondary/10 text-brand-secondary" />
                  </div>
                  <div className="text-left font-sans">
                    <div className="font-bold text-sm text-gray-950">AI Menganalisis...</div>
                    <div className="text-gray-500 text-xs mt-0.5">8-Dimensi Profil Lulusan</div>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </section>

        {/* Demo Interactive Anchor */}
        <section id="demo-interactive" className="bg-white py-12 border-y border-gray-100">
          <div className="max-w-4xl mx-auto px-6 text-center">
            <h3 className="font-display text-xl sm:text-2xl font-bold text-gray-900 mb-2">Simulasikan Proyek Pembelajaran Guru</h3>
            <p className="text-gray-500 text-sm mb-6 max-w-lg mx-auto">
              Pilih topik di bawah untuk memuat dan berdiskusi langsung di dashboard:
            </p>
            <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
              <button 
                onClick={() => onSelectDemoProject('tsm')}
                className="bg-purple-50 hover:bg-purple-100 border border-purple-200/60 p-4 rounded-2xl text-left transition-all hover:-translate-y-1"
              >
                <div className="font-bold text-purple-900 text-sm mb-1">🔧 Teknik Sepeda Motor</div>
                <div className="text-xs text-purple-700 font-light">Troubleshooting Sistem Injeksi Bahan Bakar (Kelas XI)</div>
              </button>
              
              <button 
                onClick={() => onSelectDemoProject('sains')}
                className="bg-emerald-50 hover:bg-emerald-100 border border-emerald-200/60 p-4 rounded-2xl text-left transition-all hover:-translate-y-1"
              >
                <div className="font-bold text-emerald-900 text-sm mb-1">🌿 IPA Ekosistem</div>
                <div className="text-xs text-emerald-700 font-light">Eksplorasi Lingkungan Hidup &amp; Biotik (Kelas 6)</div>
              </button>

              <button 
                onClick={() => onSelectDemoProject('math')}
                className="bg-blue-50 hover:bg-blue-100 border border-blue-200/60 p-4 rounded-2xl text-left transition-all hover:-translate-y-1"
              >
                <div className="font-bold text-blue-900 text-sm mb-1">📐 Geometri Bangun Ruang</div>
                <div className="text-xs text-blue-700 font-light">Sifat Kesetaraan Volume &amp; RPP Matematika (Kelas 7)</div>
              </button>
            </div>
          </div>
        </section>

        {/* Features Section */}
        <section id="features" className="py-20 px-6 lg:px-12 max-w-7xl mx-auto">
          <div className="text-center mb-16">
            <h2 className="font-display text-3xl sm:text-4xl font-extrabold text-gray-900 mb-4">Fitur Unggulan Masa Depan</h2>
            <p className="text-gray-500 max-w-2xl mx-auto text-base">
              Satu ekosistem cerdas serba otomatis yang dirancang khusus menyesuaikan kebutuhan pengajaran Kurikulum Merdeka Anda.
            </p>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-12 gap-6 items-stretch">
            {/* Bento 1: Lesson Plan Generator */}
            <div className="md:col-span-8 glass-card rounded-3xl p-8 flex flex-col justify-between overflow-hidden relative group border border-gray-200/50 hover:border-brand-primary/30 transition-all duration-300 min-h-[340px]">
              <div className="relative z-10 max-w-xl">
                <div className="w-12 h-12 bg-blue-100 text-brand-primary rounded-2xl flex items-center justify-center mb-6">
                  <Sparkles className="w-6 h-6 fill-blue-50" />
                </div>
                <h3 className="font-display text-2xl font-bold text-gray-900 mb-3">1-click Lesson Plan Generator</h3>
                <p className="text-gray-500 text-sm leading-relaxed mb-6">
                  Input topik materi atau tempelkan Capaian Pembelajaran (CP) sekolah Anda. Biarkan AI kami bekerja merumuskan tujuan, langkah, dan instrumen penilaian dalam sekejap.
                </p>
              </div>
              
              <div className="absolute right-0 bottom-0 w-[45%] md:w-[40%] translate-y-8 translate-x-4 opacity-70 group-hover:translate-y-2 group-hover:translate-x-0 transition-transform duration-700 z-0 select-none">
                <img 
                  alt="Plan Generator" 
                  className="rounded-tl-2xl shadow-xl border-l border-t border-gray-200"
                  referrerPolicy="no-referrer"
                  src="https://lh3.googleusercontent.com/aida-public/AB6AXuDqOOC7E-hVmpO9kX9ZdeOuTIdsCKhycKa-_ibonLlmay3KgjaPWcv6Lo4pITLy2cvAnqSBiW97jfpVByavaVyNJbYANy6ShLrzsUMivmgpUfQsJeyfsyBFWC5unOA1eZ8emFeYSmBLu3JeTO3Jw0PX3khQngySYIOUTlEYLQYSKYMq5AtZlcXdrYY3Q0upz74vAGj5V-7A4DILzkaUDR2Zlit1K9MQ3GEjAvrHLC0JyYM67a6omzjn2WuW9trrIo4V9Y2KYzuo_8I" 
                />
              </div>
            </div>

            {/* Bento 2: Deep Learning Integration */}
            <div className="md:col-span-4 bg-gray-50 border border-gray-200/50 rounded-3xl p-8 flex flex-col justify-center text-center">
              <div className="w-16 h-16 bg-brand-secondary text-white rounded-3xl flex items-center justify-center mx-auto mb-6 shadow-md shadow-brand-secondary/20">
                <Sparkles className="w-8 h-8 fill-brand-secondary/35" />
              </div>
              <h3 className="font-display text-xl font-bold text-gray-950 mb-2">Deep Learning Integration</h3>
              <p className="text-gray-500 text-sm leading-relaxed">
                Asisten AI selalu beradaptasi dengan gaya mengajar Anda yang khas, membantu menyederhanakan penyusunan instrumen HOTS.
              </p>
            </div>

            {/* Bento 3: Inclusive Education */}
            <div className="md:col-span-4 glass-card rounded-3xl p-8 flex flex-col items-start border-l-4 border-l-brand-tertiary">
              <div className="w-12 h-12 bg-emerald-50 text-emerald-700 rounded-2xl flex items-center justify-center mb-6">
                <Check className="w-6 h-6 stroke-[3.5]" />
              </div>
              <h3 className="font-display text-xl font-bold text-gray-950 mb-2">Pendidikan Inklusif</h3>
              <p className="text-gray-500 text-sm leading-relaxed">
                Modifikasi aktivitas dan lembar ajar secara instan bagi siswa berkebutuhan khusus dengan bantuan asisten differensiasi AI.
              </p>
            </div>

            {/* Bento 4: 8-Dimension Alignment Wheel */}
            <div className="md:col-span-8 bg-white border border-gray-200/50 rounded-3xl p-8 flex flex-col sm:flex-row items-center gap-8 justify-between hover:border-brand-primary/20 transition-colors">
              <div className="flex-1">
                <div className="w-12 h-12 bg-indigo-50 text-indigo-700 rounded-2xl flex items-center justify-center mb-6">
                  <HelpCircle className="w-6 h-6" />
                </div>
                <h3 className="font-display text-xl font-bold text-gray-950 mb-2">Pemetaan Profil Lulusan 8-Dimensi</h3>
                <p className="text-gray-500 text-sm leading-relaxed">
                  Pemetaan otomatis ketercapaian siswa terhadap 8 dimensi profil pelajar Pancasila secara visual untuk pelaporan asesmen komprehensif.
                </p>
              </div>

              <div className="flex items-center justify-center relative w-44 h-44 shrink-0">
                {/* SVG aligned indicator wheel */}
                <svg className="w-full h-full transform -rotate-90">
                  <circle className="text-gray-100" cx="88" cy="88" fill="transparent" r="74" stroke="currentColor" strokeWidth="8"></circle>
                  <circle className="text-brand-primary" cx="88" cy="88" fill="transparent" r="74" stroke="currentColor" strokeDasharray="465" strokeDashoffset="75" strokeWidth="8" strokeLinecap="round"></circle>
                </svg>
                <div className="absolute inset-0 flex flex-col items-center justify-center">
                  <span className="font-display font-light text-2xl text-gray-900 tracking-tight leading-none">85%</span>
                  <span className="text-[10px] text-gray-400 uppercase tracking-widest font-extrabold mt-1">Aligned</span>
                </div>
              </div>
            </div>
          </div>
        </section>
        <section id="pricing" className="bg-slate-50 py-20 border-t border-gray-100">
          <div className="px-6 lg:px-12 max-w-7xl mx-auto">
            <div className="text-center mb-16">
              <span className="text-xs bg-indigo-50 border border-indigo-100 text-brand-primary px-3 py-1 rounded-full font-bold uppercase tracking-wider">Komitmen Edukasi Nasional</span>
              <h2 className="font-display text-3xl sm:text-4xl font-extrabold text-slate-900 mt-3 mb-4">100% Layanan Gratis untuk Seluruh Guru Indonesia</h2>
              <p className="text-gray-500 max-w-2xl mx-auto text-sm leading-relaxed">
                Melalui kolaborasi CSR Bakti Pendidikan Nasional dan Ikatan Pendidik Indonesia, seluruh hak akses administrasi AI dirancang tanpa biaya reguleran demi mendukung kelancaran mengajar Anda.
              </p>
            </div>

            <div className="grid grid-cols-1 md:grid-cols-3 gap-8 items-stretch pt-4 max-w-5xl mx-auto">
              
              {/* Free Plan */}
              <div className="bg-white border border-slate-105 rounded-3xl p-8 flex flex-col hover:shadow-xl transition-all duration-300 transform hover:-translate-y-1">
                <div className="mb-6">
                  <span className="text-[10px] bg-slate-100 text-slate-600 px-2.5 py-1 rounded-md font-bold uppercase tracking-wide inline-block mb-3">Paket Mengajar Mandiri</span>
                  <h3 className="font-display text-xl font-extrabold text-slate-900 mb-2">Guru Mandiri</h3>
                  <div className="flex items-baseline gap-1.5">
                    <span className="text-4xl font-extrabold text-slate-950 tracking-tight">Gratis</span>
                    <span className="text-emerald-600 text-xs font-bold bg-emerald-50 px-1.5 py-0.5 rounded ml-1">Rp 0 Selamanya</span>
                  </div>
                </div>
                <hr className="border-slate-100 my-2" />
                <ul className="flex flex-col gap-4 my-6 flex-grow text-slate-600 text-xs text-left">
                  <li className="flex items-center gap-2.5">
                    <Check className="w-4 h-4 text-emerald-600 stroke-[3]" />
                    <span>Draf 10 RPP & Modul Ajar / Bulan</span>
                  </li>
                  <li className="flex items-center gap-2.5">
                    <Check className="w-4 h-4 text-emerald-600 stroke-[3]" />
                    <span>Akses Bank Komunitas Kurikulum</span>
                  </li>
                  <li className="flex items-center gap-2.5 text-emerald-600 font-medium">
                    <Check className="w-4 h-4 text-emerald-600 stroke-[3]" />
                    <span>Standar Capaian Pendidikan Esensial</span>
                  </li>
                </ul>
                <button 
                  onClick={onEnterApp}
                  className="w-full py-3.5 rounded-2xl bg-slate-900 hover:bg-slate-800 text-white font-bold text-xs tracking-wide transition-all cursor-pointer shadow-md shadow-slate-900/10"
                >
                  Mulai Mengajar Gratis
                </button>
              </div>

              {/* Pro Teacher - Highlighted */}
              <div className="bg-gradient-to-br from-indigo-900 via-indigo-800 to-indigo-950 text-white rounded-3xl p-8 flex flex-col relative overflow-hidden shadow-2xl scale-102 lg:scale-105 z-10 border border-brand-secondary/30 transform hover:-translate-y-1.5 transition-all duration-300">
                <div className="absolute top-4 right-4 bg-emerald-500 text-white px-3 py-1 rounded-full text-[9px] font-extrabold uppercase tracking-widest leading-none shadow-sm animate-pulse">
                  Subsidi Penuh CSR
                </div>
                <div className="mb-6 text-left">
                  <span className="text-[10px] bg-white/10 text-emerald-300 px-2.5 py-1 rounded-md font-extrabold uppercase tracking-wide inline-block mb-3">Paket Unggulan Teratas (PRO)</span>
                  <h3 className="font-display text-xl font-extrabold mb-1">Pendidik Penggerak Pro</h3>
                  <div className="flex items-baseline gap-1.5">
                    <span className="text-4xl font-extrabold tracking-tight">Gratis Penuh</span>
                    <span className="opacity-90 text-[10px] line-through">Rp 49.000</span>
                  </div>
                </div>
                <hr className="border-white/10 my-2" />
                <ul className="flex flex-col gap-4 my-6 flex-grow text-xs text-left opacity-95">
                  <li className="flex items-center gap-2.5">
                    <Check className="w-4 h-4 text-emerald-400 stroke-[3]" />
                    <span className="font-medium text-emerald-250">UNLIMITED Modul & RPP Kurikulum</span>
                  </li>
                  <li className="flex items-center gap-2.5">
                    <Check className="w-4 h-4 text-emerald-400 stroke-[3]" />
                    <span>Asisten Dialog AI Tutor Real-Time</span>
                  </li>
                  <li className="flex items-center gap-2.5">
                    <Check className="w-4 h-4 text-emerald-400 stroke-[3]" />
                    <span>Pemetaan 8-Dimensi Profil Pancasila</span>
                  </li>
                  <li className="flex items-center gap-2.5">
                    <Check className="w-4 h-4 text-emerald-400 stroke-[3]" />
                    <span>Sistem Berbagi & Publikasi Tautan</span>
                  </li>
                  <li className="flex items-center gap-2.5">
                    <Check className="w-4 h-4 text-emerald-400 stroke-[3]" />
                    <span>Unduh Dokumen Word & PDF Tanpa Batas</span>
                  </li>
                </ul>
                <button 
                  onClick={onEnterApp}
                  className="w-full py-4 rounded-2xl bg-white text-indigo-900 font-extrabold text-xs tracking-wider uppercase hover:bg-slate-50 transition-all shadow-md active:scale-98 cursor-pointer"
                >
                  Aktifkan Akses Pro Gratis
                </button>
              </div>

              {/* School Plan */}
              <div className="bg-white border border-slate-105 rounded-3xl p-8 flex flex-col hover:shadow-lg transition-all duration-300 transform hover:-translate-y-1">
                <div className="mb-6">
                  <span className="text-[10px] bg-slate-100 text-slate-600 px-2.5 py-1 rounded-md font-bold uppercase tracking-wide inline-block mb-3">Paket Sekolah & Madrasah</span>
                  <h3 className="font-display text-xl font-extrabold text-gray-900 mb-2">Sekolah Merdeka</h3>
                  <div className="flex items-baseline gap-1.5">
                    <span className="text-3xl font-extrabold text-slate-950 tracking-tight">Hibah</span>
                    <span className="text-indigo-650 text-xs font-semibold bg-indigo-50 px-1.5 py-0.5 rounded ml-1">Gratis Kolektif</span>
                  </div>
                </div>
                <hr className="border-gray-100 my-2" />
                <ul className="flex flex-col gap-4 my-6 flex-grow text-slate-600 text-xs text-left">
                  <li className="flex items-center gap-2.5">
                    <Check className="w-4 h-4 text-emerald-600 stroke-[3]" />
                    <span>Dashboard Pengawas Kepala Sekolah</span>
                  </li>
                  <li className="flex items-center gap-2.5">
                    <Check className="w-4 h-4 text-emerald-600 stroke-[3]" />
                    <span>Dukungan Pelatihan Guru Bersertifikat</span>
                  </li>
                  <li className="flex items-center gap-2.5">
                    <Check className="w-4 h-4 text-emerald-600 stroke-[3]" />
                    <span>Sincronisasi Silabus Rapor Sekolah</span>
                  </li>
                </ul>
                <button 
                  onClick={onEnterApp}
                  className="w-full py-3.5 rounded-2xl border border-slate-350 text-slate-700 hover:bg-slate-50 font-bold text-xs tracking-wide transition-colors cursor-pointer"
                >
                  Ajukan Hibah Satu Sekolah
                </button>
              </div>

            </div>
          </div>
        </section>

        {/* Call To Action */}
        <section className="py-20 px-6 lg:px-12 max-w-5xl mx-auto text-center" id="community">
          <div className="bg-gradient-to-br from-brand-primary to-brand-secondary rounded-[2.5rem] p-12 md:p-16 text-white relative overflow-hidden shadow-2xl">
            <div className="absolute top-0 right-0 w-64 h-64 bg-white/10 rounded-full blur-3xl -translate-y-1/2 translate-x-1/2"></div>
            
            <h2 className="font-display text-3xl sm:text-4xl lg:text-5xl font-extrabold mb-6 leading-tight">
              Siap Menjadi Guru Masa Depan?
            </h2>
            <p className="text-lg opacity-85 max-w-2xl mx-auto mb-10 leading-relaxed font-light">
              Bergabunglah bersama ribuan guru inspiratif dan inovatif di seluruh Indonesia yang telah memanfaatkan EduAI untuk mengantarkan kualitas pendidikan nasional unggul.
            </p>

            <div className="flex flex-wrap justify-center gap-4">
              <button 
                onClick={onEnterApp}
                className="bg-white text-brand-primary hover:shadow-xl px-10 py-4.5 rounded-2xl font-bold text-base transition-transform active:scale-95 cursor-pointer"
              >
                Mulai Sekarang Gratis
              </button>
              <button 
                onClick={onEnterApp}
                className="bg-white/10 backdrop-blur-md border border-white/20 text-white px-10 py-4.5 rounded-2xl font-bold text-base hover:bg-white/20 transition-colors"
              >
                Lihat Panduan Singkat
              </button>
            </div>
          </div>
        </section>
      </main>

      {/* Footer */}
      <footer className="bg-white border-t border-gray-100 py-16">
        <div className="max-w-7xl mx-auto px-6 lg:px-12">
          
          <div className="flex flex-col md:flex-row justify-between items-start gap-12 mb-16">
            <div className="max-w-sm">
              <div className="font-display text-xl font-extrabold text-indigo-900 mb-4 flex items-center gap-2">
                <span className="p-1 px-2.5 bg-gradient-to-r from-blue-700 via-indigo-700 to-indigo-950 text-white text-sm rounded-xl font-bold font-display shadow-sm">PAGURU AI</span>
                <span>Perangkat Ajar</span>
              </div>
              <p className="text-gray-500 text-sm leading-relaxed">
                Asisten Administrasi &amp; Pedagogi Guru Indonesia Terlengkap, memberdayakan tenaga pendidik untuk melahirkan generasi unggul Indonesia Emas.
              </p>
            </div>

            <div className="grid grid-cols-2 sm:grid-cols-3 gap-12 text-sm font-sans font-medium text-gray-500">
              <div className="flex flex-col gap-3">
                <span className="font-bold text-gray-900 font-display">Produk</span>
                <a onClick={onEnterApp} className="hover:text-brand-primary cursor-pointer transition-colors">Generator Modul</a>
                <a onClick={onEnterApp} className="hover:text-brand-primary cursor-pointer transition-colors">AI Chat Tutor</a>
                <a onClick={onEnterApp} className="hover:text-brand-primary cursor-pointer transition-colors">Bank Materi</a>
              </div>
              <div className="flex flex-col gap-3">
                <span className="font-bold text-gray-900 font-display">Perusahaan</span>
                <a href="#about" className="hover:text-brand-primary transition-colors">Tentang Kami</a>
                <a href="#careers" className="hover:text-brand-primary transition-colors">Karir</a>
                <a href="#contact" className="hover:text-brand-primary transition-colors">Kontak</a>
              </div>
              <div className="flex flex-col gap-3">
                <span className="font-bold text-gray-900 font-display">Dukungan</span>
                <a href="#faq" className="hover:text-brand-primary transition-colors">Pusat Bantuan</a>
                <a href="#community" className="hover:text-brand-primary transition-colors">Komunitas</a>
              </div>
            </div>
          </div>

          <div className="flex flex-col sm:flex-row items-center justify-between gap-6 border-t border-gray-100 pt-12 text-xs text-gray-400 font-sans">
            <div className="flex gap-6">
              <a href="#privacy" className="hover:underline">Kebijakan Privasi</a>
              <a href="#terms" className="hover:underline">Syarat &amp; Ketentuan</a>
              <a href="#help" className="hover:underline">Bantuan</a>
            </div>
            <p className="text-center sm:text-right">
              &copy; 2026 PAGURU AI Perangkat Ajar Guru. Didukung oleh Kecerdasan Buatan Terintegrasi Kemendikbudristek RI.
            </p>
          </div>

        </div>
      </footer>
    </div>
  );
}
