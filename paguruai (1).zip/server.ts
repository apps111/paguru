/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import express from "express";
import path from "path";
import fs from "fs";
import { createServer as createViteServer } from "vite";
import { GoogleGenAI } from "@google/genai";
import dotenv from "dotenv";

dotenv.config();

// Lazy initializer for Gemini
let _ai: GoogleGenAI | null = null;
function getGeminiClient(): GoogleGenAI | null {
  const apiKey = process.env.GEMINI_API_KEY;
  if (!apiKey) {
    console.warn("GEMINI_API_KEY is not set. Real Gemini services might fail; using mock answers if so.");
    return null;
  }
  if (!_ai) {
    _ai = new GoogleGenAI({
      apiKey,
      httpOptions: {
        headers: {
          'User-Agent': 'aistudio-build',
        }
      }
    });
  }
  return _ai;
}

async function startServer() {
  const app = express();
  const PORT = 3000;

  app.use(express.json({ limit: "20mb" }));

  // 1. API: Generate Modul Ajar (Kurikulum Merdeka)
  app.post("/api/generate-modul", async (req, res) => {
    const { 
      level, kelas, semester, subject, topic, cp, 
      diferensiasi, deepLearning, teacherName, schoolName, nip,
      instrumentType = "MODUL_AJAR",
      ketunaan = "Tunagrahita"
    } = req.body;

    try {
      const ai = getGeminiClient();

      if (!ai) {
        // High fidelity offline fallback responses for maximum robustness
        let mText = "";
        
        if (instrumentType === "ATP") {
          mText = `### ALUR TUJUAN PEMBELAJARAN (ATP) TERBARU
**KURIKULUM MERDEKA - ELEMEN STRUKTURAL**

#### I. IDENTITAS PEMETAAN
* **Penyusun:** ${teacherName || "Bpk. Aris Setiawan, S.Pd."}${nip ? ` (NIP: ${nip})` : ""}
* **Sekolah:** ${schoolName || "SDN Merdeka"}${level === "SMK" ? " (Pusat Keunggulan)" : ""}
* **Mata Pelajaran:** ${subject || "Teknik Kejuruan"}
* **Kelas & Semester:** ${level || "SMK"} - ${kelas || "Kelas XI"} / ${semester || "Ganjil"}

---

#### II. ANALISIS RASIONAL & KONSEP ELEMEN
Capaian Pembelajaran (CP) menyatakan:
> ${cp || "Peserta didik mampu melakukan pemecahan masalah secara mandiri terkait pilar kompetensi ajar terbaru."}

Berdasar CP di atas, elemen pembelajaran Kurikulum Merdeka yang dikembangkan meliputi:
1. **Elemen Pemahaman Konseptual:** Menelaah keterkaitan teori dengan realitas lapangan secara mendalam.
2. **Elemen Keterampilan Proses:** Merakit, menguji, menganalisis, serta mendiagnosis anomali sistem secara sistematis.

---

#### III. ALUR TUJUAN PEMBELAJARAN (ATP) PER PERTEMUAN
* **Tujuan Pembelajaran (TP) 1:** Peserta didik mampu menguraikan struktur dasar dan fondasi kerja dari ${topic || "Materi Pokok"} serta membandingkan fungsinya secara mandiri.
* **Tujuan Pembelajaran (TP) 2:** Peserta didik terampil merancang langkah investigasi kritis terhadap kelaikan operasional ${topic || "Materi Pokok"}.

* **Skenario Alur Pertemuan Kelas:**
  * **Pertemuan ke-1 (4 JP):** Eksplorasi konsep terarah dan identifikasi dini isu kontekstual.
  * **Pertemuan ke-2 (4 JP):** Studi kelompok terarah, bedah komponen fisik/simulasi eksperimen, dan analisis mendalam.
  * **Pertemuan ke-3 (4 JP):** Evaluasi hasil merancang solusi serta pelaporan asisten sebaya.

---

#### IV. PROFIL PELAJAR PANCASILA & GLOSARIUM MINI
* **Profil Utama Pelajar Pancasila:** Gotong Royong (kolaborasi kelompok) & Bernalar Kritis (studi investigasi solusi berkelanjutan).
* **Glosarium Istilah:**
  * **Diagnosis:** Upaya sistematis mengidentifikasi letak malafungsi berdasarkan tanda fisik.
  * **Standardisasi:** Batas toleransi pabrikan atau regulasi resmi untuk mengukur kelaikan objek.`;
        } else if (instrumentType === "LKPD") {
          mText = `### LEMBAR KERJA PESERTA DIDIK (LKPD) INTERAKTIF
**STANDAR KURIKULUM MERDEKA - MANDIRI & KELOMPOK**

#### I. INFORMASI PENUGASAN AKTIVITAS
* **Materi Pembahasan:** ${topic || "Analisis Eksploratif"}
* **Mata Pelajaran:** ${subject || "Sains dan Vokasional"}
* **Penyusun:** ${teacherName || "Bpk. Aris Setiawan, S.Pd."}
* **Satuan Pendidikan:** ${schoolName || "SDN Merdeka"}

---

#### II. IDENTITAS KELOMPOK KERJA SISWA
* **Nama Kelompok:** ____________________
* **Fase / Kelas:** ${kelas || "Kelas XI"}
* **Ketua / Anggota:**
  1. ____________________
  2. ____________________
  3. ____________________

---

#### III. LANGKAH-LANGKAH AKTIVITAS BELAJAR
##### A. Tahap Observasi Awal (Apersepsi)
Tinjaulah fenomena ${topic || "topik"} yang disosialisasikan oleh guru di depan kelas. Catatlah 2 poin keganjilan utama yang Anda temukan:
1. ____________________
2. ____________________

##### B. Tahap Eksperimen Terarah
* **Alat dan Bahan Pendukung:** Modul referensi pendukung, lembar catatan, komputer/buku paket, objek eksperimen khusus.
* **Instruksi Kerja Kelompok:**
  1. Lakukan analisis mendalam terhadap struktur pembentuk ${topic || "Materi"}.
  2. Bandingkan efektivitas hasil pengukuran kelompok dengan standardisasi yang berlaku.
  3. Presentasikan kesimpulan akhir Anda di depan kelompok pendamping untuk tanggapan kritis.

---

#### IV. PERTANYAAN ANALITIS (Refleksi Kritis)
1. Analisislah mengapa terjadi penyimpangan hasil ukur dalam studi kasus ${topic || "materi"} di atas?
2. Kemukakan solusi solutif kelompok Anda untuk meminimalkan anomali tersebut secara efisien!`;
        } else if (instrumentType === "MODUL_BERMAIN") {
          mText = `### RENCANA PELAKSANAAN PEMBELAJARAN (MODUL BERMAIN BERMAKNA PAUD)
**FASE FONDASI - BERPUSAT PADA ANAK**

#### I. INFORMASI UMUM & IDENTITAS
* **Nama Penyusun:** ${teacherName || "Ibu Kartini, S.Pd."}
* **Satuan PAUD:** ${schoolName || "TK Pembina Bangsa"}
* **Kelompok Usia:** ${kelas || "TK B (5-6 Tahun)"}
* **Semester / Minggu:** ${semester || "Ganjil"} / Minggu ke-3
* **Topik Inspiratif:** ${topic || "Menghargai Lingkungan Sekitar"}

---

#### II. ELEMEN CAPAIAN PERKEMBANGAN
* **Mata Pelajaran/Aspek:** ${subject || "Literasi Dasar & STEAM Sederhana"}
* **Capaian Pembelajaran (CP) PAUD:**
  > ${cp || "Anak mengenali lingkungan sosialnya, mengamati makhluk hidup di sekitar, dan mengekspresikan imajinasinya secara kreatif melalui media bermain konkret."}

---

#### III. LANGKAH-LANGKAH BERMAIN BERMAKNA (Skenario Sentra)
##### A. Penyambutan & Jurnal Pagi (30 Menit)
1. Menyambut anak dengan senyuman ceria, bernyanyi "Halo teman-teman", dan ikrar pagi bersama.
2. Melakukan senam motorik halus / gerakan melompat lincah.

##### B. Pijakan Sebelum Bermain (15 Menit)
1. Membaca buku dongeng kontekstual tentang *${topic || "Topik Belajar PAUD"}*.
2. Memperkenalkan alat dan bahan alami yang aman (loose parts seperti dedaunan, batu warna, botol bekas, pasir).
3. Guru merumuskan aturan bermain yang menggembirakan bersama anak-anak.

##### C. Pijakan Saat Bermain / Inti Eksplorasi (60 Menit)
* **Sentra Seni & Loose Parts:** Anak berkreasi menempel kolase bunga kesayangan mereka.
* **Sentra Sains Sederhana:** Mengamati gelembung sabun atau tekstur pasir basah.
* **Sentra Peran Makro:** Bermain peran menjadi penjaga kebun botani sayuran yang ramah.

##### D. Pijakan Setelah Bermain / Recalling & Evaluasi (15 Menit)
1. Anak mengembalikan mainan ke tempat wadahnya secara mandiri (melatih kemandirian).
2. Guru menanyakan perasaan anak dan mengorek cerita seru dari karya anak hari ini.

---

#### IV. RENCANA ASESMEN PERKEMBANGAN
1. **Lembar Catatan Anekdot (Anecdotal Record)** untuk perkembangan karakter dan kebiasaan positif anak.
2. **Hasil Karya Foto Berseri** untuk mengabadikan kemampuan sosial-emosional dan kreasi loose parts anak.`;
        } else if (instrumentType === "ASESMEN_PERKEMBANGAN") {
          mText = `### RUBRIK ASESMEN PERKEMBANGAN ANAK USIA DINI
**FASE FONDASI - FORMATIF OBSERVASI LANGSUNG**

#### I. IDENTITAS PENGAMATAN
* **Nama Anak Didik:** [Dinomisasi Siswa]
* **Kelompok Usia:** ${kelas || "TK B (5-6 Tahun)"}
* **Mata Pelajaran/Elemen:** ${subject || "Nilai Agama & Jati Diri"}
* **Topik Kegiatan:** ${topic || "Eksplorasi Pembelajaran Gembira"}

---

#### II. RUBRIK CAPAIAN PERKEMBANGAN ANAK (Indikator Kinerja)

| Aspek Indikator Perkembangan | Belum Muncul (BM) | Mulai Muncul (MM) | Berkembang Sesuai Harapan (BSH) | Berkembang Sangat Baik (BSB) |
| --- | --- | --- | --- | --- |
| **Keterlibatan Sosial Emosional** | Enggan berbagi mainan | Berbagi mainan jika diminta guru | Berbagi mainan atas inisiatif sendiri | Membantu menenangkan teman menangis |
| **Kemampuan Motorik & STEAM** | Kesulitan meremas kertas | Mampu meremas tapi belum rapi | Mengerjakan kolase daun secara tuntas | Merancang konstruksi balok kompleks mendalam |
| **Bahasa & Komunikasi** | Menjawab kaku satu kata | Menjawab pertanyaan sederhana | Bercerita runtut 3 kalimat tentang karyanya | Menggunakan retorika imajinatif baru |

---

#### III. INSTRUMEN OBSERVASI & CATATAN PERKEMBANGAN
* **Rencana Tindak Lanjut Guru:** Jika aspek dominan masih di tingkat **Belum Muncul (BM)**, guru memberikan stimulasi sensorik berkelanjutan di sentra basah dan pendampingan personal yang penuh kehangatan.`;
        } else if (instrumentType === "ANECDOTAL_RECORD") {
          mText = `### CATATAN ANEKDOT (ANECDOTAL RECORD) HARIAN PAUD/TK
**KURIKULUM MERDEKA - INSTRUMEN OBSERVASI KHUSUS**

* **Satuan PAUD:** ${schoolName || "TK Pembina Bangsa"}
* **Nama Guru Pengamat:** ${teacherName || "Ibu Kartini, S.Pd."}
* **Kelompok Kelas:** ${kelas || "TK B (5-6 Tahun)"}
* **Materi Pembahasan:** ${topic || "Aktivitas Bermain dan Bersosialisasi"}

---

#### I. FORMAT CATATAN ANEKDOT INDIVIDU

| Hari / Tanggal | Waktu Pengamatan | Nama Siswa | Tempat Kejadian | Peristiwa / Perilaku Unik Siswa | Capaian Elemen Perkembangan (Interpretasi) |
| --- | --- | --- | --- | --- | --- |
| Senin, 25 Mei | 09.15 WIB | Ananda Andi | Area Sentra Balok | Andi secara mandiri menawarkan bantuan menyusun kembali balok robot yang runtuh milik Ananda Budi tanpa diminta guru. | **Sosial Emosional:** Berbagi kemandirian, empati, dan gotong royong tingkat tinggi (BSB). |
| Selasa, 26 Mei | 10.00 WIB | Ananda Citra | Area Kebun Sekolah | Citra berjongkok lama mengamati koloni semut membawa remah roti. Dia bertanya, "Ibu kenapa semut jalannya harus berbaris antre?" | **Sains Sederhana/Bernalar Kritis:** Rasa ingin tahu ilmiah, kemampuan berpikir eksploratif (BSH). |

---

#### II. EVALUASI DAN ARAH STIMULASI GURU
1. **Rencana Pengayaan:** Sediakan media lup/kaca pembesar nyata di kebun untuk memfasilitasi minat riset serangga Ananda Citra lebih lanjut.
2. **Apresiasi Sikap:** Berikan stiker bintang senyum pada Andi untuk memotivasi perilaku suka menolongnya di depan seluruh anak kelas.`;
        } else if (instrumentType === "RAPOR_PAUD") {
          mText = `### DESKRIPSI NARASI CAPAIAN BELAJAR (DRAF RAPOR PAUD TERBARU)
**STANDAR KURIKULUM MERDEKA - LAPORAN HASIL BELAJAR**

* **Nama Anak Didik:** [Nama Siswa Didik]
* **Kelompok Usia & Fase:** ${kelas || "TK B (5-6 Tahun)"} / Fase Fondasi
* **Penyusun Narasi:** ${teacherName || "Ibu Kartini, S.Pd."}
* **Satuan PAUD:** ${schoolName || "TK Pembina Bangsa"}

---

#### I. ELEMEN NILAI AGAMA DAN BUDI PEKERTI
> *"Ananda menunjukkan perkembangan yang **Sangat Baik** dalam mengenal ciptaan Tuhan. Hal ini terlihat ketika ananda berpartisipasi aktif merawat taman sekolah, bersikap menyayangi tanaman dengan rutin menyiramnya di pagi hari, serta mempraktikkan doa harian sebelum makan dengan khidmat dan tertib."*

---

#### II. ELEMEN JATI DIRI (PENDIDIKAN KARAKTER)
> *"Ananda telah menunjukkan kemandirian dan rasa percaya diri yang tinggi dalam mengelola emosi diri. Ananda mampu menggunakan sepatu sendiri secara tertib setelah bermain di luar, serta berani memimpin barisan kelas pagi secara gembira."*

---

#### III. ELEMEN DASAR LITERASI, MATEMATIKA, SAINS, TEKNOLOGI & STEAM
> *"Ananda memiliki rasa eksplorasi yang tinggi terhadap sains sederhana. Ananda menunjukkan antusiasme luar biasa saat mengklasifikasikan loose parts berbentuk batu warna warni berdasarkan pola ukuran terkecil ke terbesar. Ananda juga terampil memaparkan secara verbal hasil karyanya di hadapan rekan-rakannya."*`;
        } else if (instrumentType === "OBSERVASI_ANAK") {
          mText = `### LEMBAR PANDUAN OBSERVASI PERKEMBANGAN ANAK EKsklusif
**MONITORING TUMBUH KEMBANG - MOTORIK & PERILAKU ADAPTIF**

* **Topik Pengamatan:** ${topic || "Penyelarasan Motorik dan Kognitif"}
* **Aspek Utama Kurikulum:** ${subject || "Jati Diri & Jaringan Motorik"}
* **Penyusun:** ${teacherName || "Ibu Guru PAUD"}

---

#### I. DAFTAR CEKLIS OBSERVASI PERTUMBUHAN SISWA
1. **[ ] Kemampuan Motorik Kasar:** Anak dapat berjalan lurus seimbang pada titian balok kayu (1-2 meter) dengan gembira.
2. **[ ] Kemampuan Motorik Halus:** Anak dapat menggunakan jempol dan telunjuknya untuk memegang pensil/krayon secara mantap (tripod grasp).
3. **[ ] Kemampuan Klasifikasi Kognitif:** Anak mampu menyortir bentuk benda bundar dan kotak dari sisa mainan.
4. **[ ] Kemampuan Komunikasi:** Anak mampu mengucapkan maaf, tolong, terima kasih secara tepat keadaan.

---

#### II. FORMAT ANALISIS EVALUASI INDIVIDU GURU
* Tempatkan tanda centang **V** pada setiap indikator yang muncul selama sebulan kegiatan sentra, serta simpan foto pendukung untuk memperkuat laporan.`;
        } else if (instrumentType === "DEEP_LEARNING_PAUD") {
          mText = `### DRAF DEEP LEARNING ANAK USIA DINI
**PRINSIP DEEP LEARNING (PEMAHAMAN MENDALAM SEJAK DINI)**

* **Jenjang:** PAUD/TK - ${kelas || "TK B (5-6 Tahun)"}
* **Topik Utama:** ${topic || "Menghargai Lingkungan Alam Sekitar"}
* **Mata Pelajaran:** ${subject || "STEAM Sederhana"}

---

#### I. FONDASI BELAJAR MENDALAM (DEEP LEARNING) PAUD
Meskipun anak usia dini belajar melalui bermain bebas, pemahaman mendalam dibangun di atas tiga pilar utama:
1. **Eksplorasi Multisensori (Sensory Connection):** Anak mengeksplorasi benda riil di alam (tanah gembur, air dingin, cacing tanah) dengan semua inderanya untuk melahirkan pertanyaan mandiri intelektual.
2. **Investigasi Kritis Kognitif (Asosiasi Sebab-Akibat):** Anak didorong menyimpulkan mengapa tanaman membutuhkan air dan cahaya matahari untuk bertahan hidup.
3. **Ekspresi Solutif Seni Kreatif:** Anak merekonstruksi pemahamannya memelihara alam lewat model gambar orat-oret imajinatif mereka.

---

#### II. REKOMENDASI AKTIVITAS GURU DI KELAS
* Hindari mendikte jawaban. Ajukan pertanyaan terbuka pemantik kemandirian berpikir kritis anak (HOTS PAUD), seperti: *"Bagaimana ya kira-kira rasanya menjadi pohon rindang yang kepanasan jika tidak ada yang menyiram?"*`;
        } else if (instrumentType === "ASESMEN") {
          mText = `### INSTRUMEN ASESMEN & EVALUASI BELAJAR
**KURIKULUM MERDEKA VERSI TERBARU (HOTS & PORTFOLIO)**

#### I. ASESMEN DIAGNOSTIK KOGNITIF (Awal Kegiatan)
1. Menurut pemahaman awal Anda, apa fungsi utama dari ${topic || "Topik Bahasan"} dalam operasional sehari-hari?
2. Bagaimana jika komponen pendukung ${topic || "Topik Bahasan"} tersebut mengalami kerusakan mendadak?

---

#### II. ASESMEN FORMATIF (Penilaian Proses & Sikap)
* **Kriteria Sikap Pancasila (Skor 1-4):**
  * **Mandiri:** Menuntaskan tugas individu tepat waktu tanpa bergantung rekan kelompok.
  * **Bernalar Kritis:** Mengajukan argumentasi logis atas temuan masalah baru.

---

#### III. ASESMEN SUMATIF (Soal HOTS Pilihan Ganda & Esai)
##### A. Soal Pilihan Ganda (HOTS)
* **Soal 1:** Di bawah ini yang merupakan tindakan diagnosis awal yang paling tepat untuk mengantisipasi kegagalan sistem ${topic || "Sistem"} adalah...
  * **A.** Mengganti seluruh suku cadang tanpa pengujian awal.
  * **B.** Melakukan observasi visual menyeluruh dan pembacaan kode gangguan secara sistematis (Kunci).
  * **C.** Menurunkan kapasitas daya dukung sistem secara sepihak.
  * **D.** Membiarkan kerusakan membesar hingga sistem mati total.
  * **E.** Menutup saluran sirkulasi utama secara manual.
  * **Kunci Jawaban:** **B** (Pembahasan: Observasi visual dan diagnosis awal adalah standar utama sebelum pembongkaran).

* **Soal 2:** Faktor kritis yang menentukan kestabilan proses pada penanganan ${topic || "Materi"} di era teknologi modern yaitu...
  * **A.** Kerapian admin dan dokumentasi.
  * **B.** Akurasi kalibrasi sensor penimbang serta pemeliharaan berkala (Kunci).
  * **C.** Jumlah pekerja manual di lapangan.
  * **Kunci Jawaban:** **B**

##### B. Soal Esai Analitis (Uraikan dengan jelas)
1. Mengapa penerapan pemeliharaan preventif (pencegahan) jauh lebih disarankan dibanding penanganan reaktif pada ${topic || "sistem ajar"}? Canangkan analisis biaya dan keselamatannya!`;
        } else if (instrumentType === "BAHAN_AJAR") {
          mText = `### BAHAN BACAAN GURU & PESERTA DIDIK
**STANDAR KURIKULUM MERDEKA - SUMBER AJAR MANDIRI COMPREHENSIVE**

#### I. PENYUSUN & MATERI
* **Bahan Referensi Utama:** ${topic || "Materi Pembelajaran Kurikulum"}
* **Mata Pelajaran:** ${subject || "Materi Ajar"}
* **Fase / Kelas:** ${kelas || "Fase F - Kelas XI"}
* **Sasaran Pembaca:** Guru Pendamping & Peserta Didik Aktif

---

#### II. RINGKASAN KONSEP UTAMA (Core Theory)
Sistem ${topic || "Topik"} dirancang sebagai pilar penting untuk mengoptimalkan kinerja di lapangan. Konsep dasarnya berakar dari hukum keseimbangan operasional, di mana setiap sub-komponen saling bertukar informasi secara linier.

* **Skema Struktur Hubungan:**
  * **Input Layer:** Sinyal masukan, instrumen deteksi, atau variabel kondisi.
  * **Processing Controller:** Otak pengolah data (ECU, Otak, atau Guru Kelas).
  * **Actuator Output:** Respon tindakan akhir (gerakan mekanis, tulisan, atau penyelesaian soal).

---

#### III. STUDI KASUS PRAKTIS & TIP SUKSES
  * **Aplikasi Lapangan:** Di sektor modern, efisiensi ${topic || "topik"} dapat menghemat konsumsi energi operasional hingga 35%. Kegagalan terkecil sering disebabkan kelembapan koneksi elektrikal atau bias kalibrasi.
  * **Tip Belajar Cepat:** Fokuslah memahami alur diagram blok sistem sebelum menghafal detail komponen kecil. Pahami cara kerja interaksi satu sama lain secara logis.`;
        } else if (instrumentType === "KKTP_GLOSARIUM") {
          mText = `### KRITERIA KETERCAPAIAN TUJUAN PEMBELAJARAN (KKTP) & GLOSARIUM
**KURIKULUM MERDEKA PEMETAAN TERBARU (RUBRIK INTERVAL)**

#### I. ELEMEN KKTP (INTERVAL NILAI)
Pemantauan kompetensi peserta didik pada pencapaian *${topic || "Topik Ajar"}* dipetakan secara interval dinamis:

| Kriteria Ketercapaian (Indikator Tugas) | Baru Berkembang (0-40) | Layak (41-70) | Cakap (71-90) | Mahir (91-100) |
| --- | --- | --- | --- | --- |
| **Kemampuan Menjelaskan Teori Dasar** | Mengingat sebagian istilah | Mampu merangkum inti materi | Mampu membandingkan teori | Mampu mengkritisi & membongkar teori |
| **Keterampilan Praktis / Pemecahan Kasus** | Kebingungan merakit | Merakit dengan panduan instan | Merakit secara mandiri & cepat | Mendiagnosis seluruh malafungsi eksternal |

* **Panduan Tindak Lanjut Intervensi:**
  * **Skor 0-40%:** Remedial intensif pada aspek konsep teoritis dasar.
  * **Skor 41-70%:** Penguatan materi lanjutan disertai tutor sebaya.
  * **Skor 71-100%:** Pengayaan mandiri, delegasi asisten lab atau pendampingan proyek nyata.

---

#### II. GLOSARIUM TERKAIT MATERI
* **Akurasi:** Tingkat kedekatan hasil pengukuran dengan nilai sebenarnya/standardisasi pabrik.
* **Kalibrasi:** Proses pengecekan dan penyetelan akurasi alat ukur berdasar acuan standar tepercaya.
* **Simulasi:** Peniruan kondisi riil lapangan melalui rekayasa terkontrol untuk media belajar aman.

---

#### III. DAFTAR PUSTAKA ACUAN GURU
1. Badan Standar, Kurikulum, dan Asesmen Pendidikan (BSKAP) Kemendikbudristek RI. (2024). *Panduan Pembelajaran dan Asesmen Kurikulum Merdeka*. Jakarta.
2. Tim Pengembang Kurikulum Kementerian Pendidikan. (2023). *Buku Guru & Buku Siswa Aktif*. Pusat Perbukuan Kemdikbud.`;
        } else {
          // Default MODUL_AJAR
          mText = `### RENCANA PELAKSANAAN PEMBELAJARAN (MODUL AJAR)
**KURIKULUM MERDEKA**

#### I. INFORMASI UMUM
* **Nama Penyusun:** ${teacherName || "Bpk. Aris Setiawan, S.Pd."}${nip ? ` (NIP: ${nip})` : ""}
* **Satuan Pendidikan:** ${schoolName || "SDN Merdeka 01"}
* **Mata Pelajaran:** ${subject || "Matematika"}
* **Fase / Kelas:** ${level || "SMP"} / ${kelas || "Kelas 7"}
* **Semester:** ${semester || "Ganjil"}
* **Alokasi Waktu:** 2 x 40 Menit
* **Topik / Bab:** ${topic || "Operasi Hitung"}

---

#### II. KOMPETENSI INTI
* **Capaian Pembelajaran (CP):** 
  > ${cp || "Siswa mampu memahami konsep dasar dan menyelesaikannya dalam konteks sehari-hari."}

* **Tujuan Pembelajaran:**
  1. Melalui media interaktif, peserta didik dapat memahami esensi dari *${topic || "materi ajar"}* secara komprehensif.
  2. Peserta didik dapat menyelesaikan studi kasus nyata yang berkaitan dengan kehidupan praktis sehari-hari.

${diferensiasi ? `* **Strategi Pembelajaran Diferensiasi:**
  * **Diferensiasi Konten:** Menyediakan bahan ajar visual (diagram/tabel), auditori (diskusi kelompok), dan kinestetik (percobaan mandiri/simulasi).
  * **Diferensiasi Proses:** Siswa dibagi menjadi kelompok mandiri, kelompok bimbingan asisten sebaya, dan kelompok bimbingan intensif guru.` : ''}

${deepLearning  ? `* **Prinsip Deep Learning (Pemahaman Mendalam):**
  * **Critical Thinking:** Menantang asumsi siswa melalui pertanyaan pemantik tingkat tinggi (HOTS).
  * **Connection:** Menghubungkan konsep teoritis dengan relevansi kontekstual daerah mereka.` : ''}

---

#### III. LANGKAH-LANGKAH PEMBELAJARAN
##### A. Kegiatan Pendahuluan (10 Menit)
1. Guru menyapa peserta didik dengan hangat, berdoa bersama, dan mengecek kehadiran.
2. **Apersepsi:** Guru memberikan pertanyaan pemantik visual yang memicu daya analisis siswa berkaitan dengan *${topic || "topik"}*.
3. Menyampaikan tujuan kelas hari ini dan memberikan motivasi belajar.

##### B. Kegiatan Inti (60 Menit)
1. **Pemberian Rangsangan (Stimulation):** Guru mendemonstrasikan fenomena konkret di depan kelas.
2. **Identifikasi Masalah (Problem Statement):** Siswa merumuskan pertanyaan kritis terkait fenomena tersebut.
3. **Pengumpulan Data (Data Collection):** Siswa bekerja secara berkelompok mengeksplorasi referensi yang relevan.
4. **Pengolahan Data (Data Processing):** Siswa merumuskan hipotesis dan mencari solusi problem solving.
5. **Pembuktian (Verification):** Perwakilan kelompok menyajikan hasil analisis, ditanggapi kelompok lain.
6. **Menarik Kesimpulan (Generalization):** Guru membimbing siswa menyepakati inti materi dengan visual yang representatif.

##### C. Kegiatan Penutup (10 Menit)
1. Peserta didik melakukan evaluasi mandiri (refleksi materi yang dirasa paling menarik).
2. Guru memberikan umpan balik positif dan menutup sesi dengan pesan inspiratif.

---

#### IV. ASESMEN / PENILAIAN
1. **Sikap:** Observasi keaktifan, kedisplinan, dan profil pelajar Pancasila.
2. **Pengetahuan:** Kuis tertulis / tes penalaran logis singkat.
3. **Keterampilan:** Penilaian presentasi kelompok atau hasil portofolio LKPD.`;
        }

        return res.json({ text: mText, isMock: true });
      }

      const systemInstruction = 
        "Anda adalah seorang pakar pengembang kurikulum Kurikulum Merdeka Kemendikbudristek RI di Indonesia. " +
        "Tugas Anda adalah menghasilkan draf modul dan perangkat pembelajaran guru terbaru yang sangat komprehensif, berkualitas tinggi, " +
        "profesional, dan memiliki struktur akademis yang ketat dalam Bahasa Indonesia. Hilangkan code fences seperti ```markdown di awal output.";

      let prompt = "";
      if (instrumentType === "ATP") {
        prompt = `Buatkan Alur Tujuan Pembelajaran (ATP) Kurikulum Merdeka dengan parameter berikut:
        - Nama Penyusun: ${teacherName || "Bpk. Aris Setiawan, S.Pd."}${nip ? ` (NIP: ${nip})` : ""}
        - Sekolah: ${schoolName || "SDN Merdeka 01"}
        - Jenjang & Kelas: ${level} / ${kelas}
        - Semester: ${semester}
        - Mata Pelajaran: ${subject}
        - Topik Bahasan: ${topic}
        - Capaian Pembelajaran (CP): ${cp}
        - Pembelajaran Diferensiasi: ${diferensiasi ? 'Ya, terapkan diferensiasi' : 'Tidak wajib'}
        - Deep Learning: ${deepLearning ? 'Ya, tekankan prinsip deep learning' : 'Tidak wajib'}
        
        Format output harus dalam bentuk sub-bab bercabang Markdown yang rapi tanpa simbol aneh, mencakup:
        1. Identitas ATP (Penyusun, Satuan, Fase, Kelas, Mapel)
        2. Analisis Rasional & Konsep Utama Mata Pelajaran
        3. Pemetaan Alur Tujuan Pembelajaran per Elemen (Sebutkan Elemen Kurikulum Merdeka yang relevan dengan topik ini)
        4. Alokasi Waktu Rinci dan Skenario Alur Pertemuan (Pertemuan 1, Pertemuan 2, dst)
        5. Profil Pelajar Pancasila & Glosarium Mini.`;
      } else if (instrumentType === "LKPD") {
        prompt = `Buatkan Lembar Kerja Peserta Didik (LKPD) Interaktif Kurikulum Merdeka dengan parameter berikut:
        - Nama Penyusun: ${teacherName || "Bpk. Aris Setiawan, S.Pd."}${nip ? ` (NIP: ${nip})` : ""}
        - Sekolah: ${schoolName || "SDN Merdeka 01"}
        - Jenjang & Kelas: ${level} / ${kelas}
        - Semester: ${semester}
        - Mata Pelajaran: ${subject}
        - Topik Bahasan: ${topic}
        - Capaian Pembelajaran (CP): ${cp}
        - Pembelajaran Diferensiasi: ${diferensiasi ? 'Ya, rancang aktivitas LKPD yang melayani tipe belajar berbeda' : 'Tidak wajib'}
        
        Format output harus dalam bentuk panduan kerja siswa Markdown yang terstruktur, menarik, dan ramah anak, mencakup:
        1. JUDUL LKPD LENGKAP dengan identitas siswa (Nama Kelompok, Nama Anggota, Kelas)
        2. Petunjuk Belajar & Tujuan Aktivitas Siswa
        3. Alat dan Bahan pendukung (terutama untuk praktik/bengkel jika SMK, atau mainan jika PAUD)
        4. Langkah-Langkah Kerja Eksperimen/Diskusi yang sistematis dan menantang (High-Order Thinking)
        5. Pertanyaan Reflektif / Pengolahan Data kelayakan solusi
        6. Lembar Kesimpulan untuk diisi siswa.`;
      } else if (instrumentType === "MODUL_BERMAIN") {
        prompt = `Buatkan Rencana Pelaksanaan Pembelajaran (Modul Bermain Bermakna PAUD) Kurikulum Merdeka dengan parameter berikut:
        - Nama Penyusun: ${teacherName || "Ibu Kartini, S.Pd."}${nip ? ` (NIP: ${nip})` : ""}
        - Satuan PAUD: ${schoolName || "TK Pembina Bangsa"}
        - Kelompok Usia: ${kelas}
        - Semester: ${semester}
        - Topik/Sub-topik: ${topic}
        - Capaian Perkembangan (CP): ${cp}
        - Strategi Bermain: Pembelajaran Berbasis Loose Parts (Bahan Alami/Daur Ulang)
        
        Format output harus dalam bentuk rancangan bermain bermakna yang ceria dan ramah anak, mencakup:
        1. Identitas Lengkap Modul Bermain
        2. Elemen Capaian Perkembangan Anak yang Disasar
        3. Pijakan Sebelum Bermain (Apersepsi cerita, bernyanyi, aturan main)
        4. Pijakan Saat Bermain (Aneka ragam aktivitas di berbagai sentra/area yang mendalam)
        5. Pijakan Setelah Bermain (Recalling diskusi karya anak, melatih kemandirian membereskan alat)
        6. Rencana Asesmen (Catatan Anekdot dan Foto berseri).`;
      } else if (instrumentType === "ASESMEN_PERKEMBANGAN") {
        prompt = `Buatkan Rubrik Asesmen Perkembangan Pembelajaran PAUD Kurikulum Merdeka dengan parameter berikut:
        - Penyusun: ${teacherName || "Ibu Kartini, S.Pd."}
        - Sekolah: ${schoolName || "TK Pembina Bangsa"}
        - Kelompok Usia: ${kelas}
        - Elemen Kompetensi/Mapel: ${subject}
        - Topik Bahasan: ${topic}
        
        Format output harus mencakup:
        1. Rubrik Penilaian dengan Kriteria (Belum Muncul - BM, Mulai Muncul - MM, Berkembang Sesuai Harapan - BSH, Berkembang Sangat Baik - BSB)
        2. Indikator perilaku konkret anak yang relevan dengan topik ${topic}
        3. Panduan instrumen lembar ceklis observasi guru.`;
      } else if (instrumentType === "ANECDOTAL_RECORD") {
        prompt = `Buatkan Catatan Anekdot (Anecdotal Record) PAUD Kurikulum Merdeka dengan parameter berikut:
        - Nama Guru: ${teacherName}
        - Satuan PAUD: ${schoolName}
        - Kelompok Usia: ${kelas}
        - Topik/Aktivitas: ${topic}
        
        Format output harus dalam bentuk tabel deskriptif Markdown yang sangat rapi, berisi:
        1. Templat Tabel Anecdotal Record dengan kolom: Tanggal, Nama Anak, Peristiwa Kejadian Unik Anak, Analisis Capaian Elemen Perkembangan Anak. Isi tabel dengan contoh konkret 2 skenario nyata anak di kelas PAUD.
        2. Panduan/Rencana Stimulasi Guru menindaklanjuti temuan tersebut.`;
      } else if (instrumentType === "RAPOR_PAUD") {
        prompt = `Buatkan Draf Deskripsi Narasi Rapor PAUD Kurikulum Merdeka Terbaru dengan parameter berikut:
        - Nama Penyusun: ${teacherName}
        - Satuan PAUD: ${schoolName}
        - Kelompok Usia/Fase: ${kelas} / Fase Fondasi
        - Elemen Utama: ${subject}
        - Fokus Aktivitas/Topik: ${topic}
        
        Format output berupa contoh penulisan deskripsi narasi rapor siswa yang positif, konstruktif, dan menyentuh hati orang tua untuk:
        1. Elemen Nilai Agama dan Budi Pekerti
        2. Elemen Jati Diri (Kemandirian dan Emosi)
        3. Elemen Dasar Literasi, Matematika, Sains, Teknologi, Rekayasa, dan Seni (STEAM)
        Tampilkan contoh kalimat capaian istimewa (BSB) dan bimbingan lembut bagi perkembangan anak yang belum muncul.`;
      } else if (instrumentType === "OBSERVASI_ANAK") {
        prompt = `Buatkan Panduan Observasi Perkembangan Anak PAUD Kurikulum Merdeka dengan parameter berikut:
        - Nama Guru: ${teacherName}
        - Satuan PAUD: ${schoolName}
        - Kelompok Usia: ${kelas}
        - Topik Pengamatan: ${topic}
        
        Format output harus menyajikan checklist perilaku, indikator motorik halus dan kasar, kemampuan sosial emosional, sains sederhana, dan kemandirian anak secara operasional.`;
      } else if (instrumentType === "DEEP_LEARNING_PAUD") {
        prompt = `Buatkan Panduan Deep Learning (Pemahaman Mendalam) Anak Usia Dini PAUD Kurikulum Merdeka dengan parameter berikut:
        - Nama Guru: ${teacherName}
        - Satuan PAUD: ${schoolName}
        - Kelompok Usia: ${kelas}
        - Topik Utama: ${topic}
        - Elemen STEAM: ${subject}
        
        Format output harus menekankan prinsip:
        1. Sensory Connection (Koneksi Multisensori dengan bahan loose parts nyata)
        2. Critical Thinking & Cause Effect (Sebab akibat) untuk anak usia dini lewat pertanyaan pemantik terbuka (HOTS PAUD)
        3. Kreativitas Ekspresif Mandiri.`;
      } else if (instrumentType === "ASESMEN") {
        prompt = `Buatkan Instrumen Asesmen Pembelajaran Kurikulum Merdeka dengan parameter berikut:
        - Nama Penyusun: ${teacherName || "Bpk. Aris Setiawan, S.Pd."}${nip ? ` (NIP: ${nip})` : ""}
        - Sekolah: ${schoolName || "SDN Merdeka 01"}
        - Jenjang & Kelas: ${level} / ${kelas}
        - Mata Pelajaran: ${subject}
        - Topik Bahasan: ${topic}
        - Capaian Pembelajaran (CP): ${cp}
        - Deep Learning: ${deepLearning ? 'Ya, rancang asesmen berbasis pemahaman mendalam' : 'Tidak wajib'}
        
        Format output harus dalam bentuk kuis, instrumen, dan rubrik Markdown yang komprehensif, mencakup:
        1. Asesmen Diagnostik Kognitif & Non-Kognitif (Pertanyaan awal memetakan kemampuan dasar)
        2. Asesmen Formatif (Rubrik aktivitas proses diskusi atau penilaian observasi sikap profil pelajar pancasila)
        3. Asesmen Sumatif (Berisi minimal 5 butir soal HOTS Pilihan Ganda dengan Opsi jawaban A, B, C, D, E beserta KUNCI JAWABAN dan pembahasannya, serta minimal 2 soal uraian esai analitis)
        4. Kriteria Penilaian & Konversi Skor Nilai Akhir.`;
      } else if (instrumentType === "BAHAN_AJAR") {
        prompt = `Buatkan Bahan Ajar Bacaan Ringkas (Summary Handout) Kurikulum Merdeka dengan parameter berikut:
        - Nama Penyusun: ${teacherName || "Bpk. Aris Setiawan, S.Pd."}${nip ? ` (NIP: ${nip})` : ""}
        - Sekolah: ${schoolName || "SDN Merdeka 01"}
        - Jenjang & Kelas: ${level} / ${kelas}
        - Mata Pelajaran: ${subject}
        - Topik Bahasan: ${topic}
        - Capaian Pembelajaran (CP): ${cp}
        
        Format output harus dalam bentuk modul bacaan/handout Markdown yang kaya materi sains/praktis, mencakup:
        1. Judul Menarik & Ringkasan Materi Esensial
        2. Penjelasan Konsep Teoritis Tepercaya (disertai ilustrasi analitis teks, analogi yang logis, dan diagram prosedur)
        3. Studi Kasus Nyata di Indonesia atau aplikasinya dalam industri (jika SMK) / kehidupan sehari-hari (jika SD/PAUD)
        4. Peta Konsep Ringkas (Teks hierarki visual)
        5. Rujukan Cepat Istilah & Tip Belajar Cepat.`;
      } else if (instrumentType === "KKTP_GLOSARIUM") {
        prompt = `Buatkan Kriteria Ketercapaian Tujuan Pembelajaran (KKTP) dan Glosarium Kurikulum Merdeka dengan parameter berikut:
        - Nama Penyusun: ${teacherName || "Bpk. Aris Setiawan, S.Pd."}${nip ? ` (NIP: ${nip})` : ""}
        - Sekolah: ${schoolName || "SDN Merdeka 01"}
        - Jenjang & Kelas: ${level} / ${kelas}
        - Mata Pelajaran: ${subject}
        - Topik Bahasan: ${topic}
        - Capaian Pembelajaran (CP): ${cp}
        
        Format output harus dalam bentuk instrumen bimbingan guru Kurikulum Merdeka berupa:
        1. Kriteria Ketercapaian Tujuan Pembelajaran (KKTP) menggunakan Pendekatan Deskripsi Kriteria, Pendekatan Rubrik, dan Pendekatan Interval Nilai (0-40, 41-70, 71-100) beserta intervensinya.
        2. Glosarium istilah-istilah ilmiah/kejuruan penting terkait materi ini (minimal 8 kata kunci penting beserta penjelasannya)
        3. Daftar Pustaka pendukung sesuai format standar rujukan akademik (APA/MLA style).`;
      } else {
        // Default MODUL_AJAR
        prompt = `Buatkan Rencana Pelaksanaan Pembelajaran (Modul Ajar) Kurikulum Merdeka dengan parameter berikut:
        - Nama Penyusun (Guru): ${teacherName || "Bpk. Aris Setiawan, S.Pd."}${nip ? ` (NIP: ${nip})` : ""}
        - Satuan Pendidikan (Sekolah): ${schoolName || "SDN Merdeka 01"}
        - Jenjang Pendidikan: ${level}
        - Kelas: ${kelas}
        - Semester: ${semester}
        - Mata Pelajaran: ${subject}
        - Topik/Bab: ${topic}
        - Capaian Pembelajaran (CP): ${cp}
        - Pembelajaran Diferensiasi: ${diferensiasi ? 'Ya, terapkan diferensiasi konten, proses, dan produk' : 'Tidak wajib'}
        - Prinsip Deep Learning: ${deepLearning ? 'Ya, tekankan pemahaman mendalam, konsep HOTS, koneksi kontekstual, dan refleksi' : 'Tidak wajib'}
        
        Format output harus dalam bentuk Markdown lengkap yang rapi dan indah, mencakup:
        1. Identitas Modul (Nama Penyusun: ${teacherName || "Bpk. Aris Setiawan, S.Pd."}, Sekolah: ${schoolName || "SDN Merdeka 01"}, Alokasi Waktu, Kelas, dll)
        2. Kompetensi Awal
        3. Profil Pelajar Pancasila yang berkaitan
        4. Sarana dan Prasarana
        5. Tujuan Pembelajaran
        6. Pertanyaan Pemantik
        7. Langkah-langkah Pembelajaran Lengkap (Pendahuluan, Inti, Penutup) dengan metode diferensiasi/deep learning jika diaktifkan
        8. Asesmen Penilaian (Sikap, Pengetahuan, Keterampilan)
        9. Pengayaan & Remedial.`;
      }

      // Specific level overrides
      if (level === "SMK") {
        prompt += `\n\nCATATAN KHUSUS UNTUK SMK: Karena jenjang SMK, modul ini harus sangat praktis, bernuansa link-and-match dengan industri modern, menyertakan standar K3 (Keselamatan dan Kesehatan Kerja), dan fokus pada praktik bengkel/laboratorium serta penalaran troubleshooting teknik maupun penguasaan konsentrasi keahlian kejuruan yang dipilih.`;
      } else if (level === "SLB") {
        prompt += `\n\nCATATAN KHUSUS UNTUK SLB: Karena jenjang SLB (Sekolah Luar Biasa), sesuaikan penyusunannya dengan akomodasi kebutuhan khusus siswa, gunakan pendekatan instruksi konkret, penyederhanaan langkah motorik, penguatan visual, dan melatih kemandirian perilaku adaptif.`;
      } else if (level === "PAUD") {
        prompt += `\n\nCATATAN KHUSUS UNTUK PAUD: Karena jenjang PAUD, buatlah berpusat pada bermain sebagai belajar, pengembangan motorik kasar/halus, sosio-emosional anak, proyek Pancasila sederhana (P5), serta menyanyi/bercerita yang menggembirakan.`;
      }

      const response = await ai.models.generateContent({
        model: "gemini-3.5-flash",
        contents: prompt,
        config: {
          systemInstruction,
          temperature: 0.7,
        }
      });

      res.json({ text: response.text || "Gagal menghasilkan modul.", isMock: false });
    } catch (error: any) {
      console.error("Gemini execution error:", error);
      res.status(500).json({ error: error.message || "Kesalahan internal server." });
    }
  });

  // 2. API: Chat Guru Assistant
  app.post("/api/chat", async (req, res) => {
    const { message, history } = req.body;

    try {
      const ai = getGeminiClient();

      // Determine context or topic for intelligent UI asset injection
      const textLower = (message || "").toLowerCase();
      let hasTSMContext = textLower.includes("tsm") || textLower.includes("motor") || textLower.includes("injeksi") || textLower.includes("bengkel");
      let hasSainsContext = textLower.includes("sains") || textLower.includes("ipa") || textLower.includes("biologi") || textLower.includes("fisika") || textLower.includes("ekosistem");
      let hasMathContext = textLower.includes("matematika") || textLower.includes("angka") || textLower.includes("rumus") || textLower.includes("hitung") || textLower.includes("geometri");

      // Default assets configuration
      let assets = undefined;

      if (hasTSMContext) {
        assets = {
          slides: {
            title: "Sistem Bahan Bakar Injeksi TSM (Troubleshooting)",
            fileName: "Struktur Sistem EFI TSM.pptx",
            imageUrl: "https://lh3.googleusercontent.com/aida-public/AB6AXuA9vAg5zp8-iJUvzpiP6AQ4y6NiQPBtU9RiykmVQw7VwBTNY0XskTpgT8dNo2eoat4BFP4p-bcODGHuq4ENYPhjN_l9QfUf_J4xRTICWAkoP1wdlGViJaekHZFzEBXwoI8OdJmYrV_sdSWo4ZEBX0kpPLBHyH269n5LTD5xwPLERXsKPd1DQZOC9PrDCDG4LbMq_z8wvdkranPS1gAu23mlvGLISyRj354SoQA3YOdKlbyK0c9QE1C_88hRDiNLp0Kz8V_xuVIe3Is"
          },
          lkpd: {
            title: "LKPD Mandiri: Sensor EFI & Troubleshooting",
            status: "TERSEDIA",
            imageUrl: "https://lh3.googleusercontent.com/aida-public/AB6AXuD6I1iRN3oXZ3UbR8RehvpUnsVhX-YRo2S72uli4gXAvii_6XpLFtWs6bbG3XDZZzK4DOd8hZK9X95qLX0pscrrVe2Q119mTzdllcdUCna3XlIFxtPxnT-CLOuJU2RwaSXJ1PboIc7puZRxco0Th_4KIJJ7xiSzOeZxU2haKfuwXy8rholiMfI8iaVVkbxtmPTxHg_seLiIp2qNsyRC74771FZvQ_oJ0EWtWCxc6ptiaCDneGk9nTyuZZsyQyn9Xm_oGRvJVoWK7Vs"
          },
          cheatsheet: {
            title: "Cheat Sheet Diagnosis DTC & Reset ECU",
            status: "TERSEDIA",
            imageUrl: "https://lh3.googleusercontent.com/aida-public/AB6AXuDS1W94dC7hEo6QxHw60Cl4c7EbH4yKGR6bkNxOYOSnJL6-NrsTHdegXieUBrR-j-VdlzKkMlaLqbzlGeIwrp3vVBMS06R6JbyD40Rnr_9EeTtMcMXXDZkwH4cLxJLBRbNCFQtNbruY7ublWYKWiD8uL2XTp0BBjnmJOWaanDKbi7v5NF2GwQ97WAUh8MkEAuJmia86ejSErc5u0NVBhLAnH2s7A7jp5WWsuPCTZy4LFVHacZnL4ywKo36yi6Bgr5jo0uVXGk-nVuE"
          }
        };
      } else if (hasSainsContext) {
        assets = {
          slides: {
            title: "Rantai Makanan & Abiotik - Sains SD/SMP",
            fileName: "Interaksi Ekosistem Sains.pptx",
            imageUrl: "https://lh3.googleusercontent.com/aida-public/AB6AXuAZed_mzWOGdONt9tUUYzWHsS7u30gjvXp_PmLosxMniz97GzGpQ8PcHWOoyNkLozz4o3tMAP-2ROZU2y2AUbSy1ADINY-c5KXabmVK3XfQS-jJZYWCP_eYxgMEvts_up6EL0RKcpx4PCy-lfoFlFbaIrkHkVTSvaVgG2QzX-VoUFckGMCNYJeYGwUXd9fxeOLK1yA50jY4FDGF9xp50pW6xJGDq0MkWS3FNNw-n9-jJ8YF-ROatCpg7Sb4DtYoRwNEZ9zAfTLnohk"
          },
          lkpd: {
            title: "Lembar Eksplorasi Biotik Lapangan",
            status: "TERSEDIA",
            imageUrl: "https://lh3.googleusercontent.com/aida-public/AB6AXuD6I1iRN3oXZ3UbR8RehvpUnsVhX-YRo2S72uli4gXAvii_6XpLFtWs6bbG3XDZZzK4DOd8hZK9X95qLX0pscrrVe2Q119mTzdllcdUCna3XlIFxtPxnT-CLOuJU2RwaSXJ1PboIc7puZRxco0Th_4KIJJ7xiSzOeZxU2haKfuwXy8rholiMfI8iaVVkbxtmPTxHg_seLiIp2qNsyRC74771FZvQ_oJ0EWtWCxc6ptiaCDneGk9nTyuZZsyQyn9Xm_oGRvJVoWK7Vs"
          },
          cheatsheet: {
            title: "Bagan Klasifikasi Makhluk Hidup",
            status: "TERSEDIA",
            imageUrl: "https://lh3.googleusercontent.com/aida-public/AB6AXuAmHxEGJxZKkdYsSeePu0W0OWeID3mCZMCbNBZK-SxeLiaO9C3KnyR-dtE42P52-PGTqB8x_LBqtd5K0PCIpcPenucb5ROzYnTiCeRE0_dMkGMGA56fXserVO-svib4C3UgjqiirUa-zi6BHXDzUAM2O68adeAGjXN_cneD6-D1lQOGHKoScv-b84Kelop7PCZPki5Xa6YhCnv412ogxYS6xfi6HrgadJj796GXfCpFukNmZIYCI4yoM5jCnnJMJmdCv2gYWN2PXGE"
          }
        };
      } else if (hasMathContext) {
        assets = {
          slides: {
            title: "Visualisasi Rumus Geometri Ruang",
            fileName: "Matematika Geometri Ruang.pptx",
            imageUrl: "https://lh3.googleusercontent.com/aida-public/AB6AXuAmHxEGJxZKkdYsSeePu0W0OWeID3mCZMCbNBZK-SxeLiaO9C3KnyR-dtE42P52-PGTqB8x_LBqtd5K0PCIpcPenucb5ROzYnTiCeRE0_dMkGMGA56fXserVO-svib4C3UgjqiirUa-zi6BHXDzUAM2O68adeAGjXN_cneD6-D1lQOGHKoScv-b84Kelop7PCZPki5Xa6YhCnv412ogxYS6xfi6HrgadJj796GXfCpFukNmZIYCI4yoM5jCnnJMJmdCv2gYWN2PXGE"
          },
          lkpd: {
            title: "Kuis Latihan Matematika Konstruktif",
            status: "TERSEDIA",
            imageUrl: "https://lh3.googleusercontent.com/aida-public/AB6AXuD6I1iRN3oXZ3UbR8RehvpUnsVhX-YRo2S72uli4gXAvii_6XpLFtWs6bbG3XDZZzK4DOd8hZK9X95qLX0pscrrVe2Q119mTzdllcdUCna3XlIFxtPxnT-CLOuJU2RwaSXJ1PboIc7puZRxco0Th_4KIJJ7xiSzOeZxU2haKfuwXy8rholiMfI8iaVVkbxtmPTxHg_seLiIp2qNsyRC74771FZvQ_oJ0EWtWCxc6ptiaCDneGk9nTyuZZsyQyn9Xm_oGRvJVoWK7Vs"
          },
          cheatsheet: {
            title: "Formula Cepat Volume & Sisi Bangun Ruang",
            status: "TERSEDIA",
            imageUrl: "https://lh3.googleusercontent.com/aida-public/AB6AXuDS1W94dC7hEo6QxHw60Cl4c7EbH4yKGR6bkNxOYOSnJL6-NrsTHdegXieUBrR-j-VdlzKkMlaLqbzlGeIwrp3vVBMS06R6JbyD40Rnr_9EeTtMcMXXDZkwH4cLxJLBRbNCFQtNbruY7ublWYKWiD8uL2XTp0BBjnmJOWaanDKbi7v5NF2GwQ97WAUh8MkEAuJmia86ejSErc5u0NVBhLAnH2s7A7jp5WWsuPCTZy4LFVHacZnL4ywKo36yi6Bgr5jo0uVXGk-nVuE"
          }
        };
      }

      if (!ai) {
        // Mock chat replies
        let responseText = "Halo, Pak Aris! Tentu, saya senang bisa membantu merancang materi ajar Anda. ";
        
        if (hasTSMContext) {
          responseText += `Berikut adalah draf singkat **Modul Praktikum Troubleshooting Sistem Injeksi (EFI)** untuk kelas XI TSM:
          
### 1. Tujuan Pembelajaran
* Siswa mampu mendiagnosis kode kegagalan (DTC) menggunakan scanner EFI.
* Siswa mampu melakukan reset ECU/ECM secara manual maupun menggunakan scanner khusus.
* Siswa mampu melakukan troubleshooting dan perbaikan pada sensor tekanan udara absolut manifold (MAP).

Saya juga telah merancang slide interaktif dan lembar kerja peserta didik (LKPD) yang terlampir pada panel **AI Media Assets** di kanan layar untuk mendukung proses mengajar Anda di bengkel/kelas secara efektif!`;
        } else if (hasSainsContext) {
          responseText += `Baik, Pak Aris. Ini adalah rekomendasi silabus **Sains/IPA Lingkungan Biotik & Abiotik**:
          
### 1. Intisari Pembelajaran
* Investigasi interaksi makhluk hidup dengan lingkungan habitat aslinya.
* Simulasi analisis rantai makanan sederhana berbasis studi kasus riil.

Aset visual, slide interaktif, dan LKPD sains pendukung dapat langsung dilihat dan diunduh di sebelah kanan!`;
        } else if (hasMathContext) {
          responseText += `Tentu, ini adalah rancangan aktivitas pembelajaran matematika interaktif:
          
### 1. Aktivitas Inti
* Konstruksi bangun ruang secara mandiri menggunakan origami / model 3D.
* Asesmen kolaboratif memecahkan rumus diagonal dan luas permukaan volume.

Draf presentasi pembelajaran visual serta formula ringkas matematika telah siap diakses di panel kanan!`;
        } else {
          responseText += "Ada yang bisa saya bantu diskusikan untuk persiapan kelas atau modul ajar Kurikulum Merdeka hari ini? Sebutkan mata pelajaran seperti Sains, Matematika, atau kejuruan Teknik Sepeda Motor (TSM) agar saya dapat menyiapkan aset media pembelajarannya secara instan.";
        }

        const suggestions = hasTSMContext 
          ? ["Buat Kuis Interaktif (Kahoot Style)", "Generate Video Skrip Penjelasan"]
          : ["Rancang Asesmen HOTS", "Integrasikan Profil Pelajar Pancasila"];

        return res.json({ text: responseText, suggestions, assets });
      }

      const systemInstruction = 
        "Anda adalah Guru AI Assistant, asisten kecerdasan buatan super pintar khusus pendidik di Indonesia. " +
        "Gaya bicara Anda harus ramah, santun, inspiratif, profesional, dan berfokus memberikan solusi kurikulum Merdeka yang kontekstual. " +
        "Hasilkan penjelasan bersahabat dengan format Markdown.";

      // Simple build up of prompt conversation
      let promptWithContext = `Sapa guru bernama Bpk. Aris. Beliau bertanya: "${message}"\n`;
      if (history && history.length > 0) {
        promptWithContext += "Histori obrolan singkat sebelumnya:\n";
        const pastChat = history.slice(-4).map((h: any) => `${h.sender === 'user' ? 'Guru' : 'AI'}: ${h.text}`).join("\n");
        promptWithContext += pastChat + "\n";
      }

      const response = await ai.models.generateContent({
        model: "gemini-3.5-flash",
        contents: promptWithContext,
        config: {
          systemInstruction,
          temperature: 0.7,
        }
      });

      // Provide default suggestions
      const suggestions = hasTSMContext 
        ? ["Buat Kuis Interaktif (Kahoot Style)", "Generate Video Skrip Penjelasan"]
        : ["Rancang Lembar Kerja Siswa", "Rancang Soal Asesmen Pemantik"];

      res.json({
        text: response.text || "Mohon maaf, terjadi gangguan koneksi dengan asisten AI.",
        suggestions,
        assets
      });
    } catch (error: any) {
      console.error("Chat error:", error);
      res.status(500).json({ error: error.message || "Kesalahan internal." });
    }
  });

  // 3. API: Publish Modul Ajar
  const DB_PATH = path.join(process.cwd(), "published_db.json");

  function loadPublishedDB(): Record<string, any> {
    try {
      if (fs.existsSync(DB_PATH)) {
        const data = fs.readFileSync(DB_PATH, "utf-8");
        return JSON.parse(data);
      }
    } catch (error) {
      console.error("Error reading db:", error);
    }
    return {};
  }

  function savePublishedDB(db: Record<string, any>) {
    try {
      fs.writeFileSync(DB_PATH, JSON.stringify(db, null, 2), "utf-8");
    } catch (error) {
      console.error("Error writing db:", error);
    }
  }

  app.post("/api/publish", (req, res) => {
    const { title, level, kelas, semester, subject, topic, cp, content, authorName, schoolName } = req.body;
    
    if (!content) {
      return res.status(400).json({ error: "Konten modul ajar kosong." });
    }

    try {
      const db = loadPublishedDB();
      const publishId = "pub_" + Math.random().toString(36).substring(2, 10);
      
      db[publishId] = {
        id: publishId,
        title: title || "Modul Ajar",
        level: level || "SMK",
        kelas: kelas || "Kelas XI",
        semester: semester || "Ganjil",
        subject: subject || "Lainnya",
        topic: topic || "",
        cp: cp || "",
        content,
        authorName: authorName || "Bpk. Aris Setiawan, S.Pd.",
        schoolName: schoolName || "SDN Merdeka 01",
        publishedAt: new Date().toLocaleDateString("id-ID", {
          weekday: "long",
          year: "numeric",
          month: "long",
          day: "numeric"
        })
      };

      savePublishedDB(db);
      res.json({ success: true, id: publishId });
    } catch (e: any) {
      console.error("Error publishing module:", e);
      res.status(500).json({ error: "Gagal mempublikasikan modul." });
    }
  });

  app.get("/api/published/:id", (req, res) => {
    const { id } = req.params;
    try {
      const db = loadPublishedDB();
      const published = db[id];
      if (!published) {
        return res.status(404).json({ error: "Modul ajar tidak ditemukan." });
      }
      res.json(published);
    } catch (e: any) {
      console.error("Error fetching published:", e);
      res.status(500).json({ error: "Gagal memuat data." });
    }
  });

  // Vite/Static build routing
  if (process.env.NODE_ENV !== "production") {
    const vite = await createViteServer({
      server: { middlewareMode: true },
      appType: "spa",
    });
    app.use(vite.middlewares);
  } else {
    const distPath = path.join(process.cwd(), 'dist');
    app.use(express.static(distPath));
    app.get('*', (req, res) => {
      res.sendFile(path.join(distPath, 'index.html'));
    });
  }

  app.listen(PORT, "0.0.0.0", () => {
    console.log(`Server EduAI Indonesia running on port ${PORT}`);
  });
}

startServer().catch((err) => {
  console.error("Server starting failure:", err);
});
